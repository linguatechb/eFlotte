<?php
/**
 * Configuration eFlotte Bénin (instance ministérielle).
 * Pour personnaliser sans modifier ce fichier : créer config/config.local.php
 * qui retourne un tableau (il sera fusionné avec celui-ci).
 */
return [
    'app_name' => 'eFlotte Bénin',
    'env'      => 'production',            // 'development' pour afficher les erreurs PHP
    'timezone' => 'Africa/Porto-Novo',
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'eflotte_benin',
        'user' => 'root',                  // XAMPP par défaut
        'pass' => '',                      // XAMPP par défaut
    ],
    // Dossiers sensibles : peuvent être placés HORS de htdocs (recommandé en production)
    // ex. 'private_upload_path' => 'C:/eflotte_data/uploads',  'backup_path' => 'C:/eflotte_data/backups'
    'private_upload_path' => null,         // contient ordres_mission/ et justificatifs/
    'backup_path'         => null,         // sauvegardes (.zip)
];
