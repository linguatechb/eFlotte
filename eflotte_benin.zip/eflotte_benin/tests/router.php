<?php
// Routeur pour `php -S` : reproduit les règles .htaccess (le serveur intégré ne les lit pas)
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (preg_match('#^/(app|config|database|storage|lib|tests|tools)(/|$)#', $path) || preg_match('#^/uploads/(ordres_mission|justificatifs)(/|$)#', $path)
    || preg_match('#^/public/.*\.php$#', $path) || preg_match('#\.(sql|log|zip|lock)$#', $path) || preg_match('#/\.ht#', $path)) { http_response_code(403); echo 'Forbidden'; return true; }
if ($path === '/' || $path === '/index.php') { $_SERVER['SCRIPT_NAME'] = '/index.php'; require __DIR__ . '/../index.php'; return true; }
if ($path === '/setup.php') { return false; }
return false;
