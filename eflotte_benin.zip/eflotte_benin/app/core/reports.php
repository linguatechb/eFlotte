<?php
declare(strict_types=1);

const REPORT_TYPES = [
    'mensuel' => 'Rapport mensuel d\'activité', 'annuel' => 'Rapport annuel d\'activité', 'missions' => 'Missions',
    'vehicule' => 'Rapport par véhicule', 'chauffeur' => 'Rapport par chauffeur', 'depenses' => 'Dépenses automobiles',
    'maintenances' => 'Maintenances', 'immobilisations' => 'Immobilisations et indisponibilités',
];
const DEP_CATS = ['Carburant', 'Entretien', 'Réparation', 'Assurance', 'Visite technique', 'Pièces détachées', 'Autres frais'];
const MNT_CATS = ['Vidange', 'Pneumatiques', 'Freinage', 'Batterie', 'Révision générale', 'Réparation mécanique', 'Réparation électrique', 'Autres interventions'];
const CARBURANTS = ['Essence', 'Diesel', 'Hybride', 'Électrique', 'GPL'];
const ETATS = ['Disponible', 'En mission', 'En maintenance', 'Immobilisé', 'Réformé'];
const RES_STATUTS = ['En attente', 'Validée', 'Attribuée', 'En cours', 'Terminée', 'Rejetée'];

function report_filters(): array
{
    $g = fn($k, $d = '') => qget($k, $d);
    $type = $g('type', 'mensuel'); if (!isset(REPORT_TYPES[$type])) { $type = 'mensuel'; }
    $mois = $g('mois', date('Y-m')); if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $mois)) { $mois = date('Y-m'); }
    $annee = (int)$g('annee', date('Y')); if ($annee < 2000 || $annee > 2100) { $annee = (int)date('Y'); }
    $du = $g('du', date('Y-m-01')); if (!valid_date($du)) { $du = date('Y-m-01'); }
    $au = $g('au', date('Y-m-d')); if (!valid_date($au)) { $au = date('Y-m-d'); }
    if ($au < $du) { [$du, $au] = [$au, $du]; }
    $cat = $g('categorie'); if (!in_array($cat, array_merge(DEP_CATS, MNT_CATS), true)) { $cat = ''; }
    $st = $g('statut'); if (!in_array($st, array_merge(RES_STATUTS, ['Planifiée', 'Terminée']), true)) { $st = ''; }
    return ['type' => $type, 'mois' => $mois, 'annee' => $annee, 'du' => $du, 'au' => $au, 'vehicule_id' => (int)$g('vehicule_id', '0'), 'chauffeur_id' => (int)$g('chauffeur_id', '0'), 'statut' => $st, 'categorie' => $cat];
}

/** @return array{title:string,subtitle:string,columns:array,rows:array,summary:array,error?:string} */
function report_data(array $f): array
{
    $m = mid(); $t = $f['type'];
    $R = ['title' => REPORT_TYPES[$t], 'subtitle' => '', 'columns' => [], 'rows' => [], 'summary' => []];
    $vname = fn($id) => ($v = row('SELECT marque, modele, immatriculation FROM vehicules WHERE id=? AND ministere_id=?', [$id, $m])) ? $v['marque'] . ' ' . $v['modele'] . ' (' . $v['immatriculation'] . ')' : null;
    $period = 'Période du ' . fmt_date($f['du']) . ' au ' . fmt_date($f['au']);
    $dFrom = $f['du'] . ' 00:00:00'; $dTo = $f['au'] . ' 23:59:59';

    if ($t === 'mensuel' || $t === 'annuel') {
        if ($t === 'mensuel') { [$y, $mo] = explode('-', $f['mois']); $start = "$y-$mo-01"; $end = date('Y-m-t', strtotime($start)); $R['subtitle'] = mois_fr((int)$mo) . ' ' . $y; }
        else { $start = $f['annee'] . '-01-01'; $end = $f['annee'] . '-12-31'; $R['subtitle'] = 'Année ' . $f['annee']; }
        $s = $start . ' 00:00:00'; $e = $end . ' 23:59:59';
        $one = fn($sql, $p = []) => (float)(val($sql, $p) ?? 0);
        $kmExpr = 'COALESCE(SUM(km_retour - km_depart),0)';
        $nbDem = $one('SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND date_depart BETWEEN ? AND ?', [$m, $s, $e]);
        $nbRej = $one("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut='Rejetée' AND date_depart BETWEEN ? AND ?", [$m, $s, $e]);
        $nbMis = $one("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut IN ('Attribuée','En cours','Terminée') AND date_depart BETWEEN ? AND ?", [$m, $s, $e]);
        $nbTer = $one("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut='Terminée' AND date_depart BETWEEN ? AND ?", [$m, $s, $e]);
        $km = $one("SELECT $kmExpr FROM reservations WHERE ministere_id=? AND statut='Terminée' AND date_depart BETWEEN ? AND ?", [$m, $s, $e]);
        $dep = $one('SELECT COALESCE(SUM(montant),0) FROM depenses WHERE ministere_id=? AND date_depense BETWEEN ? AND ?', [$m, $start, $end]);
        $mnt = $one('SELECT COUNT(*) FROM maintenances WHERE ministere_id=? AND date_maintenance BETWEEN ? AND ?', [$m, $start, $end]);
        $R['summary'] = [['Demandes reçues', nb($nbDem)], ['Demandes rejetées', nb($nbRej)], ['Missions programmées/réalisées', nb($nbMis)], ['Missions terminées', nb($nbTer)],
            ['Kilomètres parcourus (missions terminées)', nb($km) . ' km'], ['Dépenses totales', fcfa($dep)], ['Interventions de maintenance', nb($mnt)]];
        if ($t === 'mensuel') {
            $R['columns'] = [['Véhicule', 4, 'text'], ['Immatriculation', 2, 'text'], ['Missions', 1.2, 'int'], ['Km parcourus', 1.5, 'int'], ['Dépenses (FCFA)', 2, 'money'], ['Maintenances (FCFA)', 2, 'money']];
            foreach (rows("SELECT v.marque, v.modele, v.immatriculation,
                (SELECT COUNT(*) FROM reservations r WHERE r.vehicule_id=v.id AND r.statut IN ('Attribuée','En cours','Terminée') AND r.date_depart BETWEEN ? AND ?) AS nb,
                (SELECT COALESCE(SUM(km_retour-km_depart),0) FROM reservations r WHERE r.vehicule_id=v.id AND r.statut='Terminée' AND r.date_depart BETWEEN ? AND ?) AS km,
                (SELECT COALESCE(SUM(montant),0) FROM depenses d WHERE d.vehicule_id=v.id AND d.date_depense BETWEEN ? AND ?) AS dep,
                (SELECT COALESCE(SUM(cout),0) FROM maintenances x WHERE x.vehicule_id=v.id AND x.date_maintenance BETWEEN ? AND ?) AS mn
                FROM vehicules v WHERE v.ministere_id=? AND v.est_archive=0 ORDER BY v.marque, v.modele", [$s, $e, $s, $e, $start, $end, $start, $end, $m]) as $v) {
                $R['rows'][] = [$v['marque'] . ' ' . $v['modele'], $v['immatriculation'], (int)$v['nb'], (int)$v['km'], (float)$v['dep'], (float)$v['mn']];
            }
        } else {
            $R['columns'] = [['Mois', 2, 'text'], ['Demandes', 1.3, 'int'], ['Missions', 1.3, 'int'], ['Km parcourus', 1.6, 'int'], ['Dépenses (FCFA)', 2, 'money'], ['Maintenances', 1.5, 'int']];
            $a = array_column(rows("SELECT MONTH(date_depart) mo, COUNT(*) dem, SUM(statut IN ('Attribuée','En cours','Terminée')) mis, COALESCE(SUM(CASE WHEN statut='Terminée' THEN km_retour-km_depart END),0) km FROM reservations WHERE ministere_id=? AND date_depart BETWEEN ? AND ? GROUP BY mo", [$m, $s, $e]), null, 'mo');
            $b = array_column(rows('SELECT MONTH(date_depense) mo, SUM(montant) dep FROM depenses WHERE ministere_id=? AND date_depense BETWEEN ? AND ? GROUP BY mo', [$m, $start, $end]), 'dep', 'mo');
            $c = array_column(rows('SELECT MONTH(date_maintenance) mo, COUNT(*) n FROM maintenances WHERE ministere_id=? AND date_maintenance BETWEEN ? AND ? GROUP BY mo', [$m, $start, $end]), 'n', 'mo');
            for ($i = 1; $i <= 12; $i++) { $R['rows'][] = [mois_fr($i), (int)($a[$i]['dem'] ?? 0), (int)($a[$i]['mis'] ?? 0), (int)($a[$i]['km'] ?? 0), (float)($b[$i] ?? 0), (int)($c[$i] ?? 0)]; }
        }
        return $R;
    }

    if ($t === 'missions' || $t === 'vehicule' || $t === 'chauffeur') {
        $w = 'r.ministere_id=? AND r.date_depart BETWEEN ? AND ?'; $p = [$m, $dFrom, $dTo];
        if ($t === 'vehicule') {
            if (!$f['vehicule_id'] || !$vname($f['vehicule_id'])) { $R['error'] = 'Sélectionnez un véhicule.'; return $R; }
            $R['subtitle'] = $vname($f['vehicule_id']) . ' — ' . $period;
        } elseif ($t === 'chauffeur') {
            $c = row('SELECT nom, prenoms, matricule FROM chauffeurs WHERE id=? AND ministere_id=?', [$f['chauffeur_id'], $m]);
            if (!$c) { $R['error'] = 'Sélectionnez un chauffeur.'; return $R; }
            $R['subtitle'] = $c['prenoms'] . ' ' . $c['nom'] . ' (' . $c['matricule'] . ') — ' . $period;
        } else { $R['subtitle'] = $period; }
        if ($f['vehicule_id']) { $w .= ' AND r.vehicule_id=?'; $p[] = $f['vehicule_id']; }
        if ($f['chauffeur_id']) { $w .= ' AND r.chauffeur_id=?'; $p[] = $f['chauffeur_id']; }
        if ($f['statut'] && in_array($f['statut'], RES_STATUTS, true)) { $w .= ' AND r.statut=?'; $p[] = $f['statut']; }
        $R['columns'] = [['Référence', 1.7, 'text'], ['Demandeur', 2.2, 'text'], ['Destination', 2.4, 'text'], ['Départ', 1.7, 'dt'], ['Retour', 1.7, 'dt'], ['Véhicule', 2.2, 'text'], ['Chauffeur', 2, 'text'], ['Km', 1, 'int'], ['Statut', 1.4, 'text']];
        $tot = 0; $ter = 0; $km = 0;
        foreach (rows("SELECT r.reference, CONCAT(d.prenoms,' ',d.nom) dem, r.destination, r.date_depart, r.date_retour, CONCAT(COALESCE(v.marque,''),' ',COALESCE(v.immatriculation,'')) veh, CONCAT(COALESCE(c.prenoms,''),' ',COALESCE(c.nom,'')) ch, (r.km_retour-r.km_depart) km, r.statut
            FROM reservations r JOIN users d ON d.id=r.demandeur_id LEFT JOIN vehicules v ON v.id=r.vehicule_id LEFT JOIN chauffeurs c ON c.id=r.chauffeur_id WHERE $w ORDER BY r.date_depart DESC", $p) as $r) {
            $tot++; if ($r['statut'] === 'Terminée') { $ter++; $km += (int)$r['km']; }
            $R['rows'][] = [$r['reference'], $r['dem'], $r['destination'], $r['date_depart'], $r['date_retour'], trim($r['veh']) ?: '—', trim($r['ch']) ?: '—', $r['km'] !== null ? (int)$r['km'] : '', $r['statut']];
        }
        $R['summary'] = [['Nombre de demandes/missions', nb($tot)], ['Missions terminées', nb($ter)], ['Kilomètres parcourus', nb($km) . ' km']];
        if ($t !== 'missions') {
            $col = $t === 'vehicule' ? 'vehicule_id' : null;
            if ($t === 'vehicule') {
                $d = (float)val('SELECT COALESCE(SUM(montant),0) FROM depenses WHERE vehicule_id=? AND date_depense BETWEEN ? AND ?', [$f['vehicule_id'], $f['du'], $f['au']]);
                $mc = (float)val('SELECT COALESCE(SUM(cout),0) FROM maintenances WHERE vehicule_id=? AND date_maintenance BETWEEN ? AND ?', [$f['vehicule_id'], $f['du'], $f['au']]);
                $R['summary'][] = ['Dépenses sur la période', fcfa($d)]; $R['summary'][] = ['dont coûts de maintenance', fcfa($mc)];
                $R['summary'][] = ['Coût moyen par km', $km > 0 ? fcfa($d / $km) . ' / km' : 'n/d'];
            }
        }
        return $R;
    }

    if ($t === 'depenses') {
        $R['subtitle'] = $period;
        $w = 'd.ministere_id=? AND d.date_depense BETWEEN ? AND ?'; $p = [$m, $f['du'], $f['au']];
        if ($f['vehicule_id']) { $w .= ' AND d.vehicule_id=?'; $p[] = $f['vehicule_id']; $R['subtitle'] .= ' — ' . ($vname($f['vehicule_id']) ?? ''); }
        if ($f['categorie'] && in_array($f['categorie'], DEP_CATS, true)) { $w .= ' AND d.categorie=?'; $p[] = $f['categorie']; $R['subtitle'] .= ' — ' . $f['categorie']; }
        $R['columns'] = [['Date', 1.4, 'date'], ['Véhicule', 3, 'text'], ['Catégorie', 2, 'text'], ['Description', 4, 'text'], ['Prestataire', 2.4, 'text'], ['Montant (FCFA)', 2, 'money']];
        $tot = 0; $byCat = [];
        foreach (rows("SELECT d.date_depense, CONCAT(v.marque,' ',v.modele,' (',v.immatriculation,')') veh, d.categorie, d.description, d.prestataire, d.montant FROM depenses d JOIN vehicules v ON v.id=d.vehicule_id WHERE $w ORDER BY d.date_depense DESC, d.id DESC", $p) as $r) {
            $R['rows'][] = [$r['date_depense'], $r['veh'], $r['categorie'], $r['description'], $r['prestataire'], (float)$r['montant']];
            $tot += (float)$r['montant']; $byCat[$r['categorie']] = ($byCat[$r['categorie']] ?? 0) + (float)$r['montant'];
        }
        $R['summary'][] = ['Total des dépenses', fcfa($tot)]; $R['summary'][] = ['Nombre d\'écritures', nb(count($R['rows']))];
        arsort($byCat); foreach ($byCat as $c => $v) { $R['summary'][] = ['— ' . $c, fcfa($v)]; }
        return $R;
    }

    if ($t === 'maintenances') {
        $R['subtitle'] = $period;
        $w = 'x.ministere_id=? AND x.date_maintenance BETWEEN ? AND ?'; $p = [$m, $f['du'], $f['au']];
        if ($f['vehicule_id']) { $w .= ' AND x.vehicule_id=?'; $p[] = $f['vehicule_id']; }
        if ($f['categorie'] && in_array($f['categorie'], MNT_CATS, true)) { $w .= ' AND x.categorie=?'; $p[] = $f['categorie']; }
        if (in_array($f['statut'], ['Planifiée', 'En cours', 'Terminée'], true)) { $w .= ' AND x.statut=?'; $p[] = $f['statut']; }
        $R['columns'] = [['Date', 1.4, 'date'], ['Véhicule', 3, 'text'], ['Type', 1.5, 'text'], ['Catégorie', 2.2, 'text'], ['Description', 4, 'text'], ['Prestataire', 2.2, 'text'], ['Statut', 1.4, 'text'], ['Coût (FCFA)', 1.8, 'money'], ['Prochaine échéance', 1.8, 'date']];
        $tot = 0;
        foreach (rows("SELECT x.date_maintenance, CONCAT(v.marque,' ',v.modele,' (',v.immatriculation,')') veh, x.type, x.categorie, x.description, x.prestataire, x.statut, x.cout, x.prochaine_echeance FROM maintenances x JOIN vehicules v ON v.id=x.vehicule_id WHERE $w ORDER BY x.date_maintenance DESC", $p) as $r) {
            $R['rows'][] = [$r['date_maintenance'], $r['veh'], $r['type'], $r['categorie'], $r['description'], $r['prestataire'], $r['statut'], (float)$r['cout'], $r['prochaine_echeance']]; $tot += (float)$r['cout'];
        }
        $R['summary'] = [['Interventions', nb(count($R['rows']))], ['Coût total', fcfa($tot)]];
        return $R;
    }

    // immobilisations
    $R['subtitle'] = 'Situation au ' . fmt_date(date('Y-m-d'));
    $R['columns'] = [['Véhicule', 3.4, 'text'], ['Immatriculation', 2, 'text'], ['État', 1.8, 'text'], ['Depuis le', 1.6, 'date'], ['Intervention en cours', 2.8, 'text'], ['Observations', 4.4, 'text']];
    foreach (rows("SELECT v.marque, v.modele, v.immatriculation, v.etat, v.updated_at, v.est_archive, v.observations,
        (SELECT CONCAT(x.categorie,' (depuis le ',DATE_FORMAT(x.date_maintenance,'%d/%m/%Y'),')') FROM maintenances x WHERE x.vehicule_id=v.id AND x.statut='En cours' ORDER BY x.date_maintenance DESC LIMIT 1) mnt
        FROM vehicules v WHERE v.ministere_id=? AND (v.etat IN ('En maintenance','Immobilisé','Réformé') OR v.est_archive=1) ORDER BY v.etat, v.marque", [$m]) as $r) {
        $R['rows'][] = [$r['marque'] . ' ' . $r['modele'], $r['immatriculation'], $r['etat'] . ($r['est_archive'] ? ' (archivé)' : ''), $r['updated_at'], $r['mnt'] ?? '—', $r['observations'] ?? ''];
    }
    $R['summary'] = [['Véhicules indisponibles', nb(count($R['rows']))], ['Parc total actif', nb((int)val('SELECT COUNT(*) FROM vehicules WHERE ministere_id=? AND est_archive=0', [$m]))]];
    return $R;
}

function report_cell(mixed $v, string $type, bool $raw = false): string
{
    if ($v === null || $v === '') { return $type === 'text' ? '' : ($raw ? '' : '—'); }
    return match ($type) {
        'date' => fmt_date((string)$v), 'dt' => fmt_dt((string)$v),
        'money' => $raw ? (string)(0 + $v) : nb($v), 'int' => $raw ? (string)(0 + $v) : nb($v),
        default => (string)$v,
    };
}

// =================================================================== Exports
function pdf_txt(string $s): string { return mb_convert_encoding($s, 'Windows-1252', 'UTF-8'); }

function report_pdf(array $R, array $f): never
{
    require_once APP_ROOT . '/lib/fpdf/fpdf.php';
    $min = ministere();
    $pdf = new class('L', 'mm', 'A4') extends FPDF {
        public string $ministere = ''; public string $rtitle = ''; public string $by = '';
        function Header(): void {
            $w = $this->GetPageWidth() / 3;
            $this->SetFillColor(0, 104, 40); $this->Rect(0, 0, $w, 3.2, 'F');
            $this->SetFillColor(255, 190, 0); $this->Rect($w, 0, $w, 3.2, 'F');
            $this->SetFillColor(235, 0, 0); $this->Rect($w * 2, 0, $w, 3.2, 'F');
            $this->SetY(7); $this->SetFont('Helvetica', 'B', 9); $this->SetTextColor(0, 104, 40);
            $this->Cell(0, 5, pdf_txt('RÉPUBLIQUE DU BÉNIN — ' . mb_strtoupper($this->ministere)), 0, 1);
            $this->SetFont('Helvetica', '', 8); $this->SetTextColor(90, 90, 90);
            $this->Cell(0, 4, pdf_txt('eFlotte Bénin — Gestion du parc automobile'), 0, 1);
            $this->Ln(2);
        }
        function Footer(): void {
            $this->SetY(-12); $this->SetFont('Helvetica', '', 7.5); $this->SetTextColor(110, 110, 110);
            $this->Cell(0, 5, pdf_txt('Généré le ' . date('d/m/Y à H:i') . ' par ' . $this->by . ' — Document administratif'), 0, 0, 'L');
            $this->Cell(0, 5, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'R');
        }
    };
    $pdf->ministere = $min['nom']; $pdf->by = trim((user()['prenoms'] ?? '') . ' ' . (user()['nom'] ?? ''));
    $pdf->AliasNbPages(); $pdf->SetMargins(10, 10, 10); $pdf->SetAutoPageBreak(false); $pdf->AddPage();
    $pdf->SetFont('Helvetica', 'B', 15); $pdf->SetTextColor(20, 20, 20);
    $pdf->Cell(0, 8, pdf_txt($R['title']), 0, 1);
    $pdf->SetFont('Helvetica', '', 10); $pdf->SetTextColor(80, 80, 80);
    $pdf->Cell(0, 5, pdf_txt($R['subtitle']), 0, 1); $pdf->Ln(3);

    // Synthèse
    if ($R['summary']) {
        $pdf->SetFont('Helvetica', '', 9); $pdf->SetFillColor(240, 247, 242);
        foreach ($R['summary'] as [$k, $v]) {
            $pdf->SetTextColor(70, 70, 70); $pdf->Cell(95, 6, pdf_txt($k), 0, 0, 'L', true);
            $pdf->SetFont('Helvetica', 'B', 9); $pdf->SetTextColor(0, 80, 30); $pdf->Cell(60, 6, pdf_txt((string)$v), 0, 1, 'L', true); $pdf->SetFont('Helvetica', '', 9);
            $pdf->Ln(0.6);
        }
        $pdf->Ln(3);
    }
    // Tableau
    $usable = $pdf->GetPageWidth() - 20; $sum = array_sum(array_column($R['columns'], 1)); $ws = array_map(fn($c) => $c[1] / $sum * $usable, $R['columns']);
    $fit = function (string $s, float $w) use ($pdf): string {
        $s = pdf_txt($s); if ($pdf->GetStringWidth($s) <= $w - 2) { return $s; }
        while ($s !== '' && $pdf->GetStringWidth($s . '...') > $w - 2) { $s = substr($s, 0, -1); }
        return rtrim($s) . '...';
    };
    $head = function () use ($pdf, $R, $ws) {
        $pdf->SetFont('Helvetica', 'B', 8); $pdf->SetFillColor(0, 104, 40); $pdf->SetTextColor(255, 255, 255);
        foreach ($R['columns'] as $i => $c) { $pdf->Cell($ws[$i], 7, pdf_txt($c[0]), 0, 0, in_array($c[2], ['int', 'money']) ? 'R' : 'L', true); }
        $pdf->Ln(); $pdf->SetFont('Helvetica', '', 8); $pdf->SetTextColor(30, 30, 30);
    };
    $head(); $zebra = false;
    if (!$R['rows']) { $pdf->Ln(2); $pdf->SetFont('Helvetica', 'I', 9); $pdf->Cell(0, 8, pdf_txt('Aucune donnée pour les critères sélectionnés.'), 0, 1); }
    foreach ($R['rows'] as $row) {
        if ($pdf->GetY() > $pdf->GetPageHeight() - 20) { $pdf->AddPage(); $head(); }
        $pdf->SetFillColor(246, 248, 247);
        foreach ($R['columns'] as $i => $c) { $pdf->Cell($ws[$i], 6.2, $fit(report_cell($row[$i] ?? '', $c[2]), $ws[$i]), 0, 0, in_array($c[2], ['int', 'money']) ? 'R' : 'L', $zebra); }
        $pdf->Ln(); $zebra = !$zebra;
    }
    $pdf->SetDrawColor(0, 104, 40); $pdf->Line(10, $pdf->GetY(), $pdf->GetPageWidth() - 10, $pdf->GetY());
    $name = 'rapport_' . $f['type'] . '_' . date('Ymd_His') . '.pdf';
    header('Content-Type: application/pdf'); header('Content-Disposition: attachment; filename="' . $name . '"'); header('Cache-Control: private, no-store');
    $pdf->Output('I', $name);
    exit;
}

function report_csv(array $R, array $f): never
{
    $name = 'rapport_' . $f['type'] . '_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="' . $name . '"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF");
    fputcsv($o, [$R['title'] . ' — ' . $R['subtitle']], ';', '"', '\\');
    fputcsv($o, array_column($R['columns'], 0), ';', '"', '\\');
    foreach ($R['rows'] as $row) { $line = []; foreach ($R['columns'] as $i => $c) { $line[] = report_cell($row[$i] ?? '', $c[2], true); } fputcsv($o, $line, ';', '"', '\\'); }
    fputcsv($o, [], ';', '"', '\\');
    foreach ($R['summary'] as $s) { fputcsv($o, $s, ';', '"', '\\'); }
    fclose($o); exit;
}

/** Export Excel (.xlsx) natif, sans dépendance externe (ZipArchive + XML) */
function report_xlsx(array $R, array $f): never
{
    $esc = fn($s) => htmlspecialchars((string)$s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
    $col = function (int $i): string { $s = ''; for ($i++; $i > 0; $i = intdiv($i - 1, 26)) { $s = chr(65 + ($i - 1) % 26) . $s; } return $s; };
    $cell = function (int $c, int $r, mixed $v, bool $numeric, int $style = 0) use ($esc, $col): string {
        $ref = $col($c) . $r; $st = $style ? ' s="' . $style . '"' : '';
        if ($v === '' || $v === null) { return '<c r="' . $ref . '"' . $st . '/>'; }
        return $numeric && is_numeric($v) ? '<c r="' . $ref . '"' . $st . '><v>' . $v . '</v></c>' : '<c r="' . $ref . '" t="inlineStr"' . $st . '><is><t xml:space="preserve">' . $esc($v) . '</t></is></c>';
    };
    $r = 1; $x = '<row r="1">' . $cell(0, 1, $R['title'] . ' — ' . $R['subtitle'], false, 2) . '</row>'; $r = 3;
    $x .= '<row r="3">'; foreach ($R['columns'] as $i => $c) { $x .= $cell($i, 3, $c[0], false, 1); } $x .= '</row>'; $r = 4;
    foreach ($R['rows'] as $row) {
        $x .= '<row r="' . $r . '">';
        foreach ($R['columns'] as $i => $c) { $num = in_array($c[2], ['int', 'money'], true); $x .= $cell($i, $r, report_cell($row[$i] ?? '', $c[2], $num), $num); }
        $x .= '</row>'; $r++;
    }
    $r++;
    foreach ($R['summary'] as $s) { $x .= '<row r="' . $r . '">' . $cell(0, $r, $s[0], false, 1) . $cell(1, $r, $s[1], false) . '</row>'; $r++; }
    $widths = ''; foreach ($R['columns'] as $i => $c) { $widths .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . max(12, (int)($c[1] * 9)) . '" customWidth="1"/>'; }
    $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><cols>' . $widths . '</cols><sheetData>' . $x . '</sheetData></worksheet>';
    if (!class_exists('ZipArchive')) { report_csv($R, $f); }
    $tmp = tempnam(sys_get_temp_dir(), 'efx'); $z = new ZipArchive();
    if ($z->open($tmp, ZipArchive::OVERWRITE) !== true) { report_csv($R, $f); }
    $z->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>');
    $z->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
    $z->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Rapport" sheetId="1" r:id="rId1"/></sheets></workbook>');
    $z->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
    $z->addFromString('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="3"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="13"/><color rgb="FF006828"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF006828"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="3"><xf/><xf fontId="1" fillId="2" applyFont="1" applyFill="1"/><xf fontId="2" applyFont="1"/></cellXfs></styleSheet>');
    $z->addFromString('xl/worksheets/sheet1.xml', $sheet); $z->close();
    $name = 'rapport_' . $f['type'] . '_' . date('Ymd_His') . '.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); header('Content-Disposition: attachment; filename="' . $name . '"'); header('Content-Length: ' . filesize($tmp));
    readfile($tmp); @unlink($tmp); exit;
}
