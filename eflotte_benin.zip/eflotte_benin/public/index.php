<?php
declare(strict_types=1);

if (!defined('EFLOTTE_ENTRY')) {            // accès direct à /public/index.php → retour au point d'entrée officiel
    header('Location: ../index.php');
    exit;
}
require dirname(__DIR__) . '/app/bootstrap.php';
require APP_ROOT . '/app/views/layout.php';

const MODULES = ['auth', 'dashboard', 'vehicules', 'chauffeurs', 'reservations', 'maintenances', 'depenses', 'assurances', 'disponibilites',
                 'rapports', 'audit', 'notifications', 'users', 'services', 'parametres', 'sauvegardes', 'api', 'documents'];

$P = preg_replace('/[^a-z_]/', '', qget('p', 'dashboard'));
$A = preg_replace('/[^a-z_]/', '', qget('a', 'index'));
$GLOBALS['P'] = $P; $GLOBALS['A'] = $A;

if (!in_array($P, MODULES, true)) {
    http_response_code(404);
    page_start('Page introuvable');
    echo '<div class="mx-auto mt-20 max-w-md text-center"><h2 class="text-xl font-bold">Page introuvable</h2><p class="mt-2 text-sm text-slate-500">Le module demandé n\'existe pas.</p><a class="mt-4 inline-block text-brand underline" href="' . e(url('dashboard')) . '">Retour à l\'accueil</a></div>';
    page_end();
    exit;
}

try { db(); }
catch (PDOException $e) {
    error_log('[eFlotte] connexion BD : ' . $e->getMessage());
    http_response_code(503);
    echo head_html('Installation requise') . '<body class="grid min-h-screen place-items-center bg-slate-50 p-6 font-sans"><div class="max-w-lg rounded-2xl border border-slate-200 bg-white p-8 shadow-sm">' . tricolor()
       . '<h1 class="mt-4 text-xl font-bold text-brand">Base de données inaccessible</h1><p class="mt-2 text-sm text-slate-600">Vérifiez que MySQL est démarré dans XAMPP et que la base est installée.</p>'
       . (is_file(APP_ROOT . '/setup.php') ? '<p class="mt-4"><a class="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white" href="' . e(ROOT_URL) . '/setup.php">Lancer l\'installation</a></p>' : '') . '</div></body></html>';
    exit;
}

if (is_post()) { csrf_verify(); }

$isLoginPage = ($P === 'auth' && $A === 'login');
if (!$isLoginPage && !user()) {
    if ($P === 'api') { json_out(['error' => 'Non authentifié'], 401); }
    redirect(url('auth', 'login'));
}
if (user()) { push_alert_notifications(); }

require APP_ROOT . '/app/modules/' . $P . '.php';
