<?php
declare(strict_types=1);

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = $GLOBALS['CFG']['db'];
        $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset=utf8mb4", $c['user'], (string)$c['pass'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec("SET time_zone = '+01:00'");   // heure légale du Bénin (UTC+1)
    }
    return $pdo;
}
function q(string $sql, array $p = []): PDOStatement { $s = db()->prepare($sql); $s->execute($p); return $s; }
function rows(string $sql, array $p = []): array { return q($sql, $p)->fetchAll(); }
function row(string $sql, array $p = []): ?array { $r = q($sql, $p)->fetch(); return $r ?: null; }
function val(string $sql, array $p = []) { $r = q($sql, $p)->fetchColumn(); return $r === false ? null : $r; }
function insert(string $table, array $data): int
{
    $cols = array_keys($data);
    q('INSERT INTO `' . $table . '` (`' . implode('`,`', $cols) . '`) VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', array_values($data));
    return (int)db()->lastInsertId();
}
function update(string $table, int $id, array $data): void
{
    $set = implode(',', array_map(fn($c) => "`$c`=?", array_keys($data)));
    q("UPDATE `$table` SET $set WHERE id=?", [...array_values($data), $id]);
}
/** Paramètres applicatifs (table parametres), mis en cache pour la requête */
function param(string $key, $default = null)
{
    static $cache = null;
    if ($cache === null) { try { $cache = array_column(rows('SELECT cle, valeur FROM parametres'), 'valeur', 'cle'); } catch (Throwable) { $cache = []; } }
    return $cache[$key] ?? $default;
}
function param_reset(): void { /* le cache est par requête ; rien à faire */ }
function ministere(): array { static $m = null; return $m ??= (row('SELECT * FROM ministeres WHERE id=?', [mid()]) ?? ['nom' => '', 'sigle' => '']); }
