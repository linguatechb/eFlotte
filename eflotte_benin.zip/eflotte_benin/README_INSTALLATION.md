# eFlotte Bénin — Guide d'installation (XAMPP / Windows)

## 1. Prérequis
- XAMPP avec **PHP 8.1+** et **MySQL 8 / MariaDB 10.4+** (modules Apache + MySQL démarrés).
- Extensions PHP (activées par défaut dans XAMPP) : `pdo_mysql`, `mbstring`, `fileinfo`, `gd`, `zip`.
- Une connexion Internet pour charger Tailwind CSS, Font Awesome, Chart.js et la police (CDN imposés par le cahier des charges).

## 2. Installation
1. Décompresser l'archive pour obtenir **`C:\xampp\htdocs\eflotte_benin`** (le fichier `index.php` doit se trouver directement dans ce dossier).
2. Démarrer **Apache** et **MySQL** dans le panneau XAMPP.
3. Ouvrir **http://localhost/eflotte_benin/setup.php** puis cliquer sur *Installer* (choisir « données de démonstration »).
   - Variante phpMyAdmin : importer `database/schema.sql` puis `database/seed.sql`.
   - Variante ligne de commande : `C:\xampp\php\php.exe setup.php` (option `--no-demo` pour une instance vierge).
4. Accès direct à l'application : **http://localhost/eflotte_benin/index.php**
5. Supprimer `setup.php` après installation (il se verrouille déjà via `storage/installed.lock`).

Si MySQL n'est pas en `root` sans mot de passe, copier `config/config.php` en `config/config.local.php` et ajuster la section `db`.

## 3. Comptes de démonstration (affichés aussi sur la page de connexion)
| Profil | E-mail | Mot de passe |
|---|---|---|
| Agent — Demandeur (DPE) | agent@eflotte.bj | Agent@2026 |
| Validateur — Directeur (DPE) | validateur@eflotte.bj | Valid@2026 |
| Gestionnaire de flotte | gestionnaire@eflotte.bj | Flotte@2026 |
| Super-Admin | admin@eflotte.bj | Admin@2026 |
| Compléments : agent2@ (DAF), agent3@ (DPE) → Agent@2026 ; validateur2@ (DAF) → Valid@2026 |

Pour la production : choisir l'installation vierge, changer les mots de passe, et désactiver l'affichage des comptes (Paramètres → `afficher_comptes_demo`).

## 4. Sécurité / exploitation
- `.htaccess` interdit l'accès HTTP direct à `app/`, `config/`, `database/`, `storage/`, `lib/`, `tests/` ; `uploads/ordres_mission` et `uploads/justificatifs` sont fermés (téléchargement uniquement via l'application, après contrôle des droits).
- **Recommandé en production** : déplacer les documents et sauvegardes hors de `htdocs` via `config/config.local.php` :
  `'private_upload_path' => 'C:/eflotte_data/uploads', 'backup_path' => 'C:/eflotte_data/backups'`.
- Taille des PDF : 10 Mo par défaut (Paramètres). Vérifier `upload_max_filesize` et `post_max_size` ≥ 12M dans `php.ini` si Apache n'applique pas le `.htaccess`.
- Sauvegardes : menu *Sauvegardes* (Super-Admin) — base + ordres de mission + justificatifs + photos, empreinte SHA-256, restauration vérifiée, conservation configurable.
- Une instance = un ministère = une base. Pour un autre ministère, dupliquer le dossier, créer une autre base et renseigner `config.local.php`.

## 5. Tests automatisés
```
php -S 127.0.0.1:8099 -t . tests/router.php      (dans un terminal)
php tests/run_tests.php                           (192 contrôles, sur une instance de démonstration)
php tests/crawl_links.php                         (détection de liens cassés par profil)
```
