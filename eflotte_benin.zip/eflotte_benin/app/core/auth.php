<?php
declare(strict_types=1);

/** Matrice des autorisations — appliquée CÔTÉ SERVEUR dans chaque module. */
const PERMS = [
    'vehicules.view'        => ['agent', 'validateur', 'gestionnaire', 'superadmin'],
    'vehicules.manage'      => ['gestionnaire'],
    'chauffeurs.view'       => ['validateur', 'gestionnaire', 'superadmin'],
    'chauffeurs.manage'     => ['gestionnaire'],
    'disponibilites.view'   => ['agent', 'validateur', 'gestionnaire', 'superadmin'],
    'reservations.create'   => ['agent'],
    'reservations.validate' => ['validateur'],
    'reservations.assign'   => ['gestionnaire'],
    'reservations.execute'  => ['gestionnaire'],
    'maintenances.view'     => ['gestionnaire', 'superadmin'],
    'maintenances.manage'   => ['gestionnaire'],
    'depenses.view'         => ['gestionnaire', 'superadmin'],
    'depenses.manage'       => ['gestionnaire'],
    'assurances.view'       => ['gestionnaire', 'superadmin'],
    'assurances.manage'     => ['gestionnaire'],
    'rapports.view'         => ['gestionnaire', 'superadmin'],
    'audit.view'            => ['gestionnaire', 'superadmin'],
    'parametres.operationnel' => ['gestionnaire', 'superadmin'],
    'parametres.technique'  => ['superadmin'],
    'users.manage'          => ['superadmin'],
    'sauvegardes.manage'    => ['superadmin'],
];

const ROLE_INFO = [
    'agent' => ['Agent — Demandeur', 'Cadre / Agent administratif demandeur de mission',
        ['Consulter les véhicules et leurs disponibilités', 'Soumettre une demande de réservation', 'Importer l\'ordre de mission signé (PDF)', 'Consulter ses demandes et suivre le statut de ses missions', 'Consulter son historique']],
    'validateur' => ['Validateur — Directeur / Responsable hiérarchique', 'Directeur / Responsable hiérarchique',
        ['Consulter les demandes relevant de son périmètre (service)', 'Examiner motifs, destinations et ordres de mission PDF', 'Valider ou rejeter avec commentaire', 'Consulter l\'historique des décisions']],
    'gestionnaire' => ['Gestionnaire de flotte — Administration ministérielle', 'Chef du Parc Automobile / Gestionnaire de Flotte',
        ['Gérer véhicules et chauffeurs', 'Consulter toutes les demandes du ministère et les ordres de mission', 'Attribuer véhicules et chauffeurs, démarrer et clôturer les missions', 'Gérer maintenances, dépenses, assurances et visites techniques', 'Produire les rapports, consulter le journal d\'audit, gérer les paramètres opérationnels']],
    'superadmin' => ['Super-Admin', 'Administrateur Système & Sécurité de l\'Instance',
        ['Administrer l\'instance ministérielle : utilisateurs, rôles, services', 'Configurer les paramètres généraux et techniques', 'Superviser les données de l\'instance (lecture)', 'Consulter les journaux d\'activité', 'Gérer les sauvegardes et restaurations']],
];

function user(bool $refresh = false): ?array
{
    static $cache = null, $loaded = false;
    if ($refresh) { $loaded = false; }
    if ($loaded) { return $cache; }
    $loaded = true; $cache = null;
    if (empty($_SESSION['uid'])) { return null; }
    $u = row('SELECT u.*, r.code AS role, r.libelle AS role_libelle, s.nom AS service_nom FROM users u JOIN roles r ON r.id=u.role_id LEFT JOIN services s ON s.id=u.service_id WHERE u.id=? AND u.actif=1', [$_SESSION['uid']]);
    if (!$u) { session_unset(); return null; }
    $timeout = max(5, (int)param('session_timeout_min', 30)) * 60;
    if (time() - ($_SESSION['last'] ?? time()) > $timeout) {
        audit('auth.session_expiree', 'users', $u['id'], null, null, $u);
        session_unset(); session_regenerate_id(true);
        flash('warning', 'Votre session a expiré par inactivité. Veuillez vous reconnecter.');
        return null;
    }
    $_SESSION['last'] = time();
    return $cache = $u;
}
function uid(): int { return (int)(user()['id'] ?? 0); }
function mid(): int { return (int)(user()['ministere_id'] ?? ($GLOBALS['MID_OVERRIDE'] ?? 1)); }
function role(): string { return (string)(user()['role'] ?? ''); }
function can(string $perm): bool { return in_array(role(), PERMS[$perm] ?? [], true); }
function require_perm(string $perm): void
{
    if (!can($perm)) {
        audit('securite.acces_refuse', null, null, null, ['permission' => $perm, 'url' => $_SERVER['REQUEST_URI'] ?? '']);
        http_response_code(403);
        page_start('Accès refusé');
        echo '<div class="mx-auto max-w-lg rounded-xl border border-red-200 bg-white p-8 text-center"><i class="fa-solid fa-lock text-3xl text-red-600"></i><h2 class="mt-3 text-lg font-semibold">Accès refusé</h2><p class="mt-1 text-sm text-slate-600">Votre profil (' . e(user()['role_libelle'] ?? '') . ') n\'est pas autorisé à effectuer cette opération.</p><div class="mt-4">' . link_btn(url('dashboard'), 'Retour au tableau de bord') . '</div></div>';
        page_end();
        exit;
    }
}

function client_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45); }

/** @return array{0:bool,1:string} */
function attempt_login(string $email, string $password): array
{
    $ip = client_ip();
    $max = max(3, (int)param('login_max_attempts', 5));
    $fails = (int)val('SELECT COUNT(*) FROM login_attempts WHERE succes=0 AND created_at > (NOW() - INTERVAL 15 MINUTE) AND (ip=? OR email=?)', [$ip, $email]);
    if ($fails >= $max) {
        audit('auth.connexion_bloquee', 'users', null, null, ['email' => $email], null);
        return [false, 'Trop de tentatives échouées. Compte temporairement verrouillé pendant 15 minutes.'];
    }
    $u = row('SELECT u.*, r.code AS role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.email=?', [$email]);
    $ok = $u && $u['actif'] && password_verify($password, $u['password_hash']);
    if (!$u) { password_verify($password, '$2y$10$abcdefghijklmnopqrstuuMq6x2e3o4G9m0Q5Zl8wq1sYk2T3u4vK'); } // temps constant
    q('INSERT INTO login_attempts (email, ip, succes) VALUES (?,?,?)', [$email, $ip, $ok ? 1 : 0]);
    if (!$ok) {
        audit('auth.connexion_echec', 'users', $u['id'] ?? null, null, ['email' => $email], $u ?: null);
        return [false, ($u && !$u['actif']) ? 'Ce compte est désactivé. Contactez l\'administrateur.' : 'Identifiants incorrects.'];
    }
    session_regenerate_id(true);
    $_SESSION = ['uid' => (int)$u['id'], 'last' => time()];
    csrf_token();
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) { q('UPDATE users SET password_hash=? WHERE id=?', [password_hash($password, PASSWORD_DEFAULT), $u['id']]); }
    q('UPDATE users SET derniere_connexion=NOW() WHERE id=?', [$u['id']]);
    q('DELETE FROM login_attempts WHERE email=? AND succes=0', [$email]);
    user(true);
    audit('auth.connexion', 'users', $u['id']);
    return [true, ''];
}
function do_logout(): void
{
    if (user()) { audit('auth.deconnexion', 'users', uid()); }
    $_SESSION = [];
    if (ini_get('session.use_cookies')) { $p = session_get_cookie_params(); setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']); }
    session_destroy();
    session_start(); session_regenerate_id(true);
}
