<?php
declare(strict_types=1);

/**
 * Enregistre un fichier téléversé de façon sûre.
 * Contrôles : erreur PHP, taille, vérification MIME réelle (finfo), signature, extension imposée, renommage aléatoire.
 * @return array{0:string,1:string} [nom stocké, nom d'origine]
 */
function save_upload(array $f, string $kind, string $dir, ?int $maxBytes = null): array
{
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $m = [UPLOAD_ERR_INI_SIZE => 'Le fichier dépasse la taille maximale autorisée par le serveur.', UPLOAD_ERR_FORM_SIZE => 'Le fichier est trop volumineux.', UPLOAD_ERR_NO_FILE => 'Aucun fichier n\'a été envoyé.'];
        throw new RuntimeException($m[$f['error'] ?? 4] ?? 'Échec du téléversement du fichier.');
    }
    if (!is_uploaded_file($f['tmp_name']) && !defined('EFLOTTE_TESTING')) { throw new RuntimeException('Fichier invalide.'); }
    $max = $maxBytes ?? max(1, (int)param('upload_max_mb', 10)) * 1048576;
    if ($f['size'] > $max) { throw new RuntimeException('Le fichier dépasse la taille maximale autorisée (' . round($max / 1048576) . ' Mo).'); }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $orig = mb_substr(preg_replace('/[^\p{L}\p{N}\.\-_ ()]/u', '_', basename((string)$f['name'])), 0, 180);

    if ($kind === 'pdf') {
        if ($mime !== 'application/pdf' || strtolower(pathinfo($orig, PATHINFO_EXTENSION)) !== 'pdf') { throw new RuntimeException('Seuls les fichiers PDF sont acceptés.'); }
        $fh = fopen($f['tmp_name'], 'rb'); $head = fread($fh, 5); fclose($fh);
        if ($head !== '%PDF-') { throw new RuntimeException('Le fichier n\'est pas un PDF valide.'); }
        $ext = 'pdf';
    } elseif ($kind === 'image') {
        $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($allowed[$mime]) || @getimagesize($f['tmp_name']) === false) { throw new RuntimeException('Image refusée : formats autorisés JPG, PNG ou WEBP.'); }
        $ext = $allowed[$mime];
    } else { // justificatif : PDF ou image
        $allowed = ['application/pdf' => 'pdf', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        if (!isset($allowed[$mime])) { throw new RuntimeException('Justificatif refusé : PDF, JPG, PNG ou WEBP uniquement.'); }
        $ext = $allowed[$mime];
    }
    if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    $dest = rtrim($dir, '/\\') . '/' . $name;

    if ($kind === 'image' && function_exists('imagecreatefromstring')) {
        // Ré-encodage : supprime toute charge utile cachée (polyglottes, métadonnées)
        $img = @imagecreatefromstring((string)file_get_contents($f['tmp_name']));
        if ($img === false) { throw new RuntimeException('Image illisible ou corrompue.'); }
        $max_w = 1600; $w = imagesx($img); $h = imagesy($img);
        if ($w > $max_w) { $img = imagescale($img, $max_w); }
        $ok = match ($ext) { 'jpg' => imagejpeg($img, $dest, 86), 'png' => imagepng($img, $dest, 6), default => imagewebp($img, $dest, 85) };
        imagedestroy($img);
        if (!$ok) { throw new RuntimeException('Impossible d\'enregistrer l\'image.'); }
    } else {
        $moved = defined('EFLOTTE_TESTING') ? copy($f['tmp_name'], $dest) : move_uploaded_file($f['tmp_name'], $dest);
        if (!$moved) { throw new RuntimeException('Impossible d\'enregistrer le fichier.'); }
    }
    @chmod($dest, 0644);
    return [$name, $orig];
}
function has_upload(string $key): bool { return isset($_FILES[$key]) && ($_FILES[$key]['error'] ?? 4) !== UPLOAD_ERR_NO_FILE; }
/** Suppression sécurisée : le nom est contraint à [a-f0-9]{32}.ext et au dossier cible */
function delete_file(?string $name, string $dir): void
{
    if (!$name || !preg_match('/^[a-f0-9]{32}\.(pdf|jpg|png|webp)$/', $name)) { return; }
    $p = rtrim($dir, '/\\') . '/' . $name;
    if (is_file($p)) { @unlink($p); }
}
function stream_file(string $path, string $downloadName, bool $inline = true): never
{
    if (!is_file($path)) { http_response_code(404); exit('Document introuvable.'); }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path) ?: 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . str_replace('"', '', $downloadName) . '"');
    header('Cache-Control: private, no-store');
    readfile($path);
    exit;
}
