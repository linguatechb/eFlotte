<?php
declare(strict_types=1);

require_perm('sauvegardes.manage');
if ($A === 'create' && is_post()) {
    try { $b = backup_create('manuelle'); $purged = backup_purge(); audit('sauvegarde.creation', 'sauvegardes', $b['name'], null, ['taille' => $b['size'], 'tables' => count($b['manifest']['tables']), 'fichiers' => $b['manifest']['files'], 'purgees' => $purged]);
        flash('success', 'Sauvegarde créée : ' . e($b['name']) . ' (' . round($b['size'] / 1024) . ' Ko).' . ($purged ? ' ' . $purged . ' ancienne(s) archive(s) purgée(s) selon la politique de conservation.' : '')); }
    catch (Throwable $e) { error_log('[eFlotte][backup] ' . $e->getMessage()); flash('error', 'Échec de la sauvegarde : ' . e($e->getMessage())); }
    redirect(url('sauvegardes'));
}
if ($A === 'download') {
    $n = qget('f'); if (!backup_valid_name($n) || !is_file(BACKUP_PATH . '/' . $n)) { http_response_code(404); exit('Sauvegarde introuvable.'); }
    audit('sauvegarde.telechargement', 'sauvegardes', $n); stream_file(BACKUP_PATH . '/' . $n, $n, false);
}
if ($A === 'delete' && is_post()) {
    $n = post('f'); if (!backup_valid_name($n) || !is_file(BACKUP_PATH . '/' . $n)) { http_response_code(404); exit('Introuvable.'); }
    unlink(BACKUP_PATH . '/' . $n); audit('sauvegarde.suppression', 'sauvegardes', $n); flash('success', 'Sauvegarde supprimée.'); redirect(url('sauvegardes'));
}
if ($A === 'restore' && is_post()) {
    $path = null; $tmp = null;
    if (backup_valid_name(post('f')) && is_file(BACKUP_PATH . '/' . post('f'))) { $path = BACKUP_PATH . '/' . post('f'); }
    elseif (has_upload('archive') && $_FILES['archive']['error'] === UPLOAD_ERR_OK) {
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['archive']['tmp_name']);
        if ($mime !== 'application/zip' || strtolower(pathinfo($_FILES['archive']['name'], PATHINFO_EXTENSION)) !== 'zip') { flash('error', 'Archive ZIP de sauvegarde eFlotte requise.'); redirect(url('sauvegardes')); }
        $path = $tmp = $_FILES['archive']['tmp_name'];
    }
    if (!$path) { flash('error', 'Aucune archive sélectionnée.'); redirect(url('sauvegardes')); }
    if (post('confirm_text') !== 'RESTAURER') { flash('error', 'Saisissez RESTAURER pour confirmer cette opération irréversible.'); redirect(url('sauvegardes')); }
    $who = user();
    try {
        $r = backup_restore($path);
        // La session actuelle peut ne plus correspondre aux données restaurées : on repart d'une session propre
        $_SESSION = []; session_regenerate_id(true); user(true);
        audit('sauvegarde.restauration', 'sauvegardes', basename((string)($_FILES['archive']['name'] ?? post('f'))), null, ['date_sauvegarde' => $r['date'], 'tables' => $r['tables'], 'fichiers' => $r['files'], 'ecarts' => $r['mismatch'], 'sauvegarde_securite' => $r['safety']], $who);
        flash($r['mismatch'] ? 'warning' : 'success', 'Restauration terminée (sauvegarde du ' . e(fmt_dt($r['date'])) . ') : ' . $r['tables'] . ' tables, ' . $r['files'] . ' fichiers. Vérification des comptages : ' . ($r['mismatch'] ? 'ÉCARTS sur ' . e(implode(', ', $r['mismatch'])) : 'conforme') . '. Reconnectez-vous.');
        redirect(url('auth', 'login'));
    } catch (RuntimeException $e) { flash('error', e($e->getMessage())); redirect(url('sauvegardes')); }
}
$list = backup_list(); $days = (int)param('backup_retention_days', 30);
page_start('Sauvegarde et restauration', ['actions' => '<form method="post" action="' . e(url('sauvegardes', 'create')) . '">' . csrf_field() . btn('<i class="fa-solid fa-database"></i> Créer une sauvegarde maintenant') . '</form>']);
echo '<div class="mb-5 grid gap-3 sm:grid-cols-3">' . stat_card('Archives disponibles', (string)count($list), 'fa-box-archive') . stat_card('Conservation', $days . ' jours (min. 3 archives)', 'fa-clock-rotate-left', 'sky') . stat_card('Emplacement', e(str_replace('\\', '/', BACKUP_PATH)) , 'fa-folder-closed', 'slate') . '</div>';
card_start('Archives de sauvegarde (base de données + ordres de mission + justificatifs + photos)');
if (!$list) { echo empty_state('Aucune sauvegarde. Créez-en une avant toute opération sensible.', 'fa-database'); } else {
    echo tbl_start() . th('Archive') . th('Date') . th('Taille') . th('') . tbl_mid();
    foreach ($list as $b) {
        echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 font-mono text-xs">' . e($b['name']) . '</td><td class="px-4 py-3 whitespace-nowrap">' . date('d/m/Y H:i', $b['time']) . '</td><td class="px-4 py-3">' . round($b['size'] / 1024) . ' Ko</td><td class="px-4 py-3 text-right whitespace-nowrap"><a class="mr-3 text-brand hover:underline" href="' . e(url('sauvegardes', 'download', ['f' => $b['name']])) . '">Télécharger</a>'
          . '<form method="post" action="' . e(url('sauvegardes', 'restore')) . '" class="mr-3 inline" data-confirm="Restaurer « ' . e($b['name']) . ' » ? Les données actuelles seront REMPLACÉES (une sauvegarde de sécurité est créée automatiquement avant).">' . csrf_field() . '<input type="hidden" name="f" value="' . e($b['name']) . '"><input type="hidden" name="confirm_text" value="RESTAURER"><button class="text-amber-700 hover:underline">Restaurer</button></form>'
          . confirm_form(url('sauvegardes', 'delete'), '<button class="text-red-700 hover:underline">Supprimer</button>', 'Supprimer définitivement cette archive ?', ['f' => $b['name']]) . '</td></tr>';
    }
    echo tbl_end();
} card_end();
echo '<div class="mt-6">'; card_start('Restaurer depuis une archive téléversée'); echo '<form method="post" enctype="multipart/form-data" action="' . e(url('sauvegardes', 'restore')) . '" class="grid gap-4 p-5 md:grid-cols-3">' . csrf_field()
    . '<div><label class="mb-1 block text-sm font-medium">Archive (.zip)</label><input type="file" name="archive" accept=".zip,application/zip" required class="block w-full"></div>' . f_input('Tapez RESTAURER pour confirmer', 'confirm_text', '', ['required' => 1, 'autocomplete' => 'off'])
    . '<div class="flex items-end">' . btn('<i class="fa-solid fa-rotate-left"></i> Restaurer', 'danger') . '</div><p class="text-xs text-slate-500 md:col-span-3">Processus : vérification d\'intégrité SHA-256 → sauvegarde de sécurité automatique → restauration SQL → restauration des fichiers → contrôle des comptages par table → journalisation.</p></form>'; card_end(); echo '</div>';
page_end();
