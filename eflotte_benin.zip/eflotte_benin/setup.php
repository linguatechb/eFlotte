<?php
/**
 * Installateur eFlotte Bénin — http://localhost/eflotte_benin/setup.php
 * Crée la base, importe le schéma et (optionnellement) les données de démonstration.
 * Se verrouille automatiquement après installation (fichier storage/installed.lock).
 */
declare(strict_types=1);
$root = __DIR__;
$cfg = require $root . '/config/config.php';
if (is_file($root . '/config/config.local.php')) { $cfg = array_replace_recursive($cfg, require $root . '/config/config.local.php'); }
foreach (['host', 'port', 'name', 'user', 'pass'] as $k) { $v = getenv('EFLOTTE_DB_' . strtoupper($k)); if ($v !== false) { $cfg['db'][$k] = $v; } }
require_once $root . '/app/core/backup.php';
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
$cli = PHP_SAPI === 'cli';
$lock = $root . '/storage/installed.lock';
$msgs = []; $ok = false;

if ($cli || ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
    if (is_file($lock) && !in_array('--force', $argv ?? [], true)) { $msgs[] = ['err', 'Installation déjà effectuée (supprimez storage/installed.lock pour réinstaller — les données seront effacées).']; }
    else {
        try {
            $c = $cfg['db'];
            $pdo = new PDO("mysql:host={$c['host']};port={$c['port']};charset=utf8mb4", $c['user'], (string)$c['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
            $db = preg_replace('/[^A-Za-z0-9_]/', '', $c['name']);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db`");
            $strip = fn($sql) => preg_replace(['/^\s*CREATE DATABASE[^;]*;/mi', '/^\s*USE\s+`?[A-Za-z0-9_]+`?\s*;/mi'], '', $sql);
            $n = sql_run($pdo, $strip(file_get_contents($root . '/database/schema.sql'))); $msgs[] = ['ok', "Schéma importé ($n instructions)."];
            $demo = $cli ? !in_array('--no-demo', $argv ?? [], true) : (($_POST['demo'] ?? '1') === '1');
            if ($demo) { $n = sql_run($pdo, $strip(file_get_contents($root . '/database/seed.sql'))); $msgs[] = ['ok', "Données de démonstration importées ($n instructions)."]; }
            else {
                // Instance vierge : ministère, rôles, paramètres et un compte Super-Admin initial
                $seed = $strip(file_get_contents($root . '/database/seed.sql')); $keep = [];
                foreach (sql_split($seed) as $st) { if (preg_match('/^INSERT INTO `(ministeres|roles|services|parametres)`/', $st) || preg_match('/^(SET|USE)/i', $st)) { $keep[] = $st; } }
                foreach ($keep as $st) { $pdo->exec($st); }
                $pdo->exec("INSERT INTO users (ministere_id,role_id,service_id,nom,prenoms,email,password_hash,fonction) VALUES (1,4,4,'ADMIN','Super','admin@eflotte.bj'," . $pdo->quote(password_hash('Admin@2026', PASSWORD_DEFAULT)) . ",'Administrateur Système')");
                $pdo->exec("UPDATE parametres SET valeur='0' WHERE cle='afficher_comptes_demo'");
                $msgs[] = ['ok', 'Instance vierge créée (compte admin@eflotte.bj / Admin@2026 — à modifier immédiatement).'];
            }
            foreach (['uploads/vehicules', 'uploads/ordres_mission', 'uploads/justificatifs', 'storage/backups', 'storage/logs'] as $d) { if (!is_dir("$root/$d")) { @mkdir("$root/$d", 0775, true); } }
            if (!$demo) { foreach (glob($root . '/uploads/ordres_mission/demo_*.pdf') ?: [] as $f) { @unlink($f); } }
            file_put_contents($lock, date('c')); $ok = true; $msgs[] = ['ok', 'Installation terminée.'];
        } catch (Throwable $e) { $msgs[] = ['err', 'Échec : ' . $e->getMessage()]; }
    }
    if ($cli) { foreach ($msgs as [$t, $m]) { echo strtoupper($t) . ' ' . $m . PHP_EOL; } exit($ok ? 0 : 1); }
}
$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/');
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Installation — eFlotte Bénin</title>
<style>body{font-family:system-ui,Segoe UI,sans-serif;background:#f8fafc;color:#1e293b;margin:0}.w{max-width:620px;margin:6vh auto;background:#fff;border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;box-shadow:0 1px 3px #0001}.b{display:flex;height:6px}.b i{flex:1}.p{padding:28px}h1{color:#006828;margin:0 0 6px;font-size:22px}code{background:#f1f5f9;padding:2px 6px;border-radius:4px}.ok{color:#047857}.err{color:#b91c1c}button,a.btn{background:#006828;color:#fff;border:0;border-radius:8px;padding:10px 18px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block}label{display:block;margin:10px 0}</style></head><body><div class="w"><div class="b"><i style="background:#006828"></i><i style="background:#FFBE00"></i><i style="background:#EB0000"></i></div><div class="p">
<h1>eFlotte Bénin — Installation</h1><p>Base cible : <code><?= h($cfg['db']['name']) ?></code> sur <code><?= h($cfg['db']['host']) ?>:<?= h($cfg['db']['port']) ?></code> (utilisateur <code><?= h($cfg['db']['user']) ?></code>). Modifiez <code>config/config.php</code> si besoin.</p>
<?php foreach ($msgs as [$t, $m]) { echo '<p class="' . $t . '">' . ($t === 'ok' ? '✔ ' : '✘ ') . h($m) . '</p>'; } ?>
<?php if ($ok): ?><p><a class="btn" href="<?= h($base) ?>/index.php">Ouvrir eFlotte Bénin</a></p><p style="font-size:13px;color:#64748b">Par sécurité, supprimez <code>setup.php</code> après installation.</p>
<?php elseif (is_file($lock)): ?><p class="ok">✔ L'application est déjà installée.</p><p><a class="btn" href="<?= h($base) ?>/index.php">Ouvrir eFlotte Bénin</a></p>
<?php else: ?><form method="post"><label><input type="radio" name="demo" value="1" checked> Installer avec les <b>données de démonstration</b> (recommandé pour les tests)</label><label><input type="radio" name="demo" value="0"> Instance <b>vierge</b> (production)</label><button>Installer</button></form><?php endif; ?>
</div></div></body></html>
