<?php
class Client {
    public string $jar; public array $last = [];
    function __construct(public string $base) { $this->jar = tempnam(sys_get_temp_dir(), 'cj'); }
    function req(string $method, string $url, array $data = [], bool $follow = true): array {
        $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_COOKIEJAR => $this->jar, CURLOPT_COOKIEFILE => $this->jar, CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_HEADER => 1, CURLOPT_TIMEOUT => 60, CURLOPT_MAXREDIRS => 5]);
        if ($method === 'POST') { curl_setopt($ch, CURLOPT_POST, 1); curl_setopt($ch, CURLOPT_POSTFIELDS, $data); }
        $raw = curl_exec($ch); $hs = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $r = ['code' => curl_getinfo($ch, CURLINFO_HTTP_CODE), 'head' => substr($raw, 0, $hs), 'body' => substr($raw, $hs), 'url' => curl_getinfo($ch, CURLINFO_EFFECTIVE_URL)]; curl_close($ch);
        return $this->last = $r;
    }
    function get(string $p, ?string $a = null, array $q = [], bool $follow = true): array { return $this->req('GET', $this->base . '?' . http_build_query(['p' => $p] + ($a ? ['a' => $a] : []) + $q), [], $follow); }
    function token(string $body = null): string { preg_match('/name="_csrf" value="([a-f0-9]+)"/', $body ?? $this->last['body'], $m); return $m[1] ?? ''; }
    function post(string $p, string $a, array $d = [], bool $follow = true, ?string $tokenPage = null): array {
        $tp = $tokenPage ?? 'dashboard'; if (!isset($d['_csrf'])) { $this->get($tp === 'dashboard' ? 'dashboard' : $tp); $d['_csrf'] = $this->token(); }
        return $this->req('POST', $this->base . '?' . http_build_query(['p' => $p, 'a' => $a]), $d, $follow);
    }
    function login(string $email, string $pwd): bool { $this->get('auth', 'login'); $r = $this->req('POST', $this->base . '?p=auth&a=login', ['_csrf' => $this->token(), 'email' => $email, 'password' => $pwd]); return str_contains($r['url'], 'p=dashboard') || (str_contains($r['body'], 'Tableau de bord') && $r['code'] === 200); }
}

$BASE = rtrim($argv[1] ?? 'http://127.0.0.1:8099', '/') . '/index.php';
$accounts = ['agent@eflotte.bj' => 'Agent@2026', 'validateur@eflotte.bj' => 'Valid@2026', 'gestionnaire@eflotte.bj' => 'Flotte@2026', 'admin@eflotte.bj' => 'Admin@2026'];
$total = 0; $broken = [];
foreach ($accounts as $mail => $pwd) {
    $c = new Client($BASE); $c->login($mail, $pwd); $seen = []; $queue = [$BASE . '?p=dashboard'];
    while ($queue && count($seen) < 400) {
        $u = array_shift($queue); $key = preg_replace('/[&?](page|sort|dir)=[^&]*/', '', $u); if (isset($seen[$key])) { continue; } $seen[$key] = 1;
        if (preg_match('/a=(logout|restore|create|download|csv|pdf|xlsx|dl=)|read_all|a=open|documents/', $u)) { continue; }
        $r = $c->req('GET', $u); $total++;
        if (!in_array($r['code'], [200], true) || preg_match('/(Fatal error|Warning:|Notice:|Une erreur est survenue)/', $r['body'])) { $broken[] = "$mail -> $u ({$r['code']})"; continue; }
        preg_match_all('/href="([^"#]+)"/', $r['body'], $m);
        foreach ($m[1] as $h) { $h = html_entity_decode($h); if (str_starts_with($h, '/index.php?') || str_starts_with($h, $BASE . '?')) { $full = str_starts_with($h, 'http') ? $h : 'http://127.0.0.1:8099' . $h; if (!isset($seen[preg_replace('/[&?](page|sort|dir)=[^&]*/', '', $full)])) { $queue[] = $full; } } }
    }
    echo "$mail : " . count($seen) . " pages parcourues\n";
}
echo "Total $total requêtes ; liens cassés : " . count($broken) . "\n" . implode("\n", array_slice($broken, 0, 20)) . "\n";
