<?php
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
$CFG = require APP_ROOT . '/config/config.php';
if (is_file(APP_ROOT . '/config/config.local.php')) {
    $CFG = array_replace_recursive($CFG, require APP_ROOT . '/config/config.local.php');
}
foreach (['host', 'port', 'name', 'user', 'pass'] as $k) {           // surcharges par variables d'environnement
    $v = getenv('EFLOTTE_DB_' . strtoupper($k));
    if ($v !== false) { $CFG['db'][$k] = $v; }
}
$GLOBALS['CFG'] = $CFG;
date_default_timezone_set($CFG['timezone']);
mb_internal_encoding('UTF-8');

ini_set('display_errors', $CFG['env'] === 'development' ? '1' : '0');
error_reporting(E_ALL);
ini_set('log_errors', '1');
@ini_set('error_log', APP_ROOT . '/storage/logs/php_errors.log');

// ---- URLs : calculées dynamiquement à partir de SCRIPT_NAME (ex. /eflotte_benin/index.php)
$script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
define('BASE_URL', $script);
define('ROOT_URL', rtrim(dirname($script), '/'));
define('ASSET_URL', ROOT_URL . '/public/assets');
define('UPLOAD_URL', ROOT_URL . '/uploads');

// ---- Chemins disque
define('UPLOAD_PUBLIC', APP_ROOT . '/uploads');                                   // photos véhicules uniquement
define('UPLOAD_PRIVATE', rtrim($CFG['private_upload_path'] ?: APP_ROOT . '/uploads', '/\\'));
define('BACKUP_PATH', rtrim($CFG['backup_path'] ?: APP_ROOT . '/storage/backups', '/\\'));
foreach ([UPLOAD_PUBLIC . '/vehicules', UPLOAD_PRIVATE . '/ordres_mission', UPLOAD_PRIVATE . '/justificatifs', BACKUP_PATH, APP_ROOT . '/storage/logs'] as $d) {
    if (!is_dir($d)) { @mkdir($d, 0775, true); }
}

foreach (['helpers', 'db', 'auth', 'audit', 'upload', 'availability', 'reports', 'backup'] as $f) {
    require APP_ROOT . '/app/core/' . $f . '.php';
}

// ---- Sécurité HTTP
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Permissions-Policy: geolocation=(), camera=(), microphone=()');

// ---- Session sécurisée
session_name('EFLOTTESESS');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params([
    'lifetime' => 0, 'path' => (ROOT_URL === '' ? '/' : ROOT_URL . '/'),
    'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS']),
]);
session_start();

set_exception_handler(function (Throwable $e) {
    error_log('[eFlotte] ' . $e::class . ': ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    if (!headers_sent()) { header('Content-Type: text/html; charset=utf-8'); }
    $detail = $GLOBALS['CFG']['env'] === 'development' ? '<pre style="text-align:left;white-space:pre-wrap">' . htmlspecialchars((string)$e) . '</pre>' : '';
    echo '<!doctype html><meta charset="utf-8"><title>Erreur</title><body style="font-family:system-ui;max-width:560px;margin:15vh auto;text-align:center;color:#1f2937">'
       . '<h1 style="color:#006828">Une erreur est survenue</h1><p>L\'opération n\'a pas pu être menée à terme. Veuillez réessayer ou contacter l\'administrateur de l\'instance.</p>'
       . $detail . '<p><a href="' . htmlspecialchars(BASE_URL) . '">Retour à l\'accueil</a></p></body>';
    exit;
});
