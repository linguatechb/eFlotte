<?php
declare(strict_types=1);

require_perm('rapports.view');
$f = report_filters(); $R = report_data($f);
if (in_array($A, ['pdf', 'csv', 'xlsx'], true)) {
    if (!empty($R['error'])) { flash('error', $R['error']); redirect(url('rapports', null, $_GET)); }
    audit('rapport.export_' . $A, 'rapports', $f['type'], null, $f);
    match ($A) { 'pdf' => report_pdf($R, $f), 'csv' => report_csv($R, $f), 'xlsx' => report_xlsx($R, $f) };
}
$qs = array_filter($f, fn($v) => $v !== '' && $v !== 0);
page_start('Rapports et exportations');
card_start('Paramètres du rapport');
echo '<form method="get" action="' . e(BASE_URL) . '" class="grid gap-4 p-5 sm:grid-cols-2 lg:grid-cols-4"><input type="hidden" name="p" value="rapports">'
   . f_select('Type de rapport', 'type', REPORT_TYPES, $f['type'], ['id' => 'r-type'])
   . f_input('Mois (rapport mensuel)', 'mois', $f['mois'], ['type' => 'month']) . f_input('Année (rapport annuel)', 'annee', $f['annee'], ['type' => 'number', 'min' => 2000, 'max' => 2100])
   . '<div></div>' . f_input('Période : du', 'du', $f['du'], ['type' => 'date']) . f_input('au', 'au', $f['au'], ['type' => 'date'])
   . f_select('Véhicule', 'vehicule_id', vehicule_options(true), $f['vehicule_id'] ?: '', ['empty' => 'Tous']) . f_select('Chauffeur', 'chauffeur_id', chauffeur_options(false), $f['chauffeur_id'] ?: '', ['empty' => 'Tous'])
   . f_select('Statut', 'statut', array_combine(array_merge(RES_STATUTS, ['Planifiée']), array_merge(RES_STATUTS, ['Planifiée'])), $f['statut'], ['empty' => 'Tous'])
   . f_select('Catégorie (dépenses / maintenance)', 'categorie', array_combine(array_merge(DEP_CATS, MNT_CATS), array_merge(DEP_CATS, MNT_CATS)), $f['categorie'], ['empty' => 'Toutes'])
   . '<div class="flex items-end">' . btn('<i class="fa-solid fa-eye"></i> Afficher l\'aperçu') . '</div></form>'; card_end();
echo '<div class="mt-6">'; card_start(e($R['title']) . ' <span class="ml-2 font-normal text-slate-500">' . e($R['subtitle']) . '</span>',
    empty($R['error']) ? '<a class="inline-flex items-center gap-2 rounded-lg bg-red-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-red-700" href="' . e(url('rapports', 'pdf', $qs)) . '"><i class="fa-solid fa-file-pdf"></i> PDF</a><a class="inline-flex items-center gap-2 rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800" href="' . e(url('rapports', 'xlsx', $qs)) . '"><i class="fa-solid fa-file-excel"></i> Excel</a><a class="inline-flex items-center gap-2 rounded-lg bg-slate-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-slate-800" href="' . e(url('rapports', 'csv', $qs)) . '"><i class="fa-solid fa-file-csv"></i> CSV</a>' : '');
if (!empty($R['error'])) { echo '<div class="px-5 py-8 text-center text-sm text-amber-800"><i class="fa-solid fa-circle-info mr-1"></i>' . e($R['error']) . '</div>'; }
else {
    if ($R['summary']) { echo '<dl class="grid gap-3 border-b border-slate-100 p-5 sm:grid-cols-2 lg:grid-cols-4">'; foreach ($R['summary'] as [$k, $v]) { echo '<div class="rounded-lg bg-slate-50 px-4 py-2.5"><dt class="text-xs text-slate-500">' . e($k) . '</dt><dd class="text-base font-bold text-brand">' . e($v) . '</dd></div>'; } echo '</dl>'; }
    if (!$R['rows']) { echo empty_state('Aucune donnée pour ces critères.', 'fa-chart-simple'); } else {
        echo tbl_start(); foreach ($R['columns'] as $c) { echo th($c[0], in_array($c[2], ['int', 'money']) ? 'text-right' : ''); } echo tbl_mid();
        foreach (array_slice($R['rows'], 0, 200) as $row) { echo '<tr class="hover:bg-slate-50">'; foreach ($R['columns'] as $i => $c) { echo '<td class="px-4 py-2.5 ' . (in_array($c[2], ['int', 'money']) ? 'text-right tabular-nums' : '') . '">' . e(report_cell($row[$i] ?? '', $c[2])) . '</td>'; } echo '</tr>'; }
        echo tbl_end() . '<div class="border-t border-slate-100 px-5 py-3 text-xs text-slate-500">' . count($R['rows']) . ' ligne(s)' . (count($R['rows']) > 200 ? ' — aperçu limité à 200 lignes, les exports contiennent la totalité' : '') . '</div>';
    }
}
card_end(); echo '</div>'; page_end();
