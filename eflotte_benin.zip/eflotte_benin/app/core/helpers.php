<?php
declare(strict_types=1);

function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function url(string $p = 'dashboard', ?string $a = null, array $q = []): string
{
    $params = ['p' => $p];
    if ($a !== null && $a !== '') { $params['a'] = $a; }
    return BASE_URL . '?' . http_build_query($params + $q);
}
function redirect(string $to): never { header('Location: ' . $to); exit; }
function is_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }

// ---- Messages flash
function flash(string $type, string $msg): void { $_SESSION['flash'][] = ['t' => $type, 'm' => $msg]; }
function pull_flash(): array { $f = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $f; }

// ---- CSRF
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(32)); }
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">'; }
function csrf_verify(): void
{
    $t = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($t) || !hash_equals(csrf_token(), $t)) {
        http_response_code(419);
        exit('Session expirée ou jeton de sécurité invalide. Retournez à la page précédente, actualisez-la et recommencez.');
    }
}

// ---- Entrées
function post(string $k, string $d = ''): string { return isset($_POST[$k]) && is_string($_POST[$k]) ? trim($_POST[$k]) : $d; }
function qget(string $k, string $d = ''): string { return isset($_GET[$k]) && is_string($_GET[$k]) ? trim($_GET[$k]) : $d; }
function post_int(string $k): ?int { $v = post($k); return ctype_digit($v) ? (int)$v : null; }
function valid_date(string $s): bool { $d = DateTime::createFromFormat('Y-m-d', $s); return $d && $d->format('Y-m-d') === $s; }
function valid_dt(string $s): bool { $d = DateTime::createFromFormat('Y-m-d\TH:i', $s); return $d && $d->format('Y-m-d\TH:i') === $s; }
function dt_sql(string $s): string { return str_replace('T', ' ', $s) . ':00'; }

// ---- Formats
function fmt_date(?string $d): string { return $d ? date('d/m/Y', strtotime($d)) : '—'; }
function fmt_dt(?string $d): string { return $d ? date('d/m/Y H:i', strtotime($d)) : '—'; }
function fcfa($n): string { return number_format((float)$n, 0, ',', ' ') . ' FCFA'; }
function nb($n): string { return number_format((float)$n, 0, ',', ' '); }
function mois_fr(int $m): string { return ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'][$m]; }
function mois_court(int $m): string { return ['', 'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'][$m]; }
function days_until(?string $date): ?int { return $date ? (int)floor((strtotime($date) - strtotime(date('Y-m-d'))) / 86400) : null; }

// ---- Badges de statut
function badge(string $label, ?string $kind = null): string
{
    static $map = [
        'En attente' => 'amber', 'Validée' => 'sky', 'Attribuée' => 'indigo', 'En cours' => 'green', 'Terminée' => 'slate', 'Rejetée' => 'red',
        'Disponible' => 'green', 'En mission' => 'sky', 'En maintenance' => 'amber', 'Immobilisé' => 'red', 'Réformé' => 'slate',
        'Planifiée' => 'sky', 'Actif' => 'green', 'Inactif' => 'slate', 'Valide' => 'green', 'Expire bientôt' => 'amber', 'Expirée' => 'red', 'Expiré' => 'red', 'Absente' => 'slate',
        'Favorable' => 'green', 'Défavorable' => 'red', 'Préventive' => 'sky', 'Corrective' => 'amber', 'Archivé' => 'slate',
    ];
    $c = $kind ?? ($map[$label] ?? 'slate');
    $cls = [
        'green' => 'bg-emerald-50 text-emerald-800 ring-emerald-600/20', 'amber' => 'bg-amber-50 text-amber-800 ring-amber-600/30',
        'sky' => 'bg-sky-50 text-sky-800 ring-sky-600/20', 'indigo' => 'bg-indigo-50 text-indigo-800 ring-indigo-600/20',
        'red' => 'bg-red-50 text-red-800 ring-red-600/20', 'slate' => 'bg-slate-100 text-slate-700 ring-slate-500/20',
    ][$c] ?? 'bg-slate-100 text-slate-700 ring-slate-500/20';
    return '<span class="inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset ' . $cls . '">' . e($label) . '</span>';
}

/** Statut d'une échéance (assurance, visite, permis) : Valide / Expire bientôt / Expirée */
function echeance_statut(?string $date, int $alertDays): string
{
    if (!$date) { return 'Absente'; }
    $d = days_until($date);
    return $d < 0 ? 'Expirée' : ($d <= $alertDays ? 'Expire bientôt' : 'Valide');
}

// ---- Pagination, tri
function qs(array $override = []): string { return BASE_URL . '?' . http_build_query(array_merge($_GET, $override)); }

/** $sortable : ['clé' => 'expression SQL']. $from : "table t JOIN ... WHERE ..." */
function paginate(string $cols, string $from, array $params, array $sortable, string $defSort, string $defDir = 'desc', int $per = 15): array
{
    $sort = qget('sort', $defSort); if (!isset($sortable[$sort])) { $sort = $defSort; }
    $dir = qget('dir', $defDir) === 'asc' ? 'ASC' : 'DESC';
    $total = (int)val("SELECT COUNT(*) FROM $from", $params);
    $pages = max(1, (int)ceil($total / $per));
    $page = min(max(1, (int)qget('page', '1')), $pages);
    $rows = rows("SELECT $cols FROM $from ORDER BY {$sortable[$sort]} $dir, 1 DESC LIMIT $per OFFSET " . (($page - 1) * $per), $params);
    return ['rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages, 'sort' => $sort, 'dir' => $dir === 'ASC' ? 'asc' : 'desc', 'per' => $per];
}
function th_sort(string $label, string $col, array $pg, string $cls = ''): string
{
    $active = $pg['sort'] === $col;
    $next = ($active && $pg['dir'] === 'asc') ? 'desc' : 'asc';
    $icon = $active ? ($pg['dir'] === 'asc' ? 'fa-sort-up' : 'fa-sort-down') : 'fa-sort opacity-30';
    return '<th class="px-4 py-3 text-left font-semibold ' . $cls . '"><a class="inline-flex items-center gap-1.5 hover:text-brand" href="' . e(qs(['sort' => $col, 'dir' => $next, 'page' => 1])) . '">' . e($label) . ' <i class="fa-solid ' . $icon . ' text-xs"></i></a></th>';
}
function pager(array $pg): string
{
    if ($pg['pages'] <= 1) { return '<div class="px-4 py-3 text-xs text-slate-500 border-t border-slate-100">' . nb($pg['total']) . ' résultat(s)</div>'; }
    $h = '<div class="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-t border-slate-100 text-sm"><span class="text-xs text-slate-500">' . nb($pg['total']) . ' résultat(s) — page ' . $pg['page'] . '/' . $pg['pages'] . '</span><div class="flex gap-1">';
    $from = max(1, $pg['page'] - 2); $to = min($pg['pages'], $pg['page'] + 2);
    if ($pg['page'] > 1) { $h .= '<a class="px-3 py-1 rounded border border-slate-200 hover:bg-slate-50" href="' . e(qs(['page' => $pg['page'] - 1])) . '">‹</a>'; }
    for ($i = $from; $i <= $to; $i++) {
        $h .= '<a class="px-3 py-1 rounded border ' . ($i === $pg['page'] ? 'bg-brand text-white border-brand' : 'border-slate-200 hover:bg-slate-50') . '" href="' . e(qs(['page' => $i])) . '">' . $i . '</a>';
    }
    if ($pg['page'] < $pg['pages']) { $h .= '<a class="px-3 py-1 rounded border border-slate-200 hover:bg-slate-50" href="' . e(qs(['page' => $pg['page'] + 1])) . '">›</a>'; }
    return $h . '</div></div>';
}

// ---- Champs de formulaire
function f_cls(): string { return 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm placeholder:text-slate-400 focus:border-brand focus:ring-2 focus:ring-brand/20 focus:outline-none disabled:bg-slate-100'; }
function f_wrap(string $label, string $inner, array $o): string
{
    $req = !empty($o['required']) ? ' <span class="text-red-600">*</span>' : '';
    $help = !empty($o['help']) ? '<p class="mt-1 text-xs text-slate-500">' . e($o['help']) . '</p>' : '';
    return '<div class="' . e($o['col'] ?? '') . '"><label class="mb-1 block text-sm font-medium text-slate-700">' . e($label) . $req . '</label>' . $inner . $help . '</div>';
}
function f_input(string $label, string $name, $val = '', array $o = []): string
{
    $attrs = '';
    foreach (['min', 'max', 'step', 'maxlength', 'placeholder', 'pattern', 'autocomplete', 'id', 'accept'] as $k) { if (isset($o[$k])) { $attrs .= ' ' . $k . '="' . e($o[$k]) . '"'; } }
    if (!empty($o['required'])) { $attrs .= ' required'; }
    if (!empty($o['disabled'])) { $attrs .= ' disabled'; }
    return f_wrap($label, '<input type="' . e($o['type'] ?? 'text') . '" name="' . e($name) . '" value="' . e($val) . '" class="' . f_cls() . '"' . $attrs . '>', $o);
}
function f_select(string $label, string $name, array $options, $val = '', array $o = []): string
{
    $h = '<select name="' . e($name) . '" class="' . f_cls() . '"' . (!empty($o['required']) ? ' required' : '') . (!empty($o['id']) ? ' id="' . e($o['id']) . '"' : '') . (!empty($o['disabled']) ? ' disabled' : '') . '>';
    if (isset($o['empty'])) { $h .= '<option value="">' . e($o['empty']) . '</option>'; }
    foreach ($options as $k => $v) { $h .= '<option value="' . e($k) . '"' . ((string)$k === (string)$val ? ' selected' : '') . '>' . e($v) . '</option>'; }
    return f_wrap($label, $h . '</select>', $o);
}
function f_textarea(string $label, string $name, $val = '', array $o = []): string
{
    return f_wrap($label, '<textarea name="' . e($name) . '" rows="' . (int)($o['rows'] ?? 3) . '" class="' . f_cls() . '"' . (!empty($o['required']) ? ' required' : '') . (isset($o['maxlength']) ? ' maxlength="' . (int)$o['maxlength'] . '"' : '') . '>' . e($val) . '</textarea>', $o);
}
function btn(string $label, string $kind = 'primary', string $extra = ''): string
{
    $c = ['primary' => 'bg-brand text-white hover:bg-brand-dark', 'secondary' => 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50',
          'danger' => 'bg-red-600 text-white hover:bg-red-700', 'accent' => 'bg-accent text-slate-900 hover:bg-yellow-400'][$kind];
    return '<button type="submit" class="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition-colors ' . $c . '" ' . $extra . '>' . $label . '</button>';
}
function link_btn(string $href, string $label, string $kind = 'secondary'): string
{
    $c = ['primary' => 'bg-brand text-white hover:bg-brand-dark', 'secondary' => 'bg-white text-slate-700 border border-slate-300 hover:bg-slate-50', 'accent' => 'bg-accent text-slate-900 hover:bg-yellow-400'][$kind];
    return '<a href="' . e($href) . '" class="inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition-colors ' . $c . '">' . $label . '</a>';
}
/** Petit formulaire POST avec confirmation (bouton d'action sensible) */
function confirm_form(string $action, string $btnHtml, string $message, array $hidden = [], string $cls = ''): string
{
    $h = '<form method="post" action="' . e($action) . '" class="inline ' . $cls . '" data-confirm="' . e($message) . '">' . csrf_field();
    foreach ($hidden as $k => $v) { $h .= '<input type="hidden" name="' . e($k) . '" value="' . e($v) . '">'; }
    return $h . $btnHtml . '</form>';
}
function decode_cat(string $s): array { return array_values(array_filter(array_map('trim', explode(',', $s)))); }
function json_out(array $d, int $code = 200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }
function password_policy_error(string $p): ?string
{
    if (strlen($p) < 8) { return 'Le mot de passe doit contenir au moins 8 caractères.'; }
    if (!preg_match('/[a-z]/', $p) || !preg_match('/[A-Z]/', $p) || !preg_match('/\d/', $p)) { return 'Le mot de passe doit contenir une majuscule, une minuscule et un chiffre.'; }
    return null;
}
