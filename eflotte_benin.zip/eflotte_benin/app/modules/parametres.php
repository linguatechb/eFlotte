<?php
declare(strict_types=1);

require_perm('parametres.operationnel');
$groups = can('parametres.technique') ? ['operationnel', 'technique'] : ['operationnel'];
if ($A === 'save' && is_post()) {
    $changed = []; $errs = [];
    foreach (rows('SELECT * FROM parametres WHERE groupe IN (' . implode(',', array_fill(0, count($groups), '?')) . ')', $groups) as $p) {
        if (!array_key_exists('p_' . $p['cle'], $_POST) && $p['type'] !== 'bool') { continue; }
        $raw = $p['type'] === 'bool' ? (isset($_POST['p_' . $p['cle']]) ? '1' : '0') : post('p_' . $p['cle']);
        if ($p['type'] === 'int') { if (!ctype_digit($raw) || (int)$raw < 0 || (int)$raw > 100000) { $errs[] = $p['libelle'] . ' : nombre entier positif attendu.'; continue; } $raw = (string)(int)$raw; }
        if ($p['cle'] === 'upload_max_mb' && ((int)$raw < 1 || (int)$raw > 50)) { $errs[] = 'Taille maximale des fichiers : entre 1 et 50 Mo.'; continue; }
        if ($p['cle'] === 'session_timeout_min' && ((int)$raw < 5 || (int)$raw > 480)) { $errs[] = 'Délai d\'inactivité : entre 5 et 480 minutes.'; continue; }
        if ($raw !== $p['valeur']) { q('UPDATE parametres SET valeur=? WHERE id=?', [$raw, $p['id']]); $changed[$p['cle']] = [$p['valeur'], $raw]; }
    }
    if (can('parametres.technique') && isset($_POST['min_nom'])) {
        $old = ministere(); $nm = ['nom' => post('min_nom'), 'sigle' => post('min_sigle'), 'adresse' => post('min_adresse'), 'telephone' => post('min_tel'), 'email' => post('min_email')];
        if ($nm['nom'] === '' || $nm['sigle'] === '') { $errs[] = 'Nom et sigle du ministère obligatoires.'; } elseif ($nm['email'] !== '' && !filter_var($nm['email'], FILTER_VALIDATE_EMAIL)) { $errs[] = 'E-mail du ministère invalide.'; }
        else { [$o, $n] = diff_vals($old, $nm); if ($n) { update('ministeres', mid(), $nm); audit('ministere.modification', 'ministeres', mid(), $o, $n); } }
    }
    if ($changed) { audit('parametres.modification', 'parametres', null, array_map(fn($v) => $v[0], $changed), array_map(fn($v) => $v[1], $changed)); }
    if ($errs) { flash('error', implode('<br>', array_map('e', $errs))); } else { flash('success', 'Paramètres enregistrés.'); }
    redirect(url('parametres'));
}
page_start('Paramètres');
echo '<form method="post" action="' . e(url('parametres', 'save')) . '" class="mx-auto max-w-4xl space-y-6">' . csrf_field();
if (can('parametres.technique')) { $m = ministere(); card_start('Identité de l\'instance ministérielle'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_input('Nom du ministère', 'min_nom', $m['nom'], ['required' => 1, 'col' => 'sm:col-span-2']) . f_input('Sigle', 'min_sigle', $m['sigle'], ['required' => 1]) . f_input('Téléphone', 'min_tel', $m['telephone'] ?? '') . f_input('Adresse', 'min_adresse', $m['adresse'] ?? '') . f_input('E-mail', 'min_email', $m['email'] ?? '', ['type' => 'email']) . '</div>'; card_end(); }
foreach ($groups as $g) {
    card_start($g === 'operationnel' ? 'Paramètres opérationnels' : 'Paramètres techniques et de sécurité'); echo '<div class="divide-y divide-slate-100">';
    foreach (rows('SELECT * FROM parametres WHERE groupe=? ORDER BY id', [$g]) as $p) {
        echo '<div class="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5"><label class="text-sm font-medium text-slate-700" for="p_' . e($p['cle']) . '">' . e($p['libelle']) . '<span class="block font-mono text-[11px] font-normal text-slate-400">' . e($p['cle']) . '</span></label>';
        echo $p['type'] === 'bool' ? '<label class="inline-flex items-center gap-2 text-sm"><input type="checkbox" id="p_' . e($p['cle']) . '" name="p_' . e($p['cle']) . '" value="1" class="h-4 w-4 rounded border-slate-300 text-brand"' . ($p['valeur'] === '1' ? ' checked' : '') . '> Activé</label>'
            : '<input id="p_' . e($p['cle']) . '" name="p_' . e($p['cle']) . '" type="' . ($p['type'] === 'int' ? 'number' : 'text') . '" value="' . e($p['valeur']) . '" class="' . f_cls() . ' w-40"' . ($p['type'] === 'int' ? ' min="0"' : '') . '>';
        echo '</div>';
    }
    echo '</div>'; card_end();
}
echo '<div class="flex justify-end">' . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer les paramètres') . '</div></form>'; page_end();
