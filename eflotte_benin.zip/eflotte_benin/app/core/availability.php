<?php
declare(strict_types=1);

/** Expression SQL de fin effective d'une réservation (une mission en cours non clôturée reste active). */
const RES_END = "(CASE WHEN statut='En cours' THEN GREATEST(date_retour, NOW()) ELSE date_retour END)";
const MNT_END = "(CASE WHEN statut='En cours' AND date_fin IS NULL THEN '9999-12-31' ELSE COALESCE(date_fin, date_maintenance) END)";

/** Dernière assurance / visite technique d'un véhicule */
function last_assurance(int $vid): ?array { return row('SELECT * FROM assurances WHERE vehicule_id=? ORDER BY date_expiration DESC, id DESC LIMIT 1', [$vid]); }
function last_visite(int $vid): ?array { return row('SELECT * FROM visites_techniques WHERE vehicule_id=? ORDER BY date_prochaine DESC, id DESC LIMIT 1', [$vid]); }

/**
 * Contrôle complet de la disponibilité d'un véhicule sur [dep, ret].
 * @return array{errors:string[],warnings:string[]}
 */
function vehicule_check(int $vid, string $dep, string $ret, ?int $excludeRes = null): array
{
    $err = $warn = [];
    $v = row('SELECT * FROM vehicules WHERE id=? AND ministere_id=?', [$vid, mid()]);
    if (!$v) { return ['errors' => ['Véhicule introuvable.'], 'warnings' => []]; }
    if ($v['est_archive']) { $err[] = 'Véhicule archivé.'; }
    if ($v['etat'] === 'Immobilisé') { $err[] = 'Véhicule immobilisé.'; }
    if ($v['etat'] === 'Réformé') { $err[] = 'Véhicule réformé.'; }
    if ($v['etat'] === 'En maintenance') { $err[] = 'Véhicule actuellement en maintenance : attribution bloquée.'; }

    $c = rows('SELECT reference, date_depart, date_retour FROM reservations WHERE vehicule_id=? AND statut IN (\'Attribuée\',\'En cours\') AND id<>? AND date_depart < ? AND ' . RES_END . ' > ?',
        [$vid, $excludeRes ?? 0, $ret, $dep]);
    foreach ($c as $r) { $err[] = 'Déjà affecté à la mission ' . $r['reference'] . ' (' . fmt_dt($r['date_depart']) . ' → ' . fmt_dt($r['date_retour']) . ').'; }

    $m = rows('SELECT categorie, date_maintenance, date_fin, statut FROM maintenances WHERE vehicule_id=? AND statut IN (\'Planifiée\',\'En cours\') AND date_maintenance <= DATE(?) AND ' . MNT_END . ' >= DATE(?)', [$vid, $ret, $dep]);
    foreach ($m as $r) { $err[] = 'Maintenance ' . mb_strtolower($r['statut']) . ' (' . $r['categorie'] . ') du ' . fmt_date($r['date_maintenance']) . ($r['date_fin'] ? ' au ' . fmt_date($r['date_fin']) : '') . '.'; }

    $strict = (int)param('blocage_obligations_expirees', 1) === 1;
    $a = last_assurance($vid); $t = last_visite($vid);
    $retDay = substr($ret, 0, 10);
    if (!$a) { $warn[] = 'Aucune assurance enregistrée pour ce véhicule.'; }
    elseif ($a['date_expiration'] < $retDay) {
        $msg = 'Assurance expirée ou expirant avant la fin de la mission (échéance ' . fmt_date($a['date_expiration']) . ').';
        if ($strict) { $err[] = $msg; } else { $warn[] = $msg; }
    }
    if (!$t) { $warn[] = 'Aucune visite technique enregistrée pour ce véhicule.'; }
    elseif ($t['date_prochaine'] < $retDay) {
        $msg = 'Visite technique expirée ou expirant avant la fin de la mission (échéance ' . fmt_date($t['date_prochaine']) . ').';
        if ($strict) { $err[] = $msg; } else { $warn[] = $msg; }
    }
    return ['errors' => $err, 'warnings' => $warn];
}

/** @return array{errors:string[],warnings:string[]} */
function chauffeur_check(int $cid, string $dep, string $ret, ?int $excludeRes = null): array
{
    $err = $warn = [];
    $c = row('SELECT * FROM chauffeurs WHERE id=? AND ministere_id=?', [$cid, mid()]);
    if (!$c) { return ['errors' => ['Chauffeur introuvable.'], 'warnings' => []]; }
    if (!$c['actif']) { $err[] = 'Chauffeur inactif.'; }
    if ($c['date_expiration'] < substr($ret, 0, 10)) { $err[] = 'Permis expiré ou expirant avant la fin de la mission (' . fmt_date($c['date_expiration']) . ').'; }
    $r = rows('SELECT reference, date_depart, date_retour FROM reservations WHERE chauffeur_id=? AND statut IN (\'Attribuée\',\'En cours\') AND id<>? AND date_depart < ? AND ' . RES_END . ' > ?', [$cid, $excludeRes ?? 0, $ret, $dep]);
    foreach ($r as $x) { $err[] = 'Déjà affecté à la mission ' . $x['reference'] . ' (' . fmt_dt($x['date_depart']) . ' → ' . fmt_dt($x['date_retour']) . ').'; }
    return ['errors' => $err, 'warnings' => $warn];
}

/** Véhicules et chauffeurs libres sur la période */
function disponibles(string $dep, string $ret, ?int $excludeRes = null): array
{
    $v = $c = [];
    foreach (rows('SELECT id, marque, modele, immatriculation, carburant, kilometrage, etat FROM vehicules WHERE ministere_id=? AND est_archive=0 ORDER BY marque, modele', [mid()]) as $x) {
        $ck = vehicule_check((int)$x['id'], $dep, $ret, $excludeRes);
        if (!$ck['errors']) { $x['warnings'] = $ck['warnings']; $v[] = $x; }
    }
    foreach (rows('SELECT id, nom, prenoms, matricule, categorie_permis, date_expiration FROM chauffeurs WHERE ministere_id=? AND actif=1 ORDER BY nom', [mid()]) as $x) {
        if (!chauffeur_check((int)$x['id'], $dep, $ret, $excludeRes)['errors']) { $c[] = $x; }
    }
    return ['vehicules' => $v, 'chauffeurs' => $c];
}

/** Recalcule l'état automatique d'un véhicule (hors Immobilisé / Réformé, décidés manuellement) */
function sync_vehicule_etat(int $vid): void
{
    $v = row('SELECT etat FROM vehicules WHERE id=?', [$vid]);
    if (!$v || in_array($v['etat'], ['Immobilisé', 'Réformé'], true)) { return; }
    if (val("SELECT COUNT(*) FROM maintenances WHERE vehicule_id=? AND statut='En cours'", [$vid])) { $new = 'En maintenance'; }
    elseif (val("SELECT COUNT(*) FROM reservations WHERE vehicule_id=? AND statut='En cours'", [$vid])) { $new = 'En mission'; }
    else { $new = 'Disponible'; }
    if ($new !== $v['etat']) { q('UPDATE vehicules SET etat=? WHERE id=?', [$new, $vid]); }
}

/** Périmètre de visibilité des réservations selon le profil (filtrage côté serveur) */
function reservation_scope(string $alias = 'r', string $userAlias = 'd'): array
{
    $sql = "$alias.ministere_id = ?"; $p = [mid()];
    switch (role()) {
        case 'agent': $sql .= " AND $alias.demandeur_id = ?"; $p[] = uid(); break;
        case 'validateur':
            $sql .= " AND ($userAlias.service_id " . (user()['service_id'] ? '= ?' : 'IS NULL AND 1=0') . " OR $alias.validateur_id = ?)";
            if (user()['service_id']) { $p[] = user()['service_id']; }
            $p[] = uid(); break;
        case 'gestionnaire': case 'superadmin': break;
        default: $sql .= ' AND 1=0';
    }
    return [$sql, $p];
}
function get_reservation(int $id): ?array
{
    [$sc, $sp] = reservation_scope();
    return row("SELECT r.*, d.nom AS dem_nom, d.prenoms AS dem_prenoms, d.fonction AS dem_fonction, d.service_id AS dem_service, s.nom AS service_nom,
        v.marque, v.modele, v.immatriculation, v.kilometrage AS veh_km, ch.nom AS ch_nom, ch.prenoms AS ch_prenoms, ch.telephone AS ch_tel,
        va.nom AS val_nom, va.prenoms AS val_prenoms, vs.marque AS vs_marque, vs.modele AS vs_modele, vs.immatriculation AS vs_immat
        FROM reservations r JOIN users d ON d.id=r.demandeur_id LEFT JOIN services s ON s.id=d.service_id
        LEFT JOIN vehicules v ON v.id=r.vehicule_id LEFT JOIN chauffeurs ch ON ch.id=r.chauffeur_id LEFT JOIN users va ON va.id=r.validateur_id
        LEFT JOIN vehicules vs ON vs.id=r.vehicule_souhaite_id WHERE r.id=? AND $sc", [$id, ...$sp]);
}
function histo(int $resId, ?string $old, string $new, ?string $comment = null): void
{
    insert('historiques_reservations', ['reservation_id' => $resId, 'ancien_statut' => $old, 'nouveau_statut' => $new, 'user_id' => uid() ?: null, 'commentaire' => $comment]);
}

/** Synchronise la dépense liée à une maintenance (évite la double saisie) */
function sync_maintenance_depense(int $mid_): void
{
    $m = row('SELECT * FROM maintenances WHERE id=?', [$mid_]);
    if (!$m) { return; }
    $ex = row('SELECT id FROM depenses WHERE maintenance_id=?', [$mid_]);
    if ((float)$m['cout'] <= 0 || $m['statut'] === 'Planifiée') { if ($ex) { q('DELETE FROM depenses WHERE id=?', [$ex['id']]); } return; }
    $data = ['ministere_id' => $m['ministere_id'], 'vehicule_id' => $m['vehicule_id'], 'maintenance_id' => $mid_, 'date_depense' => $m['date_fin'] ?: $m['date_maintenance'],
        'categorie' => $m['type'] === 'Préventive' ? 'Entretien' : 'Réparation', 'montant' => $m['cout'], 'description' => mb_substr('Maintenance : ' . $m['categorie'] . ' — ' . $m['description'], 0, 250),
        'prestataire' => $m['prestataire'], 'justificatif' => null, 'created_by' => uid() ?: $m['created_by']];
    if ($ex) { unset($data['created_by'], $data['justificatif']); update('depenses', (int)$ex['id'], $data); } else { insert('depenses', $data); }
}

/** Alertes administratives calculées en temps réel [niveau, message, lien] */
function alerts(): array
{
    $m = mid(); $out = [];
    $dp = (int)param('alerte_permis_jours', 60); $da = (int)param('alerte_assurance_jours', 30); $dv = (int)param('alerte_visite_jours', 30); $dm = (int)param('alerte_maintenance_jours', 15);
    foreach (rows('SELECT id, nom, prenoms, date_expiration FROM chauffeurs WHERE ministere_id=? AND actif=1 AND date_expiration <= DATE_ADD(CURDATE(), INTERVAL ? DAY) ORDER BY date_expiration', [$m, $dp]) as $c) {
        $d = days_until($c['date_expiration']);
        $out[] = [$d < 0 ? 'danger' : 'warning', 'Permis de ' . $c['prenoms'] . ' ' . $c['nom'] . ($d < 0 ? ' expiré depuis ' . abs($d) . ' j' : ' expire dans ' . $d . ' j (' . fmt_date($c['date_expiration']) . ')'), url('chauffeurs', 'show', ['id' => $c['id']]), 'permis-' . $c['id'] . '-' . $c['date_expiration']];
    }
    foreach (rows('SELECT v.id, v.marque, v.modele, v.immatriculation, (SELECT MAX(date_expiration) FROM assurances WHERE vehicule_id=v.id) AS ech FROM vehicules v WHERE v.ministere_id=? AND v.est_archive=0 AND v.etat<>\'Réformé\'', [$m]) as $v) {
        if ($v['ech'] === null) { $out[] = ['warning', 'Aucune assurance enregistrée : ' . $v['marque'] . ' ' . $v['modele'] . ' (' . $v['immatriculation'] . ')', url('assurances'), 'ass0-' . $v['id']]; continue; }
        $d = days_until($v['ech']);
        if ($d <= $da) { $out[] = [$d < 0 ? 'danger' : 'warning', 'Assurance ' . ($d < 0 ? 'EXPIRÉE' : 'à renouveler') . ' : ' . $v['marque'] . ' ' . $v['modele'] . ' (' . $v['immatriculation'] . ') — ' . fmt_date($v['ech']), url('assurances'), 'ass-' . $v['id'] . '-' . $v['ech']]; }
    }
    foreach (rows('SELECT v.id, v.marque, v.modele, v.immatriculation, (SELECT MAX(date_prochaine) FROM visites_techniques WHERE vehicule_id=v.id) AS ech FROM vehicules v WHERE v.ministere_id=? AND v.est_archive=0 AND v.etat<>\'Réformé\'', [$m]) as $v) {
        if ($v['ech'] === null) { $out[] = ['warning', 'Aucune visite technique enregistrée : ' . $v['marque'] . ' ' . $v['modele'] . ' (' . $v['immatriculation'] . ')', url('assurances'), 'vt0-' . $v['id']]; continue; }
        $d = days_until($v['ech']);
        if ($d <= $dv) { $out[] = [$d < 0 ? 'danger' : 'warning', 'Visite technique ' . ($d < 0 ? 'EXPIRÉE' : 'à programmer') . ' : ' . $v['marque'] . ' ' . $v['modele'] . ' (' . $v['immatriculation'] . ') — ' . fmt_date($v['ech']), url('assurances'), 'vt-' . $v['id'] . '-' . $v['ech']]; }
    }
    foreach (rows("SELECT v.id, v.marque, v.modele, v.immatriculation, x.prochaine_echeance AS ech FROM vehicules v JOIN maintenances x ON x.id = (SELECT id FROM maintenances WHERE vehicule_id=v.id AND statut='Terminée' AND prochaine_echeance IS NOT NULL ORDER BY date_maintenance DESC, id DESC LIMIT 1)
        WHERE v.ministere_id=? AND v.est_archive=0 AND x.prochaine_echeance <= DATE_ADD(CURDATE(), INTERVAL ? DAY)", [$m, $dm]) as $v) {
        $d = days_until($v['ech']);
        $out[] = [$d < 0 ? 'danger' : 'warning', 'Entretien ' . ($d < 0 ? 'en retard' : 'à prévoir') . ' : ' . $v['marque'] . ' ' . $v['modele'] . ' (' . $v['immatriculation'] . ') — ' . fmt_date($v['ech']), url('maintenances'), 'mnt-' . $v['id'] . '-' . $v['ech']];
    }
    foreach (rows("SELECT r.id, r.reference, r.date_retour, v.immatriculation FROM reservations r LEFT JOIN vehicules v ON v.id=r.vehicule_id WHERE r.ministere_id=? AND r.statut='En cours' AND r.date_retour < NOW()", [$m]) as $r) {
        $out[] = ['danger', 'Mission ' . $r['reference'] . ' en retard de clôture (retour prévu ' . fmt_dt($r['date_retour']) . ')', url('reservations', 'show', ['id' => $r['id']]), 'retard-' . $r['id']];
    }
    foreach (rows("SELECT id, reference FROM reservations WHERE ministere_id=? AND statut='En attente' AND created_at < (NOW() - INTERVAL 2 DAY)", [$m]) as $r) {
        $out[] = ['warning', 'Demande ' . $r['reference'] . ' en attente de validation depuis plus de 2 jours', url('reservations', 'show', ['id' => $r['id']]), 'attente-' . $r['id']];
    }
    foreach (rows("SELECT r.id, r.reference, r.date_depart FROM reservations r WHERE r.ministere_id=? AND r.statut='Validée'", [$m]) as $r) {
        $out[] = ['info', 'Demande ' . $r['reference'] . ' validée : attribution véhicule/chauffeur en attente', url('reservations', 'show', ['id' => $r['id']]), 'attrib-' . $r['id']];
    }
    return $out;
}
/** Génère (une seule fois par échéance) les notifications d'alertes pour les gestionnaires de flotte. */
function push_alert_notifications(): void
{
    if (!in_array(role(), ['gestionnaire', 'superadmin'], true)) { return; }
    if (($_SESSION['alerts_pushed'] ?? '') === date('Y-m-d')) { return; }
    $_SESSION['alerts_pushed'] = date('Y-m-d');
    $targets = array_merge(users_by_role('gestionnaire'), users_by_role('superadmin'));
    foreach (alerts() as [$lvl, $msg, $link, $key]) {
        if ($lvl === 'info' || str_starts_with($key, 'attente-')) { continue; }
        notify($targets, $lvl === 'danger' ? 'Alerte critique' : 'Alerte', $msg, $link, $lvl, 'alert-' . $key);
    }
}
