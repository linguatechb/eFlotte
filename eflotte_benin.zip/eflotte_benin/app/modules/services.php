<?php
declare(strict_types=1);

require_perm('users.manage');
if ($A === 'save' && is_post()) {
    $id = post_int('id'); $nom = post('nom'); $sig = post('sigle');
    if ($nom === '' || mb_strlen($nom) > 190) { flash('error', 'Le nom du service est obligatoire.'); redirect(url('services')); }
    if (val('SELECT COUNT(*) FROM services WHERE ministere_id=? AND nom=? AND id<>?', [mid(), $nom, $id ?? 0])) { flash('error', 'Ce service existe déjà.'); redirect(url('services')); }
    if ($id) { $old = row('SELECT * FROM services WHERE id=? AND ministere_id=?', [$id, mid()]); if (!$old) { http_response_code(404); exit('Introuvable.'); } update('services', $id, ['nom' => $nom, 'sigle' => $sig ?: null]); audit('service.modification', 'services', $id, $old, ['nom' => $nom, 'sigle' => $sig]); }
    else { $id = insert('services', ['ministere_id' => mid(), 'nom' => $nom, 'sigle' => $sig ?: null]); audit('service.creation', 'services', $id, null, ['nom' => $nom, 'sigle' => $sig]); }
    flash('success', 'Service enregistré.'); redirect(url('services'));
}
if ($A === 'delete' && is_post()) {
    $s = row('SELECT * FROM services WHERE id=? AND ministere_id=?', [(int)post('id'), mid()]); if (!$s) { http_response_code(404); exit('Introuvable.'); }
    if (val('SELECT COUNT(*) FROM users WHERE service_id=?', [$s['id']])) { flash('error', 'Suppression impossible : des utilisateurs sont rattachés à ce service.'); redirect(url('services')); }
    q('DELETE FROM services WHERE id=?', [$s['id']]); audit('service.suppression', 'services', $s['id'], $s, null); flash('success', 'Service supprimé.'); redirect(url('services'));
}
$edit = (int)qget('edit') ? row('SELECT * FROM services WHERE id=? AND ministere_id=?', [(int)qget('edit'), mid()]) : null;
page_start('Services et directions');
echo '<div class="grid gap-6 lg:grid-cols-3"><div class="lg:col-span-2">'; card_start('Services du ministère');
echo tbl_start() . th('Service') . th('Sigle') . th('Utilisateurs') . th('') . tbl_mid();
foreach (rows('SELECT s.*, (SELECT COUNT(*) FROM users u WHERE u.service_id=s.id) nb FROM services s WHERE s.ministere_id=? ORDER BY s.nom', [mid()]) as $s) {
    echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 font-semibold">' . e($s['nom']) . '</td><td class="px-4 py-3">' . e($s['sigle'] ?: '—') . '</td><td class="px-4 py-3">' . (int)$s['nb'] . '</td><td class="px-4 py-3 text-right whitespace-nowrap"><a class="mr-2 text-brand hover:underline" href="' . e(url('services', null, ['edit' => $s['id']])) . '">Modifier</a>' . confirm_form(url('services', 'delete'), '<button class="text-red-700 hover:underline">Supprimer</button>', 'Supprimer ce service ?', ['id' => $s['id']]) . '</td></tr>';
}
echo tbl_end(); card_end(); echo '</div>'; card_start($edit ? 'Modifier le service' : 'Nouveau service');
echo '<form method="post" action="' . e(url('services', 'save')) . '" class="space-y-4 p-5">' . csrf_field() . ($edit ? '<input type="hidden" name="id" value="' . $edit['id'] . '">' : '') . f_input('Nom du service', 'nom', $edit['nom'] ?? '', ['required' => 1, 'maxlength' => 190]) . f_input('Sigle', 'sigle', $edit['sigle'] ?? '', ['maxlength' => 30]) . '<div class="flex gap-2">' . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer') . ($edit ? link_btn(url('services'), 'Annuler') : '') . '</div></form>'; card_end();
echo '</div>'; page_end();
