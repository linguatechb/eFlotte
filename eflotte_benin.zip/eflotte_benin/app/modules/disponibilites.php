<?php
declare(strict_types=1);

require_perm('disponibilites.view');
$start = valid_date(qget('debut')) ? qget('debut') : date('Y-m-d');
$span = in_array((int)qget('jours', '21'), [14, 21, 31], true) ? (int)qget('jours', '21') : 21;
$end = date('Y-m-d', strtotime("$start +" . ($span - 1) . ' days'));
$vehs = rows('SELECT id, marque, modele, immatriculation, etat FROM vehicules WHERE ministere_id=? AND est_archive=0 ORDER BY marque, modele', [mid()]);
$res = rows("SELECT vehicule_id, reference, destination, date_depart, date_retour, statut FROM reservations WHERE ministere_id=? AND statut IN ('Attribuée','En cours') AND vehicule_id IS NOT NULL AND DATE(date_depart) <= ? AND (CASE WHEN statut='En cours' THEN GREATEST(date_retour,NOW()) ELSE date_retour END) >= ?", [mid(), $end, $start]);
$mnt = rows("SELECT vehicule_id, categorie, date_maintenance, CASE WHEN statut='En cours' AND date_fin IS NULL THEN '9999-12-31' ELSE COALESCE(date_fin, date_maintenance) END fin, statut FROM maintenances WHERE ministere_id=? AND statut IN ('Planifiée','En cours') AND date_maintenance <= ? AND (CASE WHEN statut='En cours' AND date_fin IS NULL THEN '9999-12-31' ELSE COALESCE(date_fin, date_maintenance) END) >= ?", [mid(), $end, $start]);

page_start('Calendrier des disponibilités', ['actions' => '<form method="get" class="flex flex-wrap items-end gap-2"><input type="hidden" name="p" value="disponibilites"><input type="date" name="debut" value="' . e($start) . '" class="' . f_cls() . ' w-auto"><select name="jours" class="' . f_cls() . ' w-auto">' . implode('', array_map(fn($n) => '<option value="' . $n . '"' . ($n === $span ? ' selected' : '') . '>' . $n . ' jours</option>', [14, 21, 31])) . '</select>' . btn('Afficher', 'secondary') . '</form>']);

// Recherche de disponibilité sur une période
$sd = qget('sdep'); $sr = qget('sret'); $found = null;
if ($sd !== '' && $sr !== '') { if (valid_dt($sd) && valid_dt($sr) && $sr > $sd) { $found = disponibles(dt_sql($sd), dt_sql($sr)); } else { flash('error', 'Période de recherche invalide.'); } }
card_start('Rechercher les véhicules et chauffeurs disponibles', '', 'mb-6');
echo '<form method="get" class="flex flex-wrap items-end gap-3 p-5"><input type="hidden" name="p" value="disponibilites"><input type="hidden" name="debut" value="' . e($start) . '"><input type="hidden" name="jours" value="' . $span . '">'
   . f_input('Départ', 'sdep', $sd, ['type' => 'datetime-local', 'required' => 1]) . f_input('Retour', 'sret', $sr, ['type' => 'datetime-local', 'required' => 1]) . btn('<i class="fa-solid fa-magnifying-glass"></i> Vérifier') . '</form>';
if ($found) {
    echo '<div class="grid gap-4 border-t border-slate-100 p-5 md:grid-cols-2"><div><h3 class="mb-2 text-sm font-bold">Véhicules disponibles (' . count($found['vehicules']) . ')</h3>';
    if (!$found['vehicules']) { echo '<p class="text-sm text-red-700">Aucun véhicule disponible sur cette période.</p>'; }
    foreach ($found['vehicules'] as $v) { echo '<div class="mb-1.5 flex items-center justify-between rounded-lg bg-emerald-50 px-3 py-2 text-sm"><span><a class="font-semibold hover:underline" href="' . e(url('vehicules', 'show', ['id' => $v['id']])) . '">' . e($v['marque'] . ' ' . $v['modele']) . '</a> <span class="font-mono text-xs">' . e($v['immatriculation']) . '</span></span>' . ($v['warnings'] ? '<span class="text-xs text-amber-700" title="' . e(implode(' ', $v['warnings'])) . '"><i class="fa-solid fa-triangle-exclamation"></i></span>' : '') . '</div>'; }
    echo '</div>';
    if (can('chauffeurs.view')) { echo '<div><h3 class="mb-2 text-sm font-bold">Chauffeurs disponibles (' . count($found['chauffeurs']) . ')</h3>'; if (!$found['chauffeurs']) { echo '<p class="text-sm text-red-700">Aucun chauffeur disponible.</p>'; } foreach ($found['chauffeurs'] as $c) { echo '<div class="mb-1.5 rounded-lg bg-emerald-50 px-3 py-2 text-sm">' . e($c['nom'] . ' ' . $c['prenoms']) . ' <span class="text-xs text-slate-500">· permis ' . e($c['categorie_permis']) . '</span></div>'; } echo '</div>'; }
    echo '</div>';
}
card_end();

card_start('Planning des véhicules', '<span class="text-xs text-slate-500">' . fmt_date($start) . ' → ' . fmt_date($end) . '</span>');
echo '<div class="flex flex-wrap gap-4 px-5 pt-4 text-xs text-slate-600"><span><i class="inline-block h-3 w-3 rounded bg-emerald-100 ring-1 ring-emerald-300"></i> Libre</span><span><i class="inline-block h-3 w-3 rounded bg-sky-500"></i> Mission attribuée / en cours</span><span><i class="inline-block h-3 w-3 rounded bg-amber-400"></i> Maintenance</span><span><i class="inline-block h-3 w-3 rounded bg-slate-400"></i> Immobilisé / réformé</span></div>';
echo '<div class="overflow-x-auto p-5"><table class="border-separate border-spacing-y-1 text-xs"><thead><tr><th class="sticky left-0 z-10 min-w-[12rem] bg-white pr-3 text-left font-semibold text-slate-500">Véhicule</th>';
for ($i = 0; $i < $span; $i++) { $t = strtotime("$start +$i days"); $we = in_array(date('N', $t), ['6', '7'], true); echo '<th class="min-w-[1.5rem] px-0.5 text-center font-medium ' . ($we ? 'text-slate-400' : 'text-slate-600') . (date('Y-m-d', $t) === date('Y-m-d') ? ' text-brand' : '') . '"><div>' . date('d', $t) . '</div><div class="text-[9px] uppercase text-slate-400">' . ['', 'L', 'M', 'M', 'J', 'V', 'S', 'D'][(int)date('N', $t)] . '</div></th>'; }
echo '</tr></thead><tbody>';
foreach ($vehs as $v) {
    echo '<tr><td class="sticky left-0 z-10 bg-white pr-3"><a class="font-semibold text-slate-800 hover:text-brand" href="' . e(url('vehicules', 'show', ['id' => $v['id']])) . '">' . e($v['marque'] . ' ' . $v['modele']) . '</a><div class="font-mono text-[10px] text-slate-400">' . e($v['immatriculation']) . '</div></td>';
    for ($i = 0; $i < $span; $i++) {
        $day = date('Y-m-d', strtotime("$start +$i days")); $cls = 'bg-emerald-50 ring-1 ring-inset ring-emerald-200'; $tip = 'Libre';
        if (in_array($v['etat'], ['Immobilisé', 'Réformé'], true)) { $cls = 'bg-slate-400'; $tip = $v['etat']; }
        foreach ($mnt as $m) { if ((int)$m['vehicule_id'] === (int)$v['id'] && $m['date_maintenance'] <= $day && $m['fin'] >= $day) { $cls = 'bg-amber-400'; $tip = 'Maintenance : ' . $m['categorie']; } }
        foreach ($res as $r) { if ((int)$r['vehicule_id'] === (int)$v['id'] && substr($r['date_depart'], 0, 10) <= $day && ($r['statut'] === 'En cours' ? max(substr($r['date_retour'], 0, 10), date('Y-m-d')) : substr($r['date_retour'], 0, 10)) >= $day) { $cls = 'bg-sky-500'; $tip = $r['reference'] . ' — ' . $r['destination'] . ' (' . fmt_dt($r['date_depart']) . ' → ' . fmt_dt($r['date_retour']) . ')'; } }
        echo '<td class="px-0.5"><div class="cal-cell rounded ' . $cls . '" title="' . e($day . ' : ' . $tip) . '"></div></td>';
    }
    echo '</tr>';
}
echo '</tbody></table></div>'; if (!$vehs) { echo empty_state('Aucun véhicule dans le parc.'); } card_end(); page_end();
