<?php
declare(strict_types=1);

const DEMO_ACCOUNTS = [
    'agent'        => ['agent@eflotte.bj', 'Agent@2026'],
    'validateur'   => ['validateur@eflotte.bj', 'Valid@2026'],
    'gestionnaire' => ['gestionnaire@eflotte.bj', 'Flotte@2026'],
    'superadmin'   => ['admin@eflotte.bj', 'Admin@2026'],
];

if ($A === 'logout' && is_post()) { do_logout(); flash('success', 'Vous avez été déconnecté.'); redirect(url('auth', 'login')); }

if ($A === 'profil') {
    $u = user(); if (!$u) { redirect(url('auth', 'login')); }
    if (is_post()) {
        $cur = $_POST['current'] ?? ''; $new = $_POST['new'] ?? ''; $conf = $_POST['confirm'] ?? '';
        $full = row('SELECT password_hash FROM users WHERE id=?', [uid()]);
        if (!password_verify((string)$cur, $full['password_hash'])) { flash('error', 'Le mot de passe actuel est incorrect.'); }
        elseif ($new !== $conf) { flash('error', 'La confirmation ne correspond pas au nouveau mot de passe.'); }
        elseif ($err = password_policy_error((string)$new)) { flash('error', $err); }
        else {
            q('UPDATE users SET password_hash=? WHERE id=?', [password_hash((string)$new, PASSWORD_DEFAULT), uid()]);
            audit('users.mot_de_passe_modifie', 'users', uid());
            flash('success', 'Votre mot de passe a été modifié.'); redirect(url('auth', 'profil'));
        }
        redirect(url('auth', 'profil'));
    }
    page_start('Mon profil');
    $info = ROLE_INFO[$u['role']];
    echo '<div class="grid gap-6 lg:grid-cols-2">';
    card_start('Informations du compte');
    echo '<dl class="grid grid-cols-3 gap-y-3 p-5 text-sm">';
    foreach ([['Nom complet', $u['prenoms'] . ' ' . $u['nom']], ['Email', $u['email']], ['Matricule', $u['matricule'] ?: '—'], ['Service', $u['service_nom'] ?: '—'], ['Profil', $info[0]], ['Fonction', $info[1]], ['Dernière connexion', fmt_dt($u['derniere_connexion'])]] as [$k, $v]) {
        echo '<dt class="text-slate-500">' . e($k) . '</dt><dd class="col-span-2 font-medium">' . e($v) . '</dd>';
    }
    echo '</dl><div class="border-t border-slate-100 p-5"><h3 class="mb-2 text-sm font-bold">Vos autorisations</h3><ul class="space-y-1.5 text-sm text-slate-600">';
    foreach ($info[2] as $perm) { echo '<li class="flex gap-2"><i class="fa-solid fa-check mt-1 text-xs text-brand"></i>' . e($perm) . '</li>'; }
    echo '</ul></div>'; card_end();
    card_start('Changer le mot de passe');
    echo '<form method="post" class="space-y-4 p-5">' . csrf_field()
        . f_input('Mot de passe actuel', 'current', '', ['type' => 'password', 'required' => 1, 'autocomplete' => 'current-password'])
        . f_input('Nouveau mot de passe', 'new', '', ['type' => 'password', 'required' => 1, 'autocomplete' => 'new-password', 'help' => '8 caractères minimum, avec majuscule, minuscule et chiffre.'])
        . f_input('Confirmer le nouveau mot de passe', 'confirm', '', ['type' => 'password', 'required' => 1, 'autocomplete' => 'new-password'])
        . btn('<i class="fa-solid fa-key"></i> Enregistrer') . '</form>';
    card_end(); echo '</div>';
    page_end(); exit;
}

// ------------------------------------------------------------------ Connexion
if (user()) { redirect(url('dashboard')); }
$error = null;
if (is_post()) {
    [$ok, $msg] = attempt_login(mb_strtolower(post('email')), (string)($_POST['password'] ?? ''));
    if ($ok) { flash('success', 'Bienvenue, ' . e(user()['prenoms']) . '.'); redirect(url('dashboard')); }
    $error = $msg;
}
$min = row('SELECT nom, sigle FROM ministeres ORDER BY id LIMIT 1') ?? ['nom' => 'Ministère', 'sigle' => ''];
$showDemo = (int)param('afficher_comptes_demo', 1) === 1;
page_start('Connexion');
echo '<div class="grid min-h-screen lg:grid-cols-[minmax(0,26rem)_1fr]">';
echo '<div class="flex flex-col bg-white"><div class="flex h-2">' . '<span class="flex-1 bg-brand"></span><span class="flex-1 bg-accent"></span><span class="flex-1 bg-danger"></span></div>';
echo '<div class="flex flex-1 flex-col justify-center px-8 py-10 sm:px-12"><div class="mb-8 flex items-center gap-3"><div class="grid h-12 w-12 place-items-center rounded-xl bg-brand text-accent"><i class="fa-solid fa-car-on text-xl"></i></div><div><div class="text-2xl font-extrabold tracking-tight text-brand">eFlotte Bénin</div><div class="text-xs text-slate-500">Gestion du parc automobile de l\'administration publique</div></div></div>';
echo '<h1 class="text-xl font-bold text-slate-900">Connexion</h1><p class="mt-1 text-sm text-slate-500">' . e($min['nom']) . '</p>';
if ($error) { echo '<div class="mt-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800"><i class="fa-solid fa-circle-xmark mr-2"></i>' . e($error) . '</div>'; }
echo '<form method="post" class="mt-6 space-y-4" autocomplete="on">' . csrf_field()
   . '<div><label class="mb-1 block text-sm font-medium" for="email">Adresse e-mail</label><input id="email" name="email" type="email" required autofocus value="' . e(post('email')) . '" class="' . f_cls() . '"></div>'
   . '<div><label class="mb-1 block text-sm font-medium" for="password">Mot de passe</label><div class="relative"><input id="password" name="password" type="password" required class="' . f_cls() . ' pr-10"><button type="button" data-toggle-pwd="#password" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700" aria-label="Afficher le mot de passe"><i class="fa-regular fa-eye"></i></button></div></div>'
   . '<button type="submit" class="w-full rounded-lg bg-brand px-4 py-2.5 text-sm font-semibold text-white hover:bg-brand-dark"><i class="fa-solid fa-right-to-bracket mr-2"></i>Se connecter</button></form>';
echo '<p class="mt-8 text-[11px] leading-relaxed text-slate-400">Toutes les connexions et opérations sont tracées. La bande tricolore est un élément graphique et ne représente pas l\'emblème national.</p></div></div>';

echo '<div class="bg-slate-50 px-6 py-10 lg:px-12"><div class="mx-auto max-w-4xl">';
if ($showDemo) {
    echo '<h2 class="text-lg font-bold text-slate-900">Comptes de démonstration</h2><p class="mt-1 text-sm text-slate-500">Quatre profils distincts, chacun avec ses autorisations propres, vérifiées côté serveur. Cliquez sur « Utiliser » pour pré-remplir le formulaire.</p>';
    echo '<div class="mt-6 grid gap-4 md:grid-cols-2">';
    foreach (DEMO_ACCOUNTS as $code => [$mail, $pwd]) {
        [$lib, $fonction, $droits] = ROLE_INFO[$code];
        echo '<article class="flex flex-col rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><header><h3 class="font-bold text-slate-900">' . e($lib) . '</h3><p class="mt-0.5 text-xs text-slate-500"><span class="font-semibold text-slate-600">Fonction :</span> ' . e($fonction) . '</p></header>';
        echo '<ul class="mt-3 flex-1 space-y-1 text-[13px] text-slate-600">'; foreach ($droits as $d) { echo '<li class="flex gap-2"><i class="fa-solid fa-check mt-1 text-[10px] text-brand"></i><span>' . e($d) . '</span></li>'; } echo '</ul>';
        echo '<div class="mt-4 rounded-lg bg-slate-50 p-3 font-mono text-xs"><div><span class="text-slate-400">E-mail&nbsp;&nbsp;&nbsp;</span> <b>' . e($mail) . '</b></div><div class="mt-1"><span class="text-slate-400">Mot de passe</span> <b>' . e($pwd) . '</b></div></div>';
        echo '<button type="button" data-fill="' . e($mail) . '" data-pwd="' . e($pwd) . '" class="mt-3 rounded-lg border border-brand/30 px-3 py-1.5 text-sm font-semibold text-brand hover:bg-brand-50">Utiliser ce compte</button></article>';
    }
    echo '</div><p class="mt-5 text-xs text-slate-500">Comptes complémentaires (mêmes mots de passe par profil) : <span class="font-mono">agent2@eflotte.bj</span> et <span class="font-mono">agent3@eflotte.bj</span> (Agent@2026), <span class="font-mono">validateur2@eflotte.bj</span> (Valid@2026).</p>';
} else {
    echo '<div class="rounded-xl border border-slate-200 bg-white p-8"><h2 class="text-lg font-bold">Plateforme sécurisée</h2><p class="mt-2 text-sm text-slate-500">Utilisez les identifiants fournis par l\'administrateur de votre ministère.</p></div>';
}
echo '</div></div></div>';
page_end();
