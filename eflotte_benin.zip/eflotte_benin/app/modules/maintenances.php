<?php
declare(strict_types=1);

require_perm('maintenances.view');
const MNT_STATUTS = ['Planifiée', 'En cours', 'Terminée'];
function mnt_get(int $id): ?array { return row('SELECT * FROM maintenances WHERE id=? AND ministere_id=?', [$id, mid()]); }

if ($A === 'save' && is_post()) {
    require_perm('maintenances.manage');
    $id = post_int('id'); $old = $id ? mnt_get($id) : null; if ($id && !$old) { http_response_code(404); exit('Maintenance introuvable.'); }
    $d = ['vehicule_id' => (int)post('vehicule_id'), 'type' => post('type'), 'categorie' => post('categorie'), 'description' => post('description'), 'statut' => post('statut'), 'date_maintenance' => post('date_maintenance'),
          'date_fin' => post('date_fin') ?: null, 'kilometrage' => post('kilometrage') !== '' ? (int)post('kilometrage') : null, 'prestataire' => post('prestataire'), 'cout' => (int)post('cout'),
          'pieces_remplacees' => post('pieces_remplacees'), 'prochaine_echeance' => post('prochaine_echeance') ?: null, 'observations' => post('observations')];
    $errs = []; $v = veh_row($d['vehicule_id']);
    if (!$v) { $errs[] = 'Véhicule invalide.'; }
    if (!in_array($d['type'], ['Préventive', 'Corrective'], true)) { $errs[] = 'Type invalide.'; }
    if (!in_array($d['categorie'], MNT_CATS, true)) { $errs[] = 'Catégorie invalide.'; }
    if (!in_array($d['statut'], MNT_STATUTS, true)) { $errs[] = 'Statut invalide.'; }
    if ($d['description'] === '') { $errs[] = 'La description est obligatoire.'; }
    if (!valid_date($d['date_maintenance'])) { $errs[] = 'Date de maintenance invalide.'; }
    if ($d['date_fin'] && (!valid_date($d['date_fin']) || $d['date_fin'] < $d['date_maintenance'])) { $errs[] = 'La date de fin est invalide ou antérieure au début.'; }
    if ($d['prochaine_echeance'] && !valid_date($d['prochaine_echeance'])) { $errs[] = 'Date de prochaine échéance invalide.'; }
    if ($d['cout'] < 0) { $errs[] = 'Le coût ne peut pas être négatif.'; }
    if (!$errs && $d['statut'] !== 'Terminée') {
        $end = $d['date_fin'] ?: ($d['statut'] === 'En cours' ? '9999-12-31' : $d['date_maintenance']);
        if ($d['statut'] === 'En cours' && $v['etat'] === 'En mission') { $errs[] = 'Ce véhicule est actuellement en mission : impossible de le passer « En cours » de maintenance.'; }
        foreach (rows("SELECT reference FROM reservations WHERE vehicule_id=? AND statut IN ('Attribuée','En cours') AND DATE(date_depart) <= ? AND DATE(date_retour) >= ?", [$d['vehicule_id'], $end, $d['date_maintenance']]) as $c) { $errs[] = 'Conflit avec la mission attribuée ' . $c['reference'] . ' : réattribuez-la d\'abord.'; }
    }
    $file = $old['justificatif'] ?? null; $newFile = null;
    if (!$errs && has_upload('justificatif')) { try { [$newFile] = save_upload($_FILES['justificatif'], 'justif', UPLOAD_PRIVATE . '/justificatifs'); $d['justificatif'] = $newFile; } catch (RuntimeException $e) { $errs[] = $e->getMessage(); } }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect($id ? url('maintenances', 'form', ['id' => $id]) : url('maintenances', 'form')); }
    if ($old) { update('maintenances', $id, $d); if ($newFile && $old['justificatif']) { delete_file($old['justificatif'], UPLOAD_PRIVATE . '/justificatifs'); } [$o, $n] = diff_vals($old, $d); audit('maintenance.modification', 'maintenances', $id, $o, $n); }
    else { $d += ['ministere_id' => mid(), 'created_by' => uid()]; $id = insert('maintenances', $d); audit('maintenance.creation', 'maintenances', $id, null, $d); }
    if ($d['kilometrage'] !== null && $d['kilometrage'] > (int)$v['kilometrage']) { q('UPDATE vehicules SET kilometrage=? WHERE id=?', [$d['kilometrage'], $v['id']]); }
    sync_maintenance_depense($id); sync_vehicule_etat((int)$d['vehicule_id']); if ($old && (int)$old['vehicule_id'] !== (int)$d['vehicule_id']) { sync_vehicule_etat((int)$old['vehicule_id']); }
    unset($_SESSION['old']); flash('success', 'Maintenance enregistrée.' . ($d['statut'] === 'En cours' ? ' Le véhicule est désormais bloqué à l\'attribution.' : '')); redirect(url('maintenances'));
}
if ($A === 'finish' && is_post()) {
    require_perm('maintenances.manage'); $m = mnt_get((int)post('id')); if (!$m) { http_response_code(404); exit('Introuvable.'); }
    $cout = post('cout') !== '' ? (int)post('cout') : (int)$m['cout'];
    update('maintenances', (int)$m['id'], ['statut' => 'Terminée', 'date_fin' => $m['date_fin'] ?: date('Y-m-d'), 'cout' => max(0, $cout)]);
    sync_maintenance_depense((int)$m['id']); sync_vehicule_etat((int)$m['vehicule_id']);
    audit('maintenance.cloture', 'maintenances', $m['id'], ['statut' => $m['statut']], ['statut' => 'Terminée']); flash('success', 'Maintenance terminée : le véhicule est de nouveau disponible (si aucune autre intervention en cours).'); redirect(url('maintenances'));
}
if ($A === 'delete' && is_post()) {
    require_perm('maintenances.manage'); $m = mnt_get((int)post('id')); if (!$m) { http_response_code(404); exit('Introuvable.'); }
    q('DELETE FROM maintenances WHERE id=?', [$m['id']]); delete_file($m['justificatif'], UPLOAD_PRIVATE . '/justificatifs'); sync_vehicule_etat((int)$m['vehicule_id']);
    audit('maintenance.suppression', 'maintenances', $m['id'], $m, null); flash('success', 'Maintenance supprimée (la dépense liée a été retirée).'); redirect(url('maintenances'));
}
function veh_row(int $id): ?array { return row('SELECT * FROM vehicules WHERE id=? AND ministere_id=? AND est_archive=0', [$id, mid()]); }

if ($A === 'form') {
    require_perm('maintenances.manage'); $id = (int)qget('id'); $m = $id ? mnt_get($id) : null; if ($id && !$m) { http_response_code(404); exit('Introuvable.'); }
    $m = array_merge($m ?? ['vehicule_id' => qget('vehicule_id'), 'type' => 'Préventive', 'categorie' => 'Vidange', 'description' => '', 'statut' => 'Planifiée', 'date_maintenance' => date('Y-m-d'), 'date_fin' => '', 'kilometrage' => '', 'prestataire' => '', 'cout' => 0, 'pieces_remplacees' => '', 'prochaine_echeance' => '', 'observations' => '', 'justificatif' => null], $_SESSION['old'] ?? []); unset($_SESSION['old']);
    page_start($id ? 'Modifier la maintenance' : 'Nouvelle maintenance');
    echo '<form method="post" enctype="multipart/form-data" action="' . e(url('maintenances', 'save')) . '">' . csrf_field() . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : '') . '<div class="grid gap-6 lg:grid-cols-3">';
    card_start('Intervention', '', 'lg:col-span-2'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_select('Véhicule', 'vehicule_id', vehicule_options(), $m['vehicule_id'], ['required' => 1, 'empty' => '— Choisir —', 'col' => 'sm:col-span-2'])
        . f_select('Type', 'type', ['Préventive' => 'Préventive', 'Corrective' => 'Corrective'], $m['type'], ['required' => 1]) . f_select('Catégorie', 'categorie', array_combine(MNT_CATS, MNT_CATS), $m['categorie'], ['required' => 1])
        . f_textarea('Description', 'description', $m['description'], ['required' => 1, 'col' => 'sm:col-span-2', 'rows' => 2]) . f_select('Statut', 'statut', array_combine(MNT_STATUTS, MNT_STATUTS), $m['statut'], ['required' => 1, 'help' => '« En cours » bloque l\'attribution du véhicule.'])
        . f_input('Kilométrage au moment de l\'intervention', 'kilometrage', $m['kilometrage'], ['type' => 'number', 'min' => 0]) . f_input('Date de début / d\'intervention', 'date_maintenance', $m['date_maintenance'], ['type' => 'date', 'required' => 1]) . f_input('Date de fin', 'date_fin', $m['date_fin'], ['type' => 'date'])
        . f_input('Prestataire', 'prestataire', $m['prestataire'], ['maxlength' => 150]) . f_input('Coût (FCFA)', 'cout', $m['cout'], ['type' => 'number', 'min' => 0, 'step' => 1, 'help' => 'Une dépense (Entretien/Réparation) est générée automatiquement une fois l\'intervention en cours/terminée.'])
        . f_textarea('Pièces remplacées', 'pieces_remplacees', $m['pieces_remplacees'], ['col' => 'sm:col-span-2', 'rows' => 2]) . f_input('Prochaine échéance', 'prochaine_echeance', $m['prochaine_echeance'], ['type' => 'date']) . f_textarea('Observations', 'observations', $m['observations'], ['rows' => 2]) . '</div>'; card_end();
    card_start('Justificatif'); echo '<div class="space-y-3 p-5">' . ($m['justificatif'] ? '<a class="text-sm font-semibold text-brand hover:underline" target="_blank" href="' . e(url('documents', 'justificatif', ['t' => 'maintenances', 'id' => $id])) . '"><i class="fa-solid fa-paperclip"></i> Justificatif actuel</a>' : '') . '<input type="file" name="justificatif" accept="application/pdf,image/jpeg,image/png,image/webp" class="block w-full"><p class="text-xs text-slate-500">PDF ou image — ' . (int)param('upload_max_mb', 10) . ' Mo max. Stocké hors accès public.</p></div>'; card_end();
    echo '</div><div class="mt-6 flex justify-end gap-2">' . link_btn(url('maintenances'), 'Annuler') . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer') . '</div></form>'; page_end(); exit;
}

$w = ['x.ministere_id=?']; $p = [mid()];
if (($q = qget('q')) !== '') { $w[] = '(x.description LIKE ? OR x.prestataire LIKE ? OR v.immatriculation LIKE ? OR v.marque LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
if ((int)qget('vehicule_id')) { $w[] = 'x.vehicule_id=?'; $p[] = (int)qget('vehicule_id'); }
if (in_array(qget('statut'), MNT_STATUTS, true)) { $w[] = 'x.statut=?'; $p[] = qget('statut'); }
if (in_array(qget('type'), ['Préventive', 'Corrective'], true)) { $w[] = 'x.type=?'; $p[] = qget('type'); }
if (in_array(qget('categorie'), MNT_CATS, true)) { $w[] = 'x.categorie=?'; $p[] = qget('categorie'); }
$pg = paginate('x.*, v.marque, v.modele, v.immatriculation', 'maintenances x JOIN vehicules v ON v.id=x.vehicule_id WHERE ' . implode(' AND ', $w), $p, ['date' => 'x.date_maintenance', 'veh' => 'v.marque', 'cat' => 'x.categorie', 'cout' => 'x.cout', 'statut' => 'x.statut', 'echeance' => 'x.prochaine_echeance'], 'date', 'desc');
$tot = (float)val('SELECT COALESCE(SUM(x.cout),0) FROM maintenances x JOIN vehicules v ON v.id=x.vehicule_id WHERE ' . implode(' AND ', $w), $p);
page_start('Maintenance du parc', ['actions' => can('maintenances.manage') ? link_btn(url('maintenances', 'form'), '<i class="fa-solid fa-plus"></i> Nouvelle maintenance', 'primary') : '']);
$enc = (int)val("SELECT COUNT(*) FROM maintenances WHERE ministere_id=? AND statut='En cours'", [mid()]); $plan = (int)val("SELECT COUNT(*) FROM maintenances WHERE ministere_id=? AND statut='Planifiée'", [mid()]);
echo '<div class="mb-5 grid gap-3 sm:grid-cols-3">' . stat_card('Interventions en cours', (string)$enc, 'fa-wrench', 'amber') . stat_card('Interventions planifiées', (string)$plan, 'fa-calendar-check', 'sky') . stat_card('Coût (filtre courant)', fcfa($tot), 'fa-coins', 'brand') . '</div>';
card_start(); echo search_bar(['vehicule_id' => [vehicule_options(true), 'Tous les véhicules'], 'statut' => [array_combine(MNT_STATUTS, MNT_STATUTS), 'Tous statuts'], 'type' => [['Préventive' => 'Préventive', 'Corrective' => 'Corrective'], 'Tous types'], 'categorie' => [array_combine(MNT_CATS, MNT_CATS), 'Toutes catégories']], 'Description, prestataire, véhicule…');
if (!$pg['rows']) { echo empty_state('Aucune maintenance enregistrée.', 'fa-screwdriver-wrench'); } else {
    echo tbl_start() . th_sort('Date', 'date', $pg) . th_sort('Véhicule', 'veh', $pg) . th('Type') . th_sort('Catégorie', 'cat', $pg) . th('Prestataire') . th_sort('Coût', 'cout', $pg) . th_sort('Échéance', 'echeance', $pg) . th_sort('Statut', 'statut', $pg) . th('') . tbl_mid();
    foreach ($pg['rows'] as $m) {
        $act = ($m['justificatif'] ? '<a class="mr-2 text-slate-500 hover:text-brand" title="Justificatif" target="_blank" href="' . e(url('documents', 'justificatif', ['t' => 'maintenances', 'id' => $m['id']])) . '"><i class="fa-solid fa-paperclip"></i></a>' : '');
        if (can('maintenances.manage')) {
            if ($m['statut'] !== 'Terminée') { $act .= confirm_form(url('maintenances', 'finish'), '<button class="mr-2 text-emerald-700 hover:underline" title="Terminer">Terminer</button>', 'Marquer cette maintenance comme terminée ?', ['id' => $m['id']]); }
            $act .= '<a class="mr-2 text-brand hover:underline" href="' . e(url('maintenances', 'form', ['id' => $m['id']])) . '">Modifier</a>' . confirm_form(url('maintenances', 'delete'), '<button class="text-red-700 hover:underline">Supprimer</button>', 'Supprimer définitivement cette maintenance et la dépense liée ?', ['id' => $m['id']]);
        }
        echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 whitespace-nowrap">' . fmt_date($m['date_maintenance']) . '</td><td class="px-4 py-3"><a class="font-semibold hover:text-brand" href="' . e(url('vehicules', 'show', ['id' => $m['vehicule_id']])) . '">' . e($m['marque'] . ' ' . $m['modele']) . '</a><div class="font-mono text-xs text-slate-500">' . e($m['immatriculation']) . '</div></td><td class="px-4 py-3">' . badge($m['type']) . '</td><td class="px-4 py-3">' . e($m['categorie']) . '<div class="max-w-[16rem] truncate text-xs text-slate-500">' . e($m['description']) . '</div></td><td class="px-4 py-3">' . e($m['prestataire'] ?: '—') . '</td><td class="px-4 py-3 whitespace-nowrap">' . fcfa($m['cout']) . '</td><td class="px-4 py-3 whitespace-nowrap">' . fmt_date($m['prochaine_echeance']) . '</td><td class="px-4 py-3">' . badge($m['statut']) . '</td><td class="px-4 py-3 text-right whitespace-nowrap">' . $act . '</td></tr>';
    }
    echo tbl_end();
}
echo pager($pg); card_end(); page_end();
