<?php
declare(strict_types=1);

if ($A === 'ordre') {
    $r = get_reservation((int)qget('id'));          // le périmètre (agent/validateur/gestionnaire) est appliqué dans la requête
    if (!$r) { http_response_code(404); exit('Document introuvable ou accès non autorisé.'); }
    audit('document.ordre_mission.' . (qget('dl') ? 'telechargement' : 'consultation'), 'reservations', $r['id'], null, ['reference' => $r['reference'], 'fichier' => $r['ordre_mission_nom']]);
    stream_file(UPLOAD_PRIVATE . '/ordres_mission/' . basename($r['ordre_mission_fichier']), $r['ordre_mission_nom'], !qget('dl'));
}
if ($A === 'justificatif') {
    $map = ['maintenances' => 'maintenances.view', 'depenses' => 'depenses.view', 'assurances' => 'assurances.view', 'visites_techniques' => 'assurances.view'];
    $t = qget('t'); if (!isset($map[$t])) { http_response_code(404); exit('Type inconnu.'); }
    require_perm($map[$t]);
    $d = row("SELECT id, justificatif FROM `$t` WHERE id=? AND ministere_id=?", [(int)qget('id'), mid()]);
    if (!$d || !$d['justificatif']) { http_response_code(404); exit('Justificatif introuvable.'); }
    audit('document.justificatif.consultation', $t, $d['id'], null, ['fichier' => $d['justificatif']]);
    stream_file(UPLOAD_PRIVATE . '/justificatifs/' . basename($d['justificatif']), 'justificatif_' . $t . '_' . $d['id'] . '.' . pathinfo($d['justificatif'], PATHINFO_EXTENSION), true);
}
http_response_code(404); exit('Action inconnue.');
