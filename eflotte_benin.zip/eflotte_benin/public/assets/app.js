(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  // Menu mobile
  const sb = $('#sidebar'), ov = $('#overlay');
  const toggle = (open) => { if (!sb) return; sb.classList.toggle('-translate-x-full', !open); ov && ov.classList.toggle('hidden', !open); };
  $('#menu-btn') && $('#menu-btn').addEventListener('click', () => toggle(sb.classList.contains('-translate-x-full')));
  ov && ov.addEventListener('click', () => toggle(false));

  // Menu utilisateur
  const ub = $('#user-btn'), um = $('#user-menu');
  if (ub) { ub.addEventListener('click', (e) => { e.stopPropagation(); um.classList.toggle('hidden'); }); document.addEventListener('click', () => um.classList.add('hidden')); }

  // Notifications toast
  $$('.toast').forEach((t, i) => setTimeout(() => { t.style.transition = 'opacity .4s'; t.style.opacity = 0; setTimeout(() => t.remove(), 400); }, 7000 + i * 800));
  $$('.toast-x').forEach(b => b.addEventListener('click', () => b.closest('.toast').remove()));

  // Fenêtre de confirmation (opérations sensibles)
  const modal = $('#confirm-modal'); let pending = null;
  document.addEventListener('submit', (e) => {
    const f = e.target.closest('form[data-confirm]');
    if (!f || f.dataset.ok === '1') return;
    e.preventDefault(); pending = f; $('#confirm-msg').textContent = f.dataset.confirm;
    const danger = /supprim|archiv|rejet|restaur|réform|désactiv/i.test(f.dataset.confirm);
    $('#confirm-yes').className = 'rounded-lg px-4 py-2 text-sm font-semibold text-white ' + (danger ? 'bg-red-600 hover:bg-red-700' : 'bg-brand hover:bg-brand-dark');
    modal.classList.remove('hidden'); modal.classList.add('flex'); $('#confirm-yes').focus();
  });
  const close = () => { modal.classList.add('hidden'); modal.classList.remove('flex'); pending = null; };
  $('#confirm-no') && $('#confirm-no').addEventListener('click', close);
  $('#confirm-yes') && $('#confirm-yes').addEventListener('click', () => { if (pending) { pending.dataset.ok = '1'; const f = pending; close(); f.requestSubmit ? f.requestSubmit() : f.submit(); } });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });

  // Anti double-soumission
  document.addEventListener('submit', (e) => {
    if (e.defaultPrevented) return;
    const f = e.target; if (f.method && f.method.toLowerCase() !== 'post') return;
    $$('button[type=submit]', f).forEach(b => { setTimeout(() => { b.disabled = true; b.classList.add('opacity-60'); }, 0); });
  });

  // Afficher / masquer mot de passe
  $$('[data-toggle-pwd]').forEach(b => b.addEventListener('click', () => { const i = $(b.dataset.togglePwd); i.type = i.type === 'password' ? 'text' : 'password'; }));

  // Remplissage rapide des comptes de démonstration
  $$('[data-fill]').forEach(b => b.addEventListener('click', () => { $('#email').value = b.dataset.fill; $('#password').value = b.dataset.pwd; $('#password').focus(); }));

  // Aperçu image
  $$('input[data-preview]').forEach(inp => inp.addEventListener('change', () => { const t = $(inp.dataset.preview); if (t && inp.files[0]) { t.src = URL.createObjectURL(inp.files[0]); t.classList.remove('hidden'); } }));

  // Disponibilités en temps réel (formulaire de demande)
  const dep = $('#f-depart'), ret = $('#f-retour'), box = $('#dispo-box'), sel = $('#f-vehicule');
  if (dep && ret && box) {
    let timer;
    const run = () => {
      if (!dep.value || !ret.value || ret.value <= dep.value) { box.innerHTML = '<p class="text-sm text-slate-500">Renseignez les dates de départ et de retour pour afficher les véhicules disponibles.</p>'; return; }
      fetch(EFLOTTE.base + '?p=api&a=disponibles&depart=' + encodeURIComponent(dep.value) + '&retour=' + encodeURIComponent(ret.value), { credentials: 'same-origin' })
        .then(r => r.json()).then(d => {
          if (!d.vehicules) { box.textContent = 'Indisponible.'; return; }
          const cur = sel ? sel.value : '';
          if (sel) { sel.innerHTML = '<option value="">— Aucune préférence —</option>' + d.vehicules.map(v => '<option value="' + v.id + '"' + (String(v.id) === cur ? ' selected' : '') + '>' + v.label + '</option>').join(''); }
          box.innerHTML = d.vehicules.length ? '<p class="mb-2 text-sm font-medium text-emerald-800"><i class="fa-solid fa-circle-check"></i> ' + d.vehicules.length + ' véhicule(s) disponible(s) sur cette période</p><div class="flex flex-wrap gap-2">' + d.vehicules.map(v => '<span class="rounded-full bg-emerald-50 px-3 py-1 text-xs text-emerald-900 ring-1 ring-inset ring-emerald-600/20">' + v.label + '</span>').join('') + '</div>' : '<p class="text-sm font-medium text-red-700"><i class="fa-solid fa-circle-xmark"></i> Aucun véhicule disponible sur cette période. Vous pouvez tout de même soumettre la demande sans préférence.</p>';
        }).catch(() => { box.textContent = 'Impossible de vérifier les disponibilités.'; });
    };
    [dep, ret].forEach(i => i.addEventListener('change', () => { clearTimeout(timer); timer = setTimeout(run, 150); }));
    run();
  }

  // Filtre rapide (tableaux courts)
  $$('input[data-filter-table]').forEach(inp => inp.addEventListener('input', () => { const t = $(inp.dataset.filterTable); const v = inp.value.toLowerCase(); $$('tbody tr', t).forEach(tr => tr.classList.toggle('hidden', !tr.textContent.toLowerCase().includes(v))); }));
})();
