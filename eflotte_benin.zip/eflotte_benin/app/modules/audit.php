<?php
declare(strict_types=1);

require_perm('audit.view');
$w = ['(a.ministere_id=? OR a.ministere_id IS NULL)']; $p = [mid()];
if (($q = qget('q')) !== '') { $w[] = '(a.action LIKE ? OR a.user_nom LIKE ? OR a.ressource_type LIKE ? OR a.ressource_id = ? OR a.ip LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", $q, "%$q%"); }
if ((int)qget('user_id')) { $w[] = 'a.user_id=?'; $p[] = (int)qget('user_id'); }
if (qget('famille') !== '' && preg_match('/^[a-z_]+$/', qget('famille'))) { $w[] = 'a.action LIKE ?'; $p[] = qget('famille') . '.%'; }
if (valid_date(qget('du'))) { $w[] = 'a.created_at >= ?'; $p[] = qget('du') . ' 00:00:00'; }
if (valid_date(qget('au'))) { $w[] = 'a.created_at <= ?'; $p[] = qget('au') . ' 23:59:59'; }
$from = 'audit_logs a WHERE ' . implode(' AND ', $w);
if ($A === 'csv') {
    audit('audit.export', 'audit_logs', null, null, $_GET);
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="journal_audit_' . date('Ymd_His') . '.csv"');
    $o = fopen('php://output', 'w'); fwrite($o, "\xEF\xBB\xBF"); fputcsv($o, ['Date', 'Utilisateur', 'Action', 'Ressource', 'ID', 'Anciennes valeurs', 'Nouvelles valeurs', 'IP'], ';', '"', '\\');
    foreach (rows("SELECT * FROM $from ORDER BY a.id DESC LIMIT 20000", $p) as $r) { fputcsv($o, [$r['created_at'], $r['user_nom'], $r['action'], $r['ressource_type'], $r['ressource_id'], $r['anciennes_valeurs'], $r['nouvelles_valeurs'], $r['ip']], ';', '"', '\\'); }
    fclose($o); exit;
}
$pg = paginate('a.*', $from, $p, ['date' => 'a.id', 'user' => 'a.user_nom', 'action' => 'a.action', 'res' => 'a.ressource_type'], 'date', 'desc', 25);
$fam = array_column(rows("SELECT DISTINCT SUBSTRING_INDEX(action,'.',1) f FROM audit_logs ORDER BY f"), 'f', 'f');
$users = []; foreach (rows('SELECT id, prenoms, nom FROM users WHERE ministere_id=? ORDER BY nom', [mid()]) as $u) { $users[$u['id']] = $u['prenoms'] . ' ' . $u['nom']; }
page_start('Journal d\'audit', ['actions' => link_btn(qs(['a' => 'csv']), '<i class="fa-solid fa-file-csv"></i> Exporter (CSV)')]);
echo '<div class="mb-4 flex items-start gap-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-900"><i class="fa-solid fa-lock mt-0.5"></i><span>Le journal est <b>en lecture seule</b> : aucune modification ni suppression n\'est possible, y compris au niveau de la base de données (déclencheurs SQL).</span></div>';
card_start(); echo '<form method="get" action="' . e(BASE_URL) . '" class="flex flex-wrap items-end gap-2 px-5 py-3"><input type="hidden" name="p" value="audit"><div class="min-w-[10rem] flex-1"><input type="search" name="q" value="' . e(qget('q')) . '" placeholder="Action, utilisateur, ressource, IP…" class="' . f_cls() . '"></div>'
    . '<select name="user_id" class="' . f_cls() . ' w-auto max-w-[13rem]"><option value="">Tous utilisateurs</option>'; foreach ($users as $k => $v) { echo '<option value="' . $k . '"' . (qget('user_id') === (string)$k ? ' selected' : '') . '>' . e($v) . '</option>'; }
echo '</select><select name="famille" class="' . f_cls() . ' w-auto"><option value="">Toutes familles</option>'; foreach ($fam as $k) { echo '<option' . (qget('famille') === $k ? ' selected' : '') . '>' . e($k) . '</option>'; }
echo '</select><input type="date" name="du" value="' . e(qget('du')) . '" class="' . f_cls() . ' w-auto"><input type="date" name="au" value="' . e(qget('au')) . '" class="' . f_cls() . ' w-auto">' . btn('Filtrer') . '<a class="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50" href="' . e(url('audit')) . '">Réinitialiser</a></form>';
if (!$pg['rows']) { echo empty_state('Aucune entrée.', 'fa-clipboard-list'); } else {
    echo tbl_start() . th_sort('Date / heure', 'date', $pg) . th_sort('Utilisateur', 'user', $pg) . th_sort('Action', 'action', $pg) . th_sort('Ressource', 'res', $pg) . th('Détails') . th('IP') . tbl_mid();
    foreach ($pg['rows'] as $r) {
        $dt = ($r['anciennes_valeurs'] || $r['nouvelles_valeurs']) ? '<details class="text-xs"><summary class="cursor-pointer text-brand">Voir</summary><div class="mt-1 max-w-md space-y-1">' . ($r['anciennes_valeurs'] ? '<div><b class="text-red-700">Avant :</b> <code class="break-all">' . e($r['anciennes_valeurs']) . '</code></div>' : '') . ($r['nouvelles_valeurs'] ? '<div><b class="text-emerald-700">Après :</b> <code class="break-all">' . e($r['nouvelles_valeurs']) . '</code></div>' : '') . '</div></details>' : '<span class="text-slate-300">—</span>';
        $tone = preg_match('/echec|bloquee|refuse|suppression|rejet/', $r['action']) ? 'text-red-700' : 'text-slate-800';
        echo '<tr class="align-top hover:bg-slate-50"><td class="px-4 py-2.5 whitespace-nowrap text-xs">' . fmt_dt($r['created_at']) . '</td><td class="px-4 py-2.5">' . e($r['user_nom'] ?: '—') . '</td><td class="px-4 py-2.5 font-mono text-xs font-semibold ' . $tone . '">' . e($r['action']) . '</td><td class="px-4 py-2.5 text-xs">' . e($r['ressource_type'] ?: '') . ($r['ressource_id'] !== null ? ' #' . e($r['ressource_id']) : '') . '</td><td class="px-4 py-2.5">' . $dt . '</td><td class="px-4 py-2.5 font-mono text-xs text-slate-500">' . e($r['ip']) . '</td></tr>';
    }
    echo tbl_end();
}
echo pager($pg); card_end(); page_end();
