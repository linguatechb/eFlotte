<?php
declare(strict_types=1);

if ($A === 'disponibles') {
    if (!can('disponibilites.view')) { json_out(['error' => 'Accès refusé'], 403); }
    $d = qget('depart'); $r = qget('retour');
    if (!valid_dt($d) || !valid_dt($r) || $r <= $d) { json_out(['error' => 'Période invalide'], 422); }
    $res = disponibles(dt_sql($d), dt_sql($r));
    json_out(['vehicules' => array_map(fn($v) => ['id' => (int)$v['id'], 'label' => $v['marque'] . ' ' . $v['modele'] . ' — ' . $v['immatriculation']], $res['vehicules'])]);
}
if ($A === 'notifs') { json_out(['unread' => unread_count()]); }
json_out(['error' => 'Action inconnue'], 404);
