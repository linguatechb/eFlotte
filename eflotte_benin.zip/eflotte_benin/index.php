<?php
/**
 * Point d'entrée frontal : http://localhost/eflotte_benin/index.php
 * Charge la configuration puis exécute public/index.php.
 * BASE_URL est calculé dynamiquement à partir de $_SERVER['SCRIPT_NAME'] (voir app/bootstrap.php).
 */
define('EFLOTTE_ENTRY', true);
require __DIR__ . '/public/index.php';
