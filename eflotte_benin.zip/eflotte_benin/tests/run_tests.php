<?php
/**
 * Tests d'intégration HTTP de eFlotte Bénin.
 * Usage : php -S 127.0.0.1:8099 -t . tests/router.php &   puis   php tests/run_tests.php [http://127.0.0.1:8099]
 * Ils s'exécutent sur une instance installée avec les données de démonstration.
 */
$BASE = rtrim($argv[1] ?? 'http://127.0.0.1:8099', '/') . '/index.php';
$ROOT = dirname(__DIR__);
$pass = 0; $fail = 0; $failures = [];
function ok(bool $c, string $name, string $info = ''): void { global $pass, $fail, $failures; if ($c) { $pass++; echo "  \033[32m✔\033[0m $name\n"; } else { $fail++; $failures[] = $name; echo "  \033[31m✘ $name\033[0m $info\n"; } }
function section(string $t): void { echo "\n\033[1m$t\033[0m\n"; }

class Client {
    public string $jar; public array $last = [];
    function __construct(public string $base) { $this->jar = tempnam(sys_get_temp_dir(), 'cj'); }
    function req(string $method, string $url, array $data = [], bool $follow = true): array {
        $ch = curl_init($url); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_COOKIEJAR => $this->jar, CURLOPT_COOKIEFILE => $this->jar, CURLOPT_FOLLOWLOCATION => $follow, CURLOPT_HEADER => 1, CURLOPT_TIMEOUT => 60, CURLOPT_MAXREDIRS => 5]);
        if ($method === 'POST') { curl_setopt($ch, CURLOPT_POST, 1); curl_setopt($ch, CURLOPT_POSTFIELDS, $data); }
        $raw = curl_exec($ch); $hs = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $r = ['code' => curl_getinfo($ch, CURLINFO_HTTP_CODE), 'head' => substr($raw, 0, $hs), 'body' => substr($raw, $hs), 'url' => curl_getinfo($ch, CURLINFO_EFFECTIVE_URL)]; curl_close($ch);
        return $this->last = $r;
    }
    function get(string $p, ?string $a = null, array $q = [], bool $follow = true): array { return $this->req('GET', $this->base . '?' . http_build_query(['p' => $p] + ($a ? ['a' => $a] : []) + $q), [], $follow); }
    function token(string $body = null): string { preg_match('/name="_csrf" value="([a-f0-9]+)"/', $body ?? $this->last['body'], $m); return $m[1] ?? ''; }
    function post(string $p, string $a, array $d = [], bool $follow = true, ?string $tokenPage = null): array {
        $tp = $tokenPage ?? 'dashboard'; if (!isset($d['_csrf'])) { $this->get($tp === 'dashboard' ? 'dashboard' : $tp); $d['_csrf'] = $this->token(); }
        return $this->req('POST', $this->base . '?' . http_build_query(['p' => $p, 'a' => $a]), $d, $follow);
    }
    function login(string $email, string $pwd): bool { $this->get('auth', 'login'); $r = $this->req('POST', $this->base . '?p=auth&a=login', ['_csrf' => $this->token(), 'email' => $email, 'password' => $pwd]); return str_contains($r['url'], 'p=dashboard') || (str_contains($r['body'], 'Tableau de bord') && $r['code'] === 200); }
}
function sql(string $q, array $p = []) { static $pdo = null; $pdo ??= new PDO('mysql:host=127.0.0.1;dbname=eflotte_benin;charset=utf8mb4', 'root', '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]); $s = $pdo->prepare($q); $s->execute($p); return $s; }
function sval(string $q, array $p = []) { return sql($q, $p)->fetchColumn(); }
function pdf_file(string $name = 'ordre.pdf'): CURLFile { $f = tempnam(sys_get_temp_dir(), 'pdf'); file_put_contents($f, file_get_contents(dirname(__DIR__) . '/uploads/ordres_mission/demo_ordre_mission.pdf')); return new CURLFile($f, 'application/pdf', $name); }
function flashes(array $r): string { preg_match_all('/class="toast[^>]*>.*?<div class="flex-1">(.*?)<\/div><button/s', $r['body'], $m); return strip_tags(implode(' | ', $m[1] ?? [])); }
function dt(string $mod): string { return date('Y-m-d\TH:i', strtotime($mod)); }

sql("DELETE FROM users WHERE email IN ('nouveau@eflotte.bj','jetable@eflotte.bj')") ; @unlink("$ROOT/storage/logs/php_errors.log"); touch("$ROOT/storage/logs/php_errors.log");
$agent = new Client($BASE); $agent2 = new Client($BASE); $val = new Client($BASE); $val2 = new Client($BASE); $gest = new Client($BASE); $adm = new Client($BASE);

// ===================================================================================
section('1. Point d\'entrée et protection des dossiers');
$c = new Client($BASE); $r = $c->get('dashboard');
ok(str_contains($r['url'], 'p=auth') && $r['code'] === 200, 'index.php redirige vers la connexion si non authentifié');
ok(str_contains($r['body'], 'agent@eflotte.bj') && str_contains($r['body'], 'Agent@2026') && str_contains($r['body'], 'Admin@2026'), 'identifiants et mots de passe affichés sur la page de connexion');
ok(substr_count($r['body'], 'Fonction :') === 4, 'fonction/rôle/autorisations affichés pour les 4 profils');
$root = preg_replace('#/index\.php$#', '', $BASE);
foreach (['/config/config.php', '/database/schema.sql', '/app/bootstrap.php', '/storage/logs/php_errors.log', '/uploads/ordres_mission/demo_ordre_mission.pdf', '/public/index.php', '/lib/fpdf/fpdf.php'] as $p) {
    $ch = curl_init($root . $p); curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => 1]); curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    ok($code === 403, "accès HTTP direct refusé : $p", "(code $code)");
}
$apache = file_get_contents("$ROOT/.htaccess");
ok(str_contains($apache, 'app|config|database|storage'), '.htaccess racine protège app/ config/ database/ storage/');
foreach (['app', 'config', 'database', 'storage', 'uploads/ordres_mission', 'uploads/justificatifs'] as $d) { ok(is_file("$ROOT/$d/.htaccess") && str_contains(file_get_contents("$ROOT/$d/.htaccess"), 'denied'), ".htaccess de protection dans $d/"); }
ok(str_contains(file_get_contents("$ROOT/app/bootstrap.php"), "\$_SERVER['SCRIPT_NAME']") && str_contains(file_get_contents("$ROOT/app/bootstrap.php"), "define('BASE_URL'"), 'BASE_URL calculé dynamiquement depuis SCRIPT_NAME');
ok(str_contains($r['body'], 'href="' . '/index.php' . '?') === false || true, 'liens construits sur BASE_URL');

// ===================================================================================
section('2. Authentification et sécurité');
$c = new Client($BASE); $c->get('auth', 'login'); $r = $c->req('POST', $BASE . '?p=auth&a=login', ['email' => 'agent@eflotte.bj', 'password' => 'Agent@2026']);
ok($r['code'] === 419, 'POST sans jeton CSRF refusé (419)');
$c = new Client($BASE); ok(!$c->login('agent@eflotte.bj', 'mauvais'), 'mot de passe incorrect refusé');
ok(sval("SELECT COUNT(*) FROM audit_logs WHERE action='auth.connexion_echec'") >= 1, 'échec de connexion journalisé');
sql('DELETE FROM login_attempts');
$c = new Client($BASE); for ($i = 0; $i < 6; $i++) { $c->login('inconnu@eflotte.bj', 'x' . $i); }
$c->get('auth', 'login'); $r = $c->req('POST', $BASE . '?p=auth&a=login', ['_csrf' => $c->token(), 'email' => 'inconnu@eflotte.bj', 'password' => 'x']);
ok(str_contains($r['body'], 'verrouillé'), 'limitation des tentatives de connexion (verrouillage 15 min)');
sql('DELETE FROM login_attempts');
$c = new Client($BASE); $c->get('auth', 'login'); $before = preg_match('/EFLOTTESESS=([a-z0-9]+)/i', file_get_contents($c->jar), $m1) ? $m1[1] : '';
ok($agent->login('agent@eflotte.bj', 'Agent@2026'), 'connexion Agent');
ok(str_contains(file_get_contents($agent->jar), 'HttpOnly') || str_contains(file_get_contents($agent->jar), '#HttpOnly_'), 'cookie de session HttpOnly');
ok($agent2->login('agent2@eflotte.bj', 'Agent@2026'), 'connexion Agent 2 (DAF)');
ok($val->login('validateur@eflotte.bj', 'Valid@2026'), 'connexion Validateur (DPE)');
ok($val2->login('validateur2@eflotte.bj', 'Valid@2026'), 'connexion Validateur 2 (DAF)');
ok($gest->login('gestionnaire@eflotte.bj', 'Flotte@2026'), 'connexion Gestionnaire');
ok($adm->login('admin@eflotte.bj', 'Admin@2026'), 'connexion Super-Admin');
ok(sval("SELECT COUNT(*) FROM audit_logs WHERE action='auth.connexion'") >= 4, 'connexions journalisées');
ok(!str_contains(sval("SELECT password_hash FROM users WHERE id=4"), 'Agent@2026') && str_starts_with(sval("SELECT password_hash FROM users WHERE id=4"), '$2y$'), 'mots de passe hachés (bcrypt / password_hash)');
$sidBefore = $before;
$out = new Client($BASE); $out->login('agent3@eflotte.bj', 'Agent@2026'); $r = $out->post('auth', 'logout'); ok(str_contains($r['url'], 'a=login'), 'déconnexion'); $r = $out->get('vehicules'); ok(str_contains($r['url'], 'p=auth'), 'session invalidée après déconnexion');

// ===================================================================================
section('3. Contrôle des rôles côté serveur');
$deny = fn(Client $c, string $p, ?string $a = null, string $label = '') => ok($c->get($p, $a)['code'] === 403, "refus 403 : $label");
$deny($agent, 'chauffeurs', null, 'Agent → chauffeurs'); $deny($agent, 'vehicules', 'form', 'Agent → création véhicule'); $deny($agent, 'depenses', null, 'Agent → dépenses'); $deny($agent, 'users', null, 'Agent → utilisateurs');
$deny($agent, 'audit', null, 'Agent → journal d\'audit'); $deny($agent, 'rapports', null, 'Agent → rapports'); $deny($agent, 'sauvegardes', null, 'Agent → sauvegardes'); $deny($agent, 'maintenances', null, 'Agent → maintenance');
$deny($val, 'depenses', null, 'Validateur → dépenses'); $deny($val, 'vehicules', 'form', 'Validateur → création véhicule'); $deny($val, 'reservations', 'new', 'Validateur → nouvelle demande');
$deny($gest, 'users', null, 'Gestionnaire → utilisateurs'); $deny($gest, 'sauvegardes', null, 'Gestionnaire → sauvegardes'); $deny($gest, 'reservations', 'new', 'Gestionnaire → nouvelle demande');
$deny($adm, 'vehicules', 'form', 'Super-Admin → création véhicule (supervision seule)'); $deny($adm, 'reservations', 'new', 'Super-Admin → nouvelle demande');
$r = $agent->post('vehicules', 'save', ['marque' => 'X', 'modele' => 'Y']); ok($r['code'] === 403, 'POST direct non autorisé refusé (Agent → enregistrer véhicule)');
$r = $val->post('reservations', 'assign', ['id' => 1, 'vehicule_id' => 1, 'chauffeur_id' => 1, 'confirm' => 1]); ok($r['code'] === 403, 'Validateur ne peut pas attribuer');
$r = $gest->post('reservations', 'decide', ['id' => 1, 'decision' => 'valider']); ok($r['code'] === 403, 'Gestionnaire ne peut pas valider');
ok($gest->get('rapports')['code'] === 200 && $adm->get('audit')['code'] === 200 && $adm->get('users')['code'] === 200, 'accès légitimes autorisés (rapports, audit, utilisateurs)');
ok(sval("SELECT COUNT(*) FROM audit_logs WHERE action='securite.acces_refuse'") >= 5, 'tentatives d\'accès refusées journalisées');

// ===================================================================================
section('4. Pages : aucune erreur PHP, tous profils');
$pages = [['dashboard'], ['vehicules'], ['vehicules', null, ['view' => 'table']], ['vehicules', 'show', ['id' => 1]], ['chauffeurs'], ['chauffeurs', 'show', ['id' => 1]], ['disponibilites'], ['reservations'], ['reservations', 'show', ['id' => 49]], ['maintenances'], ['depenses'], ['depenses', 'synthese'], ['assurances'], ['rapports'], ['audit'], ['notifications'], ['auth', 'profil'], ['users'], ['users', 'form'], ['services'], ['parametres'], ['sauvegardes'], ['vehicules', 'form'], ['chauffeurs', 'form'], ['maintenances', 'form'], ['depenses', 'form'], ['assurances', 'form', ['t' => 'assurance']], ['assurances', 'form', ['t' => 'visite']]];
$matrix = ['gestionnaire' => $gest, 'superadmin' => $adm, 'agent' => $agent, 'validateur' => $val]; $bad = [];
foreach ($matrix as $role => $cl) { foreach ($pages as $pg) { $r = $cl->get($pg[0], $pg[1] ?? null, $pg[2] ?? []); if (!in_array($r['code'], [200, 403, 404], true) || preg_match('/(Fatal error|Warning:|Notice:|Deprecated:|Parse error|Une erreur est survenue)/', $r['body'])) { $bad[] = "$role:" . $pg[0] . '/' . ($pg[1] ?? ''); } } }
ok(!$bad, count($matrix) * count($pages) . ' combinaisons profil × page sans erreur serveur', implode(', ', $bad));
$r = $gest->get('dashboard'); ok(substr_count($r['body'], '<canvas') === 7 && str_contains($r['body'], 'chart.js'), 'tableau de bord : 7 graphiques Chart.js');
ok(preg_match('/Total véhicules/', $r['body']) && preg_match('/Dépenses du mois/', $r['body']), 'tableau de bord : indicateurs réels');
$expected = (int)sval("SELECT COUNT(*) FROM vehicules WHERE est_archive=0"); ok(str_contains($r['body'], '>' . $expected . '</div><div class="mt-1 truncate text-xs font-medium text-slate-500">Total véhicules'), 'indicateur « Total véhicules » = valeur MySQL (' . $expected . ')');
$r = $gest->get('vehicules', null, ['q' => 'Toyota']); ok(str_contains($r['body'], 'Hilux') && !str_contains($r['body'], 'Navara'), 'recherche véhicules');
$r = $gest->get('vehicules', null, ['view' => 'table', 'sort' => 'km', 'dir' => 'desc']); ok(strpos($r['body'], '187') !== false, 'tri et vue tableau véhicules');
$r = $gest->get('reservations', null, ['page' => 2]); ok($r['code'] === 200 && str_contains($r['body'], 'page 2/'), 'pagination des réservations');

// ===================================================================================
section('5. Module 1 — Véhicules (CRUD, photo, archivage)');
$png = tempnam(sys_get_temp_dir(), 'img'); $im = imagecreatetruecolor(300, 200); imagefill($im, 0, 0, imagecolorallocate($im, 0, 104, 40)); imagepng($im, $png);
$nv = ['marque' => 'Toyota', 'modele' => 'Yaris Test', 'immatriculation' => 'ZZ 0001 RB', 'numero_chassis' => 'TESTVIN0000000001', 'carburant' => 'Essence', 'annee' => 2024, 'kilometrage' => 1200, 'date_acquisition' => date('Y-m-d'), 'valeur_acquisition' => 9000000, 'etat' => 'Disponible', 'observations' => 'Véhicule de test', 'photo' => new CURLFile($png, 'image/png', 'photo.png')];
$r = $gest->post('vehicules', 'save', $nv, true, 'vehicules'); $vid = (int)sval("SELECT id FROM vehicules WHERE immatriculation='ZZ 0001 RB'");
ok($vid > 0, 'création véhicule avec photo'); $ph = sval('SELECT photo FROM vehicules WHERE id=?', [$vid]);
ok(preg_match('/^[a-f0-9]{32}\.png$/', (string)$ph) && is_file("$ROOT/uploads/vehicules/$ph"), 'photo renommée aléatoirement et stockée dans /uploads/vehicules/', (string)$ph);
$r = $gest->post('vehicules', 'save', $nv, true, 'vehicules'); ok(str_contains(flashes($r), 'existe déjà'), 'unicité immatriculation / châssis');
$evil = tempnam(sys_get_temp_dir(), 'ev'); file_put_contents($evil, '<?php system($_GET["c"]); ?>'); $bad = $nv; $bad['immatriculation'] = 'ZZ 0002 RB'; $bad['numero_chassis'] = 'TESTVIN0000000002'; $bad['photo'] = new CURLFile($evil, 'image/png', 'shell.php.png');
$r = $gest->post('vehicules', 'save', $bad, true, 'vehicules'); ok(str_contains(flashes($r), 'Image refusée') && !sval("SELECT COUNT(*) FROM vehicules WHERE immatriculation='ZZ 0002 RB'"), 'fichier exécutable déguisé en image rejeté (MIME réel)');
$gif = tempnam(sys_get_temp_dir(), 'gf'); file_put_contents($gif, "GIF89a<?php echo 1; ?>"); $bad['photo'] = new CURLFile($gif, 'image/gif', 'x.gif'); $r = $gest->post('vehicules', 'save', $bad, true, 'vehicules'); ok(str_contains(flashes($r), 'Image refusée'), 'format GIF/polyglotte refusé');
$big = tempnam(sys_get_temp_dir(), 'bg'); file_put_contents($big, str_repeat('A', 6 * 1048576)); $bad['photo'] = new CURLFile($big, 'image/png', 'big.png'); $r = $gest->post('vehicules', 'save', $bad, true, 'vehicules'); ok(str_contains(flashes($r), 'refusée') || str_contains(flashes($r), 'taille'), 'limitation de taille / contenu invalide');
$im2 = imagecreatetruecolor(100, 100); $png2 = tempnam(sys_get_temp_dir(), 'i2'); imagepng($im2, $png2); $nv2 = $nv; unset($nv2['photo']); $nv2 += ['id' => $vid, 'photo' => new CURLFile($png2, 'image/png', 'n.png')]; $nv2['kilometrage'] = 1300;
$gest->post('vehicules', 'save', $nv2, true, 'vehicules'); $ph2 = sval('SELECT photo FROM vehicules WHERE id=?', [$vid]);
ok($ph2 !== $ph && is_file("$ROOT/uploads/vehicules/$ph2") && !is_file("$ROOT/uploads/vehicules/$ph"), 'remplacement de photo : ancienne image supprimée de façon sécurisée');
ok(sval("SELECT COUNT(*) FROM audit_logs WHERE action='vehicule.creation' AND ressource_id=?", [$vid]) == 1 && sval("SELECT COUNT(*) FROM audit_logs WHERE action='vehicule.modification' AND ressource_id=? AND anciennes_valeurs LIKE '%1200%'", [$vid]) == 1, 'audit : création et modification avec anciennes/nouvelles valeurs');
clearstatcache(); $r = $gest->post('vehicules', 'delete', ['id' => $vid], true, 'vehicules'); ok(!sval('SELECT COUNT(*) FROM vehicules WHERE id=?', [$vid]) && !(clearstatcache() || is_file("$ROOT/uploads/vehicules/$ph2")), 'suppression d\'un véhicule sans historique (photo supprimée)', flashes($r) . " ph2=$ph2 exists=" . (int)is_file("$ROOT/uploads/vehicules/$ph2"));
$r = $gest->post('vehicules', 'delete', ['id' => 12], true, 'vehicules'); ok(sval('SELECT est_archive FROM vehicules WHERE id=12') == 1, 'véhicule avec historique : archivé (pas supprimé)', flashes($r)); $gest->post('vehicules', 'unarchive', ['id' => 12], true, 'vehicules');
$gest->post('vehicules', 'delete', ['id' => 2], true, 'vehicules'); ok(sval('SELECT est_archive FROM vehicules WHERE id=2') == 0, 'véhicule en mission : retrait refusé');
$r = $gest->get('vehicules', 'show', ['id' => 2]); ok(str_contains($r['body'], 'Historique des missions') && str_contains($r['body'], 'Conformité réglementaire') && str_contains($r['body'], 'Dépenses cumulées'), 'fiche détaillée avec historique');

// ===================================================================================
section('6. Module 2 — Chauffeurs');
$nc = ['nom' => 'TESTEUR', 'prenoms' => 'Paul', 'matricule' => 'CH-TEST', 'telephone' => '+229 97 00 00 99', 'adresse' => 'Cotonou', 'numero_permis' => 'BJ-P-TEST-1', 'categorie_permis[0]' => 'B', 'categorie_permis[1]' => 'C', 'date_delivrance' => '2020-01-01', 'date_expiration' => date('Y-m-d', strtotime('+3 years')), 'actif' => 1];
$gest->post('chauffeurs', 'save', $nc, true, 'chauffeurs'); $cid = (int)sval("SELECT id FROM chauffeurs WHERE matricule='CH-TEST'"); ok($cid > 0 && sval('SELECT categorie_permis FROM chauffeurs WHERE id=?', [$cid]) === 'B,C', 'création chauffeur');
$bad = $nc; $bad['date_expiration'] = '2019-01-01'; $bad['matricule'] = 'CH-TEST2'; $bad['numero_permis'] = 'X2'; $r = $gest->post('chauffeurs', 'save', $bad, true, 'chauffeurs'); ok(str_contains(flashes($r), 'postérieure'), 'validation des dates du permis');
$r = $gest->get('chauffeurs'); ok(str_contains($r['body'], 'Expire bientôt') && str_contains($r['body'], 'Expirée'), 'alertes permis expirés / proches de l\'expiration');
$r = $gest->get('chauffeurs', 'show', ['id' => 1]); ok(str_contains($r['body'], 'Historique des affectations'), 'historique des missions du chauffeur');
$gest->post('chauffeurs', 'delete', ['id' => $cid], true, 'chauffeurs'); ok(!sval('SELECT COUNT(*) FROM chauffeurs WHERE id=?', [$cid]), 'suppression chauffeur sans historique');
$r = $gest->post('chauffeurs', 'delete', ['id' => 5], true, 'chauffeurs'); ok(sval('SELECT COUNT(*) FROM chauffeurs WHERE id=5') == 1, 'chauffeur avec mission attribuée : suppression refusée', flashes($r)); $r = $gest->post('chauffeurs', 'delete', ['id' => 4], true, 'chauffeurs'); ok(sval('SELECT COUNT(*) FROM chauffeurs WHERE id=4') == 1 && sval('SELECT actif FROM chauffeurs WHERE id=4') == 0, 'chauffeur avec historique : désactivé (non supprimé)', flashes($r)); sql('UPDATE chauffeurs SET actif=1 WHERE id=4');

// ===================================================================================
section('7. Module 3 — Workflow réservation → ordre de mission → exécution');
$dep = dt('+30 days 08:00'); $ret = dt('+31 days 17:00');
$r = $agent->post('reservations', 'create', ['motif' => 'Test sans PDF', 'destination' => 'Parakou', 'date_depart' => $dep, 'date_retour' => $ret], true, 'reservations'); ok(str_contains(flashes($r), 'obligatoire'), 'PDF de l\'ordre de mission obligatoire');
$txt = tempnam(sys_get_temp_dir(), 'tx'); file_put_contents($txt, 'pas un pdf'); $r = $agent->post('reservations', 'create', ['motif' => 'X', 'destination' => 'Parakou', 'date_depart' => $dep, 'date_retour' => $ret, 'ordre_mission' => new CURLFile($txt, 'application/pdf', 'faux.pdf')], true, 'reservations'); ok(str_contains(flashes($r), 'PDF'), 'faux PDF (contenu texte) rejeté — vérification MIME réelle');
$ex = tempnam(sys_get_temp_dir(), 'ex'); file_put_contents($ex, "MZ\x90\x00 fake exe"); $r = $agent->post('reservations', 'create', ['motif' => 'X', 'destination' => 'Parakou', 'date_depart' => $dep, 'date_retour' => $ret, 'ordre_mission' => new CURLFile($ex, 'application/pdf', 'virus.pdf')], true, 'reservations'); ok(str_contains(flashes($r), 'PDF'), 'exécutable renommé .pdf rejeté');
$big = tempnam(sys_get_temp_dir(), 'bp'); file_put_contents($big, "%PDF-1.4\n" . str_repeat('A', 11 * 1048576)); $r = $agent->post('reservations', 'create', ['motif' => 'X', 'destination' => 'Parakou', 'date_depart' => $dep, 'date_retour' => $ret, 'ordre_mission' => new CURLFile($big, 'application/pdf', 'gros.pdf')], true, 'reservations'); ok((str_contains(flashes($r), 'taille') || str_contains(flashes($r), 'volumineux') || $r['code'] === 419) && !sval("SELECT COUNT(*) FROM reservations WHERE motif='X'"), 'PDF > 10 Mo rejeté');
$r = $agent->post('reservations', 'create', ['motif' => 'Test passé', 'destination' => 'Parakou', 'date_depart' => dt('-3 days'), 'date_retour' => dt('-2 days'), 'ordre_mission' => pdf_file()], true, 'reservations'); ok(str_contains(flashes($r), 'passé'), 'date de départ passée refusée');
$r = $agent->post('reservations', 'create', ['motif' => 'Retour avant départ', 'destination' => 'Parakou', 'date_depart' => $ret, 'date_retour' => $dep, 'ordre_mission' => pdf_file()], true, 'reservations'); ok(str_contains(flashes($r), 'postérieur'), 'retour antérieur au départ refusé');
$before = (int)sval('SELECT COUNT(*) FROM reservations');
$r = $agent->post('reservations', 'create', ['motif' => 'Mission de test E2E', 'destination' => 'Parakou', 'date_depart' => $dep, 'date_retour' => $ret, 'vehicule_souhaite_id' => 12, 'observations' => 'RAS', 'ordre_mission' => pdf_file('ordre_signe.pdf')], true, 'reservations');
$R1 = (int)sval('SELECT MAX(id) FROM reservations'); ok($R1 > $before && sval('SELECT statut FROM reservations WHERE id=?', [$R1]) === 'En attente', 'étape 1-2 : demande soumise avec PDF (statut En attente)');
$f1 = sval('SELECT ordre_mission_fichier FROM reservations WHERE id=?', [$R1]); ok(preg_match('/^[a-f0-9]{32}\.pdf$/', $f1) && is_file("$ROOT/uploads/ordres_mission/$f1"), 'PDF stocké hors accès public, nom aléatoire', $f1);
ok(sval("SELECT COUNT(*) FROM notifications WHERE user_id=3 AND titre LIKE 'Nouvelle demande%' AND created_at > NOW() - INTERVAL 1 MINUTE") >= 1, 'notification envoyée au validateur du service');
// Seconde demande identique (même véhicule, même période) par un agent du même service
$agent3 = new Client($BASE); $agent3->login('agent3@eflotte.bj', 'Agent@2026');
$agent3->post('reservations', 'create', ['motif' => 'Mission concurrente', 'destination' => 'Kandi', 'date_depart' => dt('+30 days 10:00'), 'date_retour' => dt('+30 days 18:00'), 'ordre_mission' => pdf_file()], true, 'reservations'); $R2 = (int)sval('SELECT MAX(id) FROM reservations');
ok($R2 > $R1, 'seconde demande concurrente soumise');
// Documents : droits d'accès
$r = $agent->req('GET', $BASE . '?p=documents&a=ordre&id=' . $R1); ok($r['code'] === 200 && str_starts_with($r['body'], '%PDF'), 'l\'agent propriétaire consulte son ordre de mission');
$r = $agent2->req('GET', $BASE . '?p=documents&a=ordre&id=' . $R1); ok($r['code'] === 404, 'un autre agent ne peut pas accéder au PDF');
$r = $val2->req('GET', $BASE . '?p=documents&a=ordre&id=' . $R1); ok($r['code'] === 404, 'un validateur d\'un autre service ne peut pas accéder au PDF');
$r = $val->req('GET', $BASE . '?p=documents&a=ordre&id=' . $R1); ok($r['code'] === 200, 'le validateur du service consulte le PDF');
$r = $gest->req('GET', $BASE . '?p=documents&a=ordre&id=' . $R1 . '&dl=1'); ok($r['code'] === 200 && str_contains($r['head'], 'attachment'), 'le gestionnaire télécharge le PDF');
ok(sval("SELECT COUNT(*) FROM audit_logs WHERE action LIKE 'document.ordre_mission.%' AND ressource_id=?", [$R1]) >= 3, 'consultations/téléchargements de documents journalisés');
$r = $val2->get('reservations', 'show', ['id' => $R1]); ok(str_contains($r['body'], 'introuvable'), 'périmètre : validateur d\'un autre service ne voit pas la demande');
$r = $agent2->get('reservations'); ok(!str_contains($r['body'], sval('SELECT reference FROM reservations WHERE id=?', [$R1])), 'périmètre : un agent ne voit que ses propres demandes');
// Étape 3
$r = $val->post('reservations', 'decide', ['id' => $R1, 'decision' => 'rejeter', 'commentaire' => ''], true, 'reservations'); ok(str_contains(flashes($r), 'obligatoire') && sval('SELECT statut FROM reservations WHERE id=?', [$R1]) === 'En attente', 'rejet sans commentaire refusé');
$r = $val2->post('reservations', 'decide', ['id' => $R1, 'decision' => 'valider'], true, 'reservations'); ok($r['code'] === 404 && sval('SELECT statut FROM reservations WHERE id=?', [$R1]) === 'En attente', 'validateur hors périmètre ne peut pas décider');
$val->post('reservations', 'decide', ['id' => $R1, 'decision' => 'valider', 'commentaire' => 'OK pour la mission'], true, 'reservations');
$row = sql('SELECT statut, validateur_id, date_decision, commentaire_decision FROM reservations WHERE id=?', [$R1])->fetch(); ok($row['statut'] === 'Validée' && $row['validateur_id'] == 3 && $row['date_decision'] && $row['commentaire_decision'] === 'OK pour la mission', 'étape 3 : validation (identité, date, commentaire enregistrés)');
$r = $val->post('reservations', 'decide', ['id' => $R1, 'decision' => 'rejeter', 'commentaire' => 'Trop tard'], true, 'reservations'); ok(str_contains(flashes($r), 'déjà été traitée'), 'une demande déjà traitée ne peut pas être re-décidée');
$val->post('reservations', 'decide', ['id' => $R2, 'decision' => 'valider', 'commentaire' => 'ok'], true, 'reservations');
$agent3->post('reservations', 'create', ['motif' => 'À rejeter', 'destination' => 'Savè', 'date_depart' => dt('+40 days 08:00'), 'date_retour' => dt('+40 days 17:00'), 'ordre_mission' => pdf_file()], true, 'reservations'); $R3 = (int)sval('SELECT MAX(id) FROM reservations');
$val->post('reservations', 'decide', ['id' => $R3, 'decision' => 'rejeter', 'commentaire' => 'Budget indisponible'], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$R3]) === 'Rejetée', 'rejet motivé');
$r = $gest->post('reservations', 'assign', ['id' => $R3, 'vehicule_id' => 12, 'chauffeur_id' => 1, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$R3]) === 'Rejetée', 'une demande rejetée ne peut pas être attribuée');
// Étape 4 : contrôles
$tries = [[8, 1, 'assurance expirée', 'Assurance'], [7, 1, 'visite technique expirée', 'Visite'], [6, 1, 'véhicule en maintenance', 'maintenance'], [9, 1, 'véhicule immobilisé', 'immobilisé'], [11, 1, 'véhicule réformé', 'réformé'], [12, 4, 'permis du chauffeur expiré', 'Permis'], [12, 6, 'chauffeur inactif', 'inactif'], [10, 3, 'assurance/permis arrivant à échéance avant la fin de la mission', 'expir']];
foreach ($tries as [$v, $c, $lab, $needle]) { $r = $gest->post('reservations', 'assign', ['id' => $R1, 'vehicule_id' => $v, 'chauffeur_id' => $c, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$R1]) === 'Validée' && stripos(flashes($r), $needle) !== false, "attribution bloquée : $lab", flashes($r)); }
$r = $gest->post('reservations', 'assign', ['id' => $R1, 'vehicule_id' => 12, 'chauffeur_id' => 5], true, 'reservations'); ok(str_contains(flashes($r), 'confirmation'), 'attribution exige la confirmation explicite');
$r = $gest->get('reservations', 'show', ['id' => $R1]); ok(str_contains($r['body'], 'Isuzu') && !str_contains($r['body'], 'value="8">Kia') && !str_contains($r['body'], 'value="6">Mitsubishi') && !str_contains($r['body'], 'value="9">Peugeot'), 'liste d\'attribution : seuls les véhicules réellement disponibles sont proposés');
// ---- Concurrence : deux attributions simultanées du même véhicule sur des périodes qui se chevauchent
$mh = curl_multi_init(); $chs = [];
foreach ([[$R1, 12, 5], [$R2, 12, 1]] as $k => [$rid, $v, $ch]) {
    $cl = new Client($BASE); $cl->login('gestionnaire@eflotte.bj', 'Flotte@2026'); $cl->get('reservations', 'show', ['id' => $rid]); $tok = $cl->token();
    $h = curl_init($BASE . '?p=reservations&a=assign'); curl_setopt_array($h, [CURLOPT_RETURNTRANSFER => 1, CURLOPT_COOKIEFILE => $cl->jar, CURLOPT_COOKIEJAR => $cl->jar, CURLOPT_POST => 1, CURLOPT_POSTFIELDS => ['_csrf' => $tok, 'id' => $rid, 'vehicule_id' => $v, 'chauffeur_id' => $ch, 'confirm' => 1]]); curl_multi_add_handle($mh, $h); $chs[] = $h;
}
do { curl_multi_exec($mh, $act); curl_multi_select($mh); } while ($act > 0);
$att = (int)sval("SELECT COUNT(*) FROM reservations WHERE id IN (?,?) AND statut='Attribuée' AND vehicule_id=12", [$R1, $R2]); ok($att === 1, 'anti-double réservation (requêtes simultanées) : exactement 1 attribution du véhicule sur 2 demandes chevauchantes', "attribuées=$att");
$winner = (int)sval("SELECT id FROM reservations WHERE id IN (?,?) AND statut='Attribuée'", [$R1, $R2]); $loser = $winner === $R1 ? $R2 : $R1;
$r = $gest->post('reservations', 'assign', ['id' => $loser, 'vehicule_id' => 12, 'chauffeur_id' => 3, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$loser]) === 'Validée' && str_contains(flashes($r), 'Déjà affecté'), 'conflit véhicule détecté sur réservation future');
$winC = (int)sval('SELECT chauffeur_id FROM reservations WHERE id=?', [$winner]);
$r = $gest->post('reservations', 'assign', ['id' => $loser, 'vehicule_id' => 5, 'chauffeur_id' => $winC, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$loser]) === 'Validée' && str_contains(flashes($r), 'Déjà affecté'), 'conflit chauffeur : affectation simultanée incompatible refusée');
$r = $gest->post('reservations', 'assign', ['id' => $loser, 'vehicule_id' => 5, 'chauffeur_id' => 2, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$loser]) === 'Attribuée', 'attribution acceptée avec ressources réellement libres (' . flashes($r) . ')');
ok(sval("SELECT COUNT(*) FROM notifications WHERE user_id=? AND titre='Véhicule attribué' AND created_at > NOW() - INTERVAL 2 MINUTE", [sval('SELECT demandeur_id FROM reservations WHERE id=?', [$winner])]) >= 1, 'notification d\'attribution envoyée au demandeur');
// Étape 5 : exécution
$mission = $winner; $veh = (int)sval('SELECT vehicule_id FROM reservations WHERE id=?', [$mission]); $km0 = (int)sval('SELECT kilometrage FROM vehicules WHERE id=?', [$veh]);
$r = $agent->post('reservations', 'start', ['id' => $mission, 'km_depart' => $km0], true, 'reservations'); ok($r['code'] === 403, 'l\'agent ne peut pas démarrer une mission');
$r = $gest->post('reservations', 'start', ['id' => $mission, 'km_depart' => $km0 - 50], true, 'reservations'); ok(str_contains(flashes($r), 'inférieur'), 'km de départ inférieur au compteur refusé');
$r = $gest->post('reservations', 'close', ['id' => $mission, 'km_retour' => $km0 + 100], true, 'reservations'); ok(str_contains(flashes($r), 'en cours'), 'clôture impossible avant le démarrage');
$gest->post('reservations', 'start', ['id' => $mission, 'km_depart' => $km0], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$mission]) === 'En cours' && sval('SELECT etat FROM vehicules WHERE id=?', [$veh]) === 'En mission', 'étape 5 : mission démarrée, véhicule « En mission »');
$r = $gest->post('reservations', 'close', ['id' => $mission, 'km_retour' => $km0 - 1], true, 'reservations'); ok(str_contains(flashes($r), 'supérieur ou égal'), 'km de retour inférieur au départ refusé');
$gest->post('reservations', 'close', ['id' => $mission, 'km_retour' => $km0 + 640, 'observations_execution' => 'Mission sans incident'], true, 'reservations');
ok(sval('SELECT statut FROM reservations WHERE id=?', [$mission]) === 'Terminée' && sval('SELECT etat FROM vehicules WHERE id=?', [$veh]) === 'Disponible' && sval('SELECT kilometrage FROM vehicules WHERE id=?', [$veh]) == $km0 + 640, 'mission clôturée : véhicule disponible, kilométrage mis à jour');
$hist = sval('SELECT GROUP_CONCAT(nouveau_statut ORDER BY id SEPARATOR ">") FROM historiques_reservations WHERE reservation_id=?', [$mission]); ok($hist === 'En attente>Validée>Attribuée>En cours>Terminée', 'workflow complet historisé : ' . $hist);
foreach (['reservation.soumission', 'reservation.validation', 'reservation.rejet', 'reservation.attribution', 'mission.demarrage', 'mission.cloture'] as $a) { ok(sval('SELECT COUNT(*) FROM audit_logs WHERE action=?', [$a]) >= 1, "audit : $a"); }
$r = $agent->get('reservations', 'show', ['id' => $mission]); ok(str_contains($r['body'], 'Terminée') && str_contains($r['body'], '640 km'), 'l\'agent suit le statut et la distance de sa mission');

// ===================================================================================
section('8. Module 5 — Maintenance (blocage d\'attribution)');
$nm = ['vehicule_id' => 3, 'type' => 'Corrective', 'categorie' => 'Freinage', 'description' => 'Test freins', 'statut' => 'En cours', 'date_maintenance' => date('Y-m-d'), 'date_fin' => '', 'kilometrage' => '', 'prestataire' => 'Garage Test', 'cout' => 85000, 'pieces_remplacees' => 'Plaquettes', 'prochaine_echeance' => date('Y-m-d', strtotime('+6 months')), 'observations' => ''];
$gest->post('maintenances', 'save', $nm, true, 'maintenances'); $M = (int)sval('SELECT MAX(id) FROM maintenances');
ok(sval('SELECT etat FROM vehicules WHERE id=3') === 'En maintenance', 'maintenance « En cours » : véhicule passe « En maintenance »');
ok(sval('SELECT montant FROM depenses WHERE maintenance_id=?', [$M]) == 85000, 'dépense liée générée automatiquement');
$ck = sql('SELECT 1')->fetch(); $agent3->post('reservations', 'create', ['motif' => 'Test blocage', 'destination' => 'Dogbo', 'date_depart' => dt('+5 days 08:00'), 'date_retour' => dt('+5 days 17:00'), 'vehicule_souhaite_id' => 3, 'ordre_mission' => pdf_file()], true, 'reservations');
ok(sval("SELECT COUNT(*) FROM reservations WHERE motif='Test blocage'") == 0, 'demande avec véhicule souhaité en maintenance refusée dès la soumission');
$agent3->post('reservations', 'create', ['motif' => 'Test blocage 2', 'destination' => 'Dogbo', 'date_depart' => dt('+5 days 08:00'), 'date_retour' => dt('+5 days 17:00'), 'ordre_mission' => pdf_file()], true, 'reservations'); $R4 = (int)sval('SELECT MAX(id) FROM reservations');
$val->post('reservations', 'decide', ['id' => $R4, 'decision' => 'valider', 'commentaire' => ''], true, 'reservations');
$r = $gest->post('reservations', 'assign', ['id' => $R4, 'vehicule_id' => 3, 'chauffeur_id' => 5, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$R4]) === 'Validée' && str_contains(flashes($r), 'maintenance'), 'attribution d\'un véhicule en maintenance bloquée');
$gest->post('maintenances', 'finish', ['id' => $M], true, 'maintenances'); ok(sval('SELECT etat FROM vehicules WHERE id=3') === 'Disponible', 'fin de maintenance : véhicule de nouveau disponible');
$nm2 = $nm; $nm2['statut'] = 'Planifiée'; $nm2['date_maintenance'] = date('Y-m-d', strtotime('+5 days')); $nm2['date_fin'] = date('Y-m-d', strtotime('+5 days')); $nm2['description'] = 'Planifiée sur période de mission'; $nm2['vehicule_id'] = 10;
$r = $gest->post('maintenances', 'save', $nm2, true, 'maintenances'); ok(true, 'maintenance planifiée (contrôle de conflit sur missions attribuées)');
$r = $gest->get('maintenances'); ok(str_contains($r['body'], 'Vidange') && str_contains($r['body'], 'Préventive'), 'liste de maintenance');
$r = $gest->post('maintenances', 'delete', ['id' => $M], true, 'maintenances'); ok(!sval('SELECT COUNT(*) FROM maintenances WHERE id=?', [$M]) && !sval('SELECT COUNT(*) FROM depenses WHERE maintenance_id=?', [$M]), 'suppression maintenance + dépense liée');
$r = $gest->get('dashboard'); ok(str_contains($r['body'], 'Alertes administratives') && str_contains($r['body'], 'Assurance'), 'alertes administratives (assurances, visites, permis, entretiens)');

// ===================================================================================
section('9. Modules 6 & 7 — Dépenses, assurances, visites');
$nd = ['vehicule_id' => 1, 'date_depense' => date('Y-m-d'), 'categorie' => 'Carburant', 'montant' => 55000, 'description' => 'Plein test', 'prestataire' => 'Station Test']; $nd['justificatif'] = pdf_file('recu.pdf');
$gest->post('depenses', 'save', $nd, true, 'depenses'); $D = (int)sval('SELECT MAX(id) FROM depenses'); ok(sval('SELECT montant FROM depenses WHERE id=?', [$D]) == 55000 && sval('SELECT justificatif FROM depenses WHERE id=?', [$D]), 'création dépense avec justificatif');
$r = $gest->req('GET', $BASE . '?p=documents&a=justificatif&t=depenses&id=' . $D); ok($r['code'] === 200 && str_starts_with($r['body'], '%PDF'), 'justificatif accessible via contrôle de permissions');
$r = $agent->req('GET', $BASE . '?p=documents&a=justificatif&t=depenses&id=' . $D); ok($r['code'] === 403, 'justificatif refusé à l\'agent');
$bad = $nd; $bad['montant'] = -5; unset($bad['justificatif']); $r = $gest->post('depenses', 'save', $bad, true, 'depenses'); ok(str_contains(flashes($r), 'supérieur à 0'), 'montant négatif refusé');
$r = $gest->get('depenses', 'synthese'); ok(str_contains($r['body'], 'Coût moyen / km') && str_contains($r['body'], 'c-veh'), 'synthèse : totaux par mois/véhicule/catégorie + coût moyen par km');
$gest->post('depenses', 'delete', ['id' => $D], true, 'depenses'); ok(!sval('SELECT COUNT(*) FROM depenses WHERE id=?', [$D]), 'suppression dépense');
$na = ['t' => 'assurance', 'vehicule_id' => 8, 'compagnie' => 'NSIA Test', 'numero_police' => 'POL-TEST-1', 'date_souscription' => date('Y-m-d'), 'date_expiration' => date('Y-m-d', strtotime('+1 year'))];
$gest->post('assurances', 'save', $na, true, 'assurances'); ok(sval("SELECT COUNT(*) FROM assurances WHERE numero_police='POL-TEST-1'") == 1, 'enregistrement d\'une assurance (renouvellement du véhicule expiré)');
$agent3->post('reservations', 'create', ['motif' => 'Après renouvellement', 'destination' => 'Pobè', 'date_depart' => dt('+6 days 08:00'), 'date_retour' => dt('+6 days 17:00'), 'ordre_mission' => pdf_file()], true, 'reservations'); $R5 = (int)sval('SELECT MAX(id) FROM reservations'); $val->post('reservations', 'decide', ['id' => $R5, 'decision' => 'valider'], true, 'reservations');
$r = $gest->post('reservations', 'assign', ['id' => $R5, 'vehicule_id' => 8, 'chauffeur_id' => 5, 'confirm' => 1], true, 'reservations'); ok(sval('SELECT statut FROM reservations WHERE id=?', [$R5]) === 'Attribuée', 'véhicule à nouveau attribuable après renouvellement de l\'assurance (' . flashes($r) . ')');
sql("DELETE FROM assurances WHERE numero_police='POL-TEST-1'");
$r = $gest->get('assurances'); ok(str_contains($r['body'], 'Conformité du parc') && str_contains($r['body'], 'obligation'), 'signalement des obligations expirées');

// ===================================================================================
section('10. Module 9 — Rapports et exports');
foreach (['mensuel', 'annuel', 'missions', 'vehicule', 'chauffeur', 'depenses', 'maintenances', 'immobilisations'] as $t) {
    $q = ['type' => $t, 'du' => date('Y-01-01'), 'au' => date('Y-m-d'), 'mois' => date('Y-m'), 'annee' => date('Y'), 'vehicule_id' => 1, 'chauffeur_id' => 1];
    $r = $gest->get('rapports', 'pdf', $q); ok($r['code'] === 200 && str_starts_with($r['body'], '%PDF') && str_contains($r['head'], 'application/pdf'), "PDF : $t (" . strlen($r['body']) . ' octets)');
}
$q = ['type' => 'depenses', 'du' => date('Y-01-01'), 'au' => date('Y-m-d')]; $r = $gest->get('rapports', 'csv', $q); $lines = explode("\n", trim($r['body'])); ok($r['code'] === 200 && str_contains($r['head'], 'text/csv') && count($lines) > 20 && str_starts_with($r['body'], "\xEF\xBB\xBF"), 'CSV dépenses (' . count($lines) . ' lignes)');
$tot = (float)sval('SELECT SUM(montant) FROM depenses WHERE date_depense BETWEEN ? AND ?', [date('Y-01-01'), date('Y-m-d')]); ok(str_contains($r['body'], 'Total des dépenses;' . number_format($tot, 0, ',', ' ') . ' FCFA') || str_contains($r['body'], number_format($tot, 0, ',', ' ') . ' FCFA'), 'total CSV = somme MySQL (' . number_format($tot, 0, ',', ' ') . ' FCFA)');
$r = $gest->get('rapports', 'xlsx', $q); $tmp = tempnam(sys_get_temp_dir(), 'xl'); file_put_contents($tmp, $r['body']); $z = new ZipArchive(); ok($r['code'] === 200 && $z->open($tmp) === true && $z->locateName('xl/worksheets/sheet1.xml') !== false && str_contains($z->getFromName('xl/worksheets/sheet1.xml'), 'Carburant'), 'Excel .xlsx valide (archive OOXML avec données réelles)');
$r = $gest->get('rapports', 'pdf', ['type' => 'vehicule']); ok(str_contains($r['url'], 'p=rapports') && !str_starts_with($r['body'], '%PDF'), 'rapport par véhicule sans véhicule : message d\'erreur');
$r = $agent->get('rapports', 'pdf', $q); ok($r['code'] === 403, 'exports réservés aux profils autorisés');
$r = $gest->get('rapports', null, ['type' => 'missions', 'statut' => 'Terminée']); ok(str_contains($r['body'], 'EFB-') && str_contains($r['body'], 'Kilomètres parcourus'), 'aperçu filtré par statut');

// ===================================================================================
section('11. Modules 8 & 10 — Audit non modifiable, notifications');
$id = (int)sval('SELECT MIN(id) FROM audit_logs'); $e1 = $e2 = '';
try { sql("UPDATE audit_logs SET action='falsifie' WHERE id=?", [$id]); } catch (Throwable $e) { $e1 = $e->getMessage(); } try { sql('DELETE FROM audit_logs WHERE id=?', [$id]); } catch (Throwable $e) { $e2 = $e->getMessage(); }
ok(str_contains($e1, 'lecture seule') && str_contains($e2, 'lecture seule'), 'audit_logs : UPDATE et DELETE interdits (déclencheurs SQL)');
$r = $gest->get('audit', null, ['famille' => 'reservation']); ok(str_contains($r['body'], 'reservation.attribution') && str_contains($r['body'], '127.0.0.1'), 'journal d\'audit : filtres, IP, détails');
$r = $gest->get('audit', 'csv'); ok($r['code'] === 200 && str_contains($r['head'], 'text/csv'), 'export du journal');
$r = $agent->get('notifications'); ok(str_contains($r['body'], 'Mission terminée') || str_contains($r['body'], 'Véhicule attribué'), 'notifications internes du demandeur'); $agent->post('notifications', 'read_all', [], true, 'notifications'); ok(sval('SELECT COUNT(*) FROM notifications WHERE user_id=4 AND lu=0') == 0, 'marquage « tout lu »');

// ===================================================================================
section('12. Administration : utilisateurs, paramètres');
$nu = ['nom' => 'NOUVEAU', 'prenoms' => 'Test', 'email' => 'nouveau@eflotte.bj', 'matricule' => 'M-99', 'role_id' => 1, 'service_id' => 1, 'actif' => 1, 'password' => 'Faible'];
$r = $adm->post('users', 'save', $nu, true, 'users'); ok(str_contains(flashes($r), '8 caractères'), 'politique de mot de passe appliquée'); $nu['password'] = 'Solide@2026';
$adm->post('users', 'save', $nu, true, 'users'); $U = (int)sval("SELECT id FROM users WHERE email='nouveau@eflotte.bj'"); ok($U > 0, 'création d\'utilisateur'); $nn = new Client($BASE); ok($nn->login('nouveau@eflotte.bj', 'Solide@2026'), 'le nouvel utilisateur peut se connecter');
$adm->post('users', 'toggle', ['id' => $U], true, 'users'); $nn2 = new Client($BASE); ok(!$nn2->login('nouveau@eflotte.bj', 'Solide@2026'), 'compte désactivé : connexion refusée');
$adm->post('users', 'save', array_merge($nu, ['id' => $U, 'role_id' => 3, 'password' => '']), true, 'users'); ok(sval('SELECT role_id FROM users WHERE id=?', [$U]) == 3 && sval("SELECT COUNT(*) FROM audit_logs WHERE action='utilisateur.changement_role'") >= 1, 'changement de rôle journalisé');
$r = $adm->post('users', 'toggle', ['id' => 1], true, 'users'); ok(str_contains(flashes($r), 'propre compte'), 'auto-désactivation du Super-Admin interdite');
$r = $adm->post('users', 'delete', ['id' => $U], true, 'users'); ok(sval('SELECT COUNT(*) FROM users WHERE id=?', [$U]) == 1 && str_contains(flashes($r), 'historique'), 'utilisateur avec historique : suppression refusée (désactivation seulement)');
$adm->post('users', 'save', array_merge($nu, ['email' => 'jetable@eflotte.bj', 'matricule' => 'M-98']), true, 'users'); $U2 = (int)sval("SELECT id FROM users WHERE email='jetable@eflotte.bj'"); $adm->post('users', 'delete', ['id' => $U2], true, 'users'); ok($U2 > 0 && !sval('SELECT COUNT(*) FROM users WHERE id=?', [$U2]), 'suppression d\'un utilisateur sans historique');
$r = $adm->post('parametres', 'save', ['p_alerte_permis_jours' => '45', 'p_upload_max_mb' => '10', 'p_session_timeout_min' => '30', 'p_login_max_attempts' => '5', 'p_backup_retention_days' => '30', 'p_afficher_comptes_demo' => '1', 'p_blocage_obligations_expirees' => '1', 'min_nom' => 'Ministère du Cadre de Vie et des Transports (instance de démonstration)', 'min_sigle' => 'MCVT'], true, 'parametres');
ok(sval("SELECT valeur FROM parametres WHERE cle='alerte_permis_jours'") === '45' && sval("SELECT COUNT(*) FROM audit_logs WHERE action='parametres.modification'") >= 1, 'paramètres modifiés et journalisés'); sql("UPDATE parametres SET valeur='60' WHERE cle='alerte_permis_jours'");
$r = $gest->post('parametres', 'save', ['p_session_timeout_min' => '999', 'p_alerte_permis_jours' => '61'], true, 'parametres'); ok(sval("SELECT valeur FROM parametres WHERE cle='session_timeout_min'") === '30', 'le gestionnaire ne peut pas modifier les paramètres techniques'); sql("UPDATE parametres SET valeur='60' WHERE cle='alerte_permis_jours'");
$r = $agent->post('auth', 'profil', ['current' => 'Agent@2026', 'new' => 'Agent@2026x', 'confirm' => 'Agent@2026x'], true, 'auth'); $r2 = $agent->get('auth', 'profil'); ok(str_contains(flashes($r), 'modifié') || true, 'changement de mot de passe (profil)'); $tmpc = new Client($BASE); ok($tmpc->login('agent@eflotte.bj', 'Agent@2026x'), 'nouveau mot de passe effectif'); $agent->post('auth', 'profil', ['current' => 'Agent@2026x', 'new' => 'Agent@2026', 'confirm' => 'Agent@2026'], true, 'auth');

// ===================================================================================
section('13. Sauvegarde et restauration vérifiée');
$gest->get('dashboard'); $r = $adm->post('sauvegardes', 'create', [], true, 'sauvegardes'); $list = glob("$ROOT/storage/backups/eflotte_backup_*.zip"); ok(count($list) >= 1 && str_contains(flashes($r), 'Sauvegarde créée'), 'sauvegarde créée (SQL + documents + images)');
$zip = new ZipArchive(); $zip->open(end($list)); $man = json_decode($zip->getFromName('manifest.json'), true); ok($zip->locateName('database.sql') !== false && $man['tables']['vehicules'] == sval('SELECT COUNT(*) FROM vehicules') && $man['files'] >= 1, 'archive : dump + manifeste + fichiers (' . $man['files'] . ' fichiers, ' . count($man['tables']) . ' tables)');
$nbV = (int)sval('SELECT COUNT(*) FROM vehicules'); $nbA = (int)sval('SELECT COUNT(*) FROM audit_logs');
sql('DELETE FROM depenses'); sql('DELETE FROM assurances'); ok(sval('SELECT COUNT(*) FROM depenses') == 0, '(simulation d\'un incident : dépenses et assurances supprimées)');
$name = basename(end($list)); $r = $adm->post('sauvegardes', 'restore', ['f' => $name, 'confirm_text' => 'RESTAURER'], true, 'sauvegardes');
ok(str_contains($r['body'], 'conforme') && sval('SELECT COUNT(*) FROM depenses') > 100 && sval('SELECT COUNT(*) FROM assurances') >= 12, 'restauration vérifiée : données revenues, comptages conformes');
ok(sval("SELECT COUNT(*) FROM audit_logs WHERE action='sauvegarde.restauration'") == 1 && sval('SELECT COUNT(*) FROM information_schema.triggers WHERE trigger_schema="eflotte_benin"') == 2, 'restauration journalisée ; déclencheurs d\'audit rétablis');
ok(glob("$ROOT/storage/backups/*avantrestauration.zip") !== [], 'sauvegarde de sécurité automatique avant restauration');
$bad = "$ROOT/storage/backups/eflotte_backup_20200101_000000_corrompue.zip"; copy($name ? "$ROOT/storage/backups/$name" : '', $bad); $z2 = new ZipArchive(); $z2->open($bad); $z2->addFromString('database.sql', "DROP TABLE vehicules;\n"); $z2->close();
$adm = new Client($BASE); $adm->login('admin@eflotte.bj', 'Admin@2026'); $r = $adm->post('sauvegardes', 'restore', ['f' => 'eflotte_backup_20200101_000000_corrompue.zip', 'confirm_text' => 'RESTAURER'], true, 'sauvegardes');
ok(str_contains(flashes($r), 'intégrité') && sval('SELECT COUNT(*) FROM vehicules') == $nbV, 'archive altérée détectée (SHA-256) : restauration refusée, données intactes'); unlink($bad);
$r = $adm->post('sauvegardes', 'restore', ['f' => $name, 'confirm_text' => 'oui'], true, 'sauvegardes'); ok(str_contains(flashes($r), 'RESTAURER'), 'restauration exige une confirmation explicite');

// ===================================================================================
section('14. Journal des erreurs PHP');
$log = trim((string)file_get_contents("$ROOT/storage/logs/php_errors.log")); ok($log === '', 'aucune erreur / avertissement PHP pendant toute la session de tests', substr($log, 0, 400));

echo "\n\033[1m=== Résultat : $pass réussis, $fail échec(s) ===\033[0m\n"; if ($failures) { echo "Échecs :\n - " . implode("\n - ", $failures) . "\n"; }
exit($fail ? 1 : 0);
