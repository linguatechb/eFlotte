<?php
declare(strict_types=1);

require_perm('chauffeurs.view');
const PERMIS_CATS = ['A', 'B', 'C', 'D', 'E'];
function chauf_get(int $id): ?array { return row('SELECT * FROM chauffeurs WHERE id=? AND ministere_id=?', [$id, mid()]); }
function permis_badge(array $c): string { return badge(echeance_statut($c['date_expiration'], (int)param('alerte_permis_jours', 60))); }

if ($A === 'save' && is_post()) {
    require_perm('chauffeurs.manage');
    $id = post_int('id'); $old = $id ? chauf_get($id) : null; if ($id && !$old) { http_response_code(404); exit('Chauffeur introuvable.'); }
    $cats = array_values(array_intersect(PERMIS_CATS, (array)($_POST['categorie_permis'] ?? [])));
    $d = ['nom' => mb_strtoupper(post('nom')), 'prenoms' => post('prenoms'), 'matricule' => mb_strtoupper(post('matricule')), 'telephone' => post('telephone'), 'adresse' => post('adresse'),
          'numero_permis' => mb_strtoupper(post('numero_permis')), 'categorie_permis' => implode(',', $cats), 'date_delivrance' => post('date_delivrance'), 'date_expiration' => post('date_expiration'),
          'actif' => post('actif') === '1' ? 1 : 0, 'observations' => post('observations')];
    $errs = [];
    foreach (['nom' => 'Le nom', 'prenoms' => 'Les prénoms', 'matricule' => 'Le matricule administratif', 'numero_permis' => 'Le numéro de permis'] as $k => $l) { if ($d[$k] === '') { $errs[] = "$l est obligatoire."; } }
    if (!preg_match('/^[0-9+ ()\-]{8,20}$/', $d['telephone'])) { $errs[] = 'Numéro de téléphone invalide.'; }
    if (!$cats) { $errs[] = 'Sélectionnez au moins une catégorie de permis.'; }
    if (!valid_date($d['date_delivrance']) || !valid_date($d['date_expiration'])) { $errs[] = 'Dates du permis invalides.'; }
    elseif ($d['date_expiration'] <= $d['date_delivrance']) { $errs[] = 'La date d\'expiration doit être postérieure à la date de délivrance.'; }
    if (val('SELECT COUNT(*) FROM chauffeurs WHERE ministere_id=? AND matricule=? AND id<>?', [mid(), $d['matricule'], $id ?? 0])) { $errs[] = 'Ce matricule existe déjà.'; }
    if (val('SELECT COUNT(*) FROM chauffeurs WHERE ministere_id=? AND numero_permis=? AND id<>?', [mid(), $d['numero_permis'], $id ?? 0])) { $errs[] = 'Ce numéro de permis existe déjà.'; }
    if ($old && !$d['actif'] && val("SELECT COUNT(*) FROM reservations WHERE chauffeur_id=? AND statut IN ('Attribuée','En cours')", [$id])) { $errs[] = 'Impossible de désactiver : le chauffeur a des missions attribuées ou en cours.'; }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect($id ? url('chauffeurs', 'form', ['id' => $id]) : url('chauffeurs', 'form')); }
    if ($old) { update('chauffeurs', $id, $d); [$o, $n] = diff_vals($old, $d); audit('chauffeur.modification', 'chauffeurs', $id, $o, $n); flash('success', 'Chauffeur mis à jour.'); }
    else { $d['ministere_id'] = mid(); $id = insert('chauffeurs', $d); audit('chauffeur.creation', 'chauffeurs', $id, null, $d); flash('success', 'Chauffeur enregistré.'); }
    unset($_SESSION['old']); redirect(url('chauffeurs', 'show', ['id' => $id]));
}
if ($A === 'delete' && is_post()) {
    require_perm('chauffeurs.manage'); $c = chauf_get((int)post('id')); if (!$c) { http_response_code(404); exit('Chauffeur introuvable.'); }
    if (val("SELECT COUNT(*) FROM reservations WHERE chauffeur_id=? AND statut IN ('Attribuée','En cours')", [$c['id']])) { flash('error', 'Suppression impossible : missions attribuées ou en cours.'); redirect(url('chauffeurs', 'show', ['id' => $c['id']])); }
    if (val('SELECT COUNT(*) FROM reservations WHERE chauffeur_id=?', [$c['id']])) { update('chauffeurs', (int)$c['id'], ['actif' => 0]); audit('chauffeur.desactivation', 'chauffeurs', $c['id'], ['actif' => 1], ['actif' => 0, 'motif' => 'historique existant']); flash('success', 'Le chauffeur possède un historique : il a été désactivé (traçabilité conservée).'); }
    else { q('DELETE FROM chauffeurs WHERE id=?', [$c['id']]); audit('chauffeur.suppression', 'chauffeurs', $c['id'], $c, null); flash('success', 'Chauffeur supprimé.'); }
    redirect(url('chauffeurs'));
}
if ($A === 'form') {
    require_perm('chauffeurs.manage'); $id = (int)qget('id'); $c = $id ? chauf_get($id) : null; if ($id && !$c) { http_response_code(404); exit('Chauffeur introuvable.'); }
    $c = array_merge($c ?? ['nom' => '', 'prenoms' => '', 'matricule' => '', 'telephone' => '', 'adresse' => '', 'numero_permis' => '', 'categorie_permis' => 'B', 'date_delivrance' => '', 'date_expiration' => '', 'actif' => 1, 'observations' => ''], $_SESSION['old'] ?? []); unset($_SESSION['old']);
    $selCats = is_array($c['categorie_permis']) ? $c['categorie_permis'] : decode_cat((string)$c['categorie_permis']);
    page_start($id ? 'Modifier le chauffeur' : 'Nouveau chauffeur');
    echo '<form method="post" action="' . e(url('chauffeurs', 'save')) . '">' . csrf_field() . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : '') . '<div class="grid gap-6 lg:grid-cols-2">';
    card_start('Identité'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_input('Nom', 'nom', $c['nom'], ['required' => 1, 'maxlength' => 80]) . f_input('Prénoms', 'prenoms', $c['prenoms'], ['required' => 1, 'maxlength' => 120])
        . f_input('Matricule administratif', 'matricule', $c['matricule'], ['required' => 1, 'maxlength' => 40]) . f_input('Téléphone', 'telephone', $c['telephone'], ['required' => 1, 'maxlength' => 20, 'placeholder' => '+229 01 97 00 00 00'])
        . f_input('Adresse', 'adresse', $c['adresse'], ['col' => 'sm:col-span-2', 'maxlength' => 255]) . f_select('Statut', 'actif', ['1' => 'Actif', '0' => 'Inactif'], (string)$c['actif'], ['col' => 'sm:col-span-2']) . '</div>'; card_end();
    card_start('Permis de conduire'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_input('Numéro de permis', 'numero_permis', $c['numero_permis'], ['required' => 1, 'col' => 'sm:col-span-2', 'maxlength' => 60])
        . '<div class="sm:col-span-2"><label class="mb-1 block text-sm font-medium">Catégories <span class="text-red-600">*</span></label><div class="flex flex-wrap gap-3">';
    foreach (PERMIS_CATS as $k) { echo '<label class="flex items-center gap-2 rounded-lg border border-slate-300 px-3 py-1.5 text-sm"><input type="checkbox" name="categorie_permis[]" value="' . $k . '" class="rounded border-slate-300 text-brand"' . (in_array($k, $selCats, true) ? ' checked' : '') . '> ' . $k . '</label>'; }
    echo '</div></div>' . f_input('Date de délivrance', 'date_delivrance', $c['date_delivrance'], ['type' => 'date', 'required' => 1]) . f_input('Date d\'expiration', 'date_expiration', $c['date_expiration'], ['type' => 'date', 'required' => 1])
        . f_textarea('Observations', 'observations', $c['observations'], ['col' => 'sm:col-span-2']) . '</div>'; card_end();
    echo '</div><div class="mt-6 flex justify-end gap-2">' . link_btn($id ? url('chauffeurs', 'show', ['id' => $id]) : url('chauffeurs'), 'Annuler') . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer') . '</div></form>';
    page_end(); exit;
}
if ($A === 'show') {
    $c = chauf_get((int)qget('id')); if (!$c) { http_response_code(404); page_start('Introuvable'); echo empty_state('Chauffeur introuvable.'); page_end(); exit; }
    $id = (int)$c['id'];
    $act = link_btn(url('chauffeurs'), '<i class="fa-solid fa-arrow-left"></i> Chauffeurs');
    if (can('chauffeurs.manage')) { $act .= link_btn(url('chauffeurs', 'form', ['id' => $id]), '<i class="fa-solid fa-pen"></i> Modifier') . confirm_form(url('chauffeurs', 'delete'), btn('<i class="fa-solid fa-trash"></i> Supprimer / désactiver', 'danger'), 'Supprimer ce chauffeur ? S\'il possède un historique, il sera seulement désactivé.', ['id' => $id]); }
    page_start($c['prenoms'] . ' ' . $c['nom'], ['actions' => $act]);
    $cur = row("SELECT r.id, r.reference, r.destination, r.date_depart, r.date_retour, r.statut FROM reservations r WHERE r.chauffeur_id=? AND r.statut IN ('En cours','Attribuée') AND r.date_retour >= NOW() ORDER BY r.date_depart LIMIT 1", [$id]);
    $dispo = !$c['actif'] ? 'Inactif' : (row("SELECT 1 x FROM reservations WHERE chauffeur_id=? AND statut='En cours'", [$id]) ? 'En mission' : ($c['date_expiration'] < date('Y-m-d') ? 'Permis expiré' : 'Disponible'));
    echo '<div class="grid gap-6 lg:grid-cols-3"><div class="space-y-6">';
    card_start('Fiche chauffeur'); echo '<div class="p-5"><div class="flex items-center gap-3"><div class="grid h-14 w-14 place-items-center rounded-full bg-brand text-lg font-bold text-white">' . e(mb_strtoupper(mb_substr($c['prenoms'], 0, 1) . mb_substr($c['nom'], 0, 1))) . '</div><div><div class="font-bold">' . e($c['prenoms'] . ' ' . $c['nom']) . '</div><div class="text-xs text-slate-500">Matricule ' . e($c['matricule']) . '</div></div></div>'
        . '<div class="mt-3">' . ($dispo === 'Permis expiré' ? badge($dispo, 'red') : badge($dispo, $dispo === 'Disponible' ? 'green' : ($dispo === 'En mission' ? 'sky' : 'slate'))) . '</div><dl class="mt-4 grid grid-cols-2 gap-y-2.5 text-sm">';
    foreach ([['Téléphone', $c['telephone']], ['Adresse', $c['adresse'] ?: '—'], ['N° de permis', $c['numero_permis']], ['Catégories', $c['categorie_permis']], ['Délivré le', fmt_date($c['date_delivrance'])], ['Expire le', fmt_date($c['date_expiration'])]] as [$k, $v]) { echo '<dt class="text-slate-500">' . e($k) . '</dt><dd class="text-right font-medium">' . e($v) . '</dd>'; }
    echo '</dl><div class="mt-3 flex items-center justify-between rounded-lg bg-slate-50 px-3 py-2 text-sm"><span>Validité du permis</span>' . permis_badge($c) . '</div>' . ($c['observations'] ? '<p class="mt-3 text-sm text-slate-600">' . nl2br(e($c['observations'])) . '</p>' : '') . '</div>'; card_end();
    $fullView = in_array(role(), ['gestionnaire', 'superadmin'], true);   // détail des missions : réservé à l'administration du parc
    if ($fullView) { card_start('Prochaine mission'); echo $cur ? '<div class="p-5 text-sm"><a class="font-semibold text-brand hover:underline" href="' . e(url('reservations', 'show', ['id' => $cur['id']])) . '">' . e($cur['reference']) . '</a> ' . badge($cur['statut']) . '<div class="mt-1">' . e($cur['destination']) . '</div><div class="text-xs text-slate-500">' . fmt_dt($cur['date_depart']) . ' → ' . fmt_dt($cur['date_retour']) . '</div></div>' : '<div class="px-5 py-4 text-sm text-slate-600">Aucune mission en cours ou attribuée.</div>'; card_end(); }
    echo '</div><div class="space-y-6 lg:col-span-2">';
    $h = rows("SELECT r.id, r.reference, r.destination, r.date_depart, r.date_retour, r.statut, r.km_depart, r.km_retour, CONCAT(v.marque,' ',v.modele) veh, v.immatriculation FROM reservations r LEFT JOIN vehicules v ON v.id=r.vehicule_id WHERE r.chauffeur_id=? ORDER BY r.date_depart DESC LIMIT 25", [$id]);
    $nbT = (int)val("SELECT COUNT(*) FROM reservations WHERE chauffeur_id=? AND statut='Terminée'", [$id]); $kmT = (int)val("SELECT COALESCE(SUM(km_retour-km_depart),0) FROM reservations WHERE chauffeur_id=? AND statut='Terminée'", [$id]);
    if ($fullView) { card_start('Historique des affectations et missions', '<span class="text-xs text-slate-500">' . $nbT . ' mission(s) terminée(s) · ' . nb($kmT) . ' km</span>');
    if (!$h) { echo empty_state('Aucune affectation enregistrée.'); } else {
        echo tbl_start() . th('Référence') . th('Destination') . th('Véhicule') . th('Période') . th('Km') . th('Statut') . tbl_mid();
        foreach ($h as $r) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-2.5"><a class="font-semibold text-brand hover:underline" href="' . e(url('reservations', 'show', ['id' => $r['id']])) . '">' . e($r['reference']) . '</a></td><td class="px-4 py-2.5">' . e($r['destination']) . '</td><td class="px-4 py-2.5">' . e($r['veh'] . ' ' . $r['immatriculation']) . '</td><td class="px-4 py-2.5 whitespace-nowrap text-xs">' . fmt_dt($r['date_depart']) . '<br>' . fmt_dt($r['date_retour']) . '</td><td class="px-4 py-2.5">' . ($r['km_retour'] !== null ? nb($r['km_retour'] - $r['km_depart']) : '—') . '</td><td class="px-4 py-2.5">' . badge($r['statut']) . '</td></tr>'; }
        echo tbl_end();
    }
    card_end(); } else { card_start('Activité'); echo '<div class="px-5 py-4 text-sm text-slate-600">' . $nbT . ' mission(s) terminée(s) · ' . nb($kmT) . ' km. Le détail des affectations est réservé à l\'administration du parc.</div>'; card_end(); }
    echo '</div></div>'; page_end(); exit;
}

$w = ['c.ministere_id=?']; $p = [mid()];
if (($q = qget('q')) !== '') { $w[] = '(c.nom LIKE ? OR c.prenoms LIKE ? OR c.matricule LIKE ? OR c.numero_permis LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
$s = qget('statut'); if ($s === 'actif') { $w[] = 'c.actif=1'; } elseif ($s === 'inactif') { $w[] = 'c.actif=0'; } elseif ($s === 'alerte') { $w[] = 'c.date_expiration <= DATE_ADD(CURDATE(), INTERVAL ' . (int)param('alerte_permis_jours', 60) . ' DAY)'; }
$pg = paginate("c.*, (SELECT COUNT(*) FROM reservations r WHERE r.chauffeur_id=c.id AND r.statut='Terminée') AS nb_missions, (SELECT COUNT(*) FROM reservations r WHERE r.chauffeur_id=c.id AND r.statut='En cours') AS en_cours", 'chauffeurs c WHERE ' . implode(' AND ', $w), $p, ['nom' => 'c.nom', 'permis' => 'c.date_expiration', 'missions' => 'nb_missions', 'statut' => 'c.actif'], 'nom', 'asc');
page_start('Chauffeurs', ['actions' => can('chauffeurs.manage') ? link_btn(url('chauffeurs', 'form'), '<i class="fa-solid fa-plus"></i> Nouveau chauffeur', 'primary') : '']);
$al = (int)val('SELECT COUNT(*) FROM chauffeurs WHERE ministere_id=? AND actif=1 AND date_expiration <= DATE_ADD(CURDATE(), INTERVAL ? DAY)', [mid(), (int)param('alerte_permis_jours', 60)]);
if ($al) { echo '<div class="mb-4 flex items-center gap-3 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900"><i class="fa-solid fa-triangle-exclamation"></i><span><b>' . $al . '</b> chauffeur(s) avec un permis expiré ou proche de l\'expiration.</span><a class="ml-auto font-semibold underline" href="' . e(qs(['statut' => 'alerte', 'page' => 1])) . '">Afficher</a></div>'; }
card_start(); echo search_bar(['statut' => [['actif' => 'Actifs', 'inactif' => 'Inactifs', 'alerte' => 'Permis à surveiller'], 'Tous les statuts']], 'Nom, matricule, n° de permis…');
if (!$pg['rows']) { echo empty_state('Aucun chauffeur trouvé.', 'fa-id-card'); } else {
    echo tbl_start() . th_sort('Chauffeur', 'nom', $pg) . th('Matricule') . th('Téléphone') . th('Permis') . th_sort('Expiration', 'permis', $pg) . th_sort('Missions', 'missions', $pg) . th_sort('Statut', 'statut', $pg) . th('') . tbl_mid();
    foreach ($pg['rows'] as $c) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 font-semibold">' . e($c['nom'] . ' ' . $c['prenoms']) . '</td><td class="px-4 py-3 font-mono text-xs">' . e($c['matricule']) . '</td><td class="px-4 py-3">' . e($c['telephone']) . '</td><td class="px-4 py-3">' . e($c['categorie_permis']) . '</td><td class="px-4 py-3 whitespace-nowrap">' . fmt_date($c['date_expiration']) . ' ' . permis_badge($c) . '</td><td class="px-4 py-3">' . (int)$c['nb_missions'] . ($c['en_cours'] ? ' ' . badge('En mission') : '') . '</td><td class="px-4 py-3">' . badge($c['actif'] ? 'Actif' : 'Inactif') . '</td><td class="px-4 py-3 text-right"><a class="text-brand hover:underline" href="' . e(url('chauffeurs', 'show', ['id' => $c['id']])) . '">Fiche</a></td></tr>'; }
    echo tbl_end();
}
echo pager($pg); card_end(); page_end();
