<?php
declare(strict_types=1);

require_perm('depenses.view');
function dep_get(int $id): ?array { return row('SELECT * FROM depenses WHERE id=? AND ministere_id=?', [$id, mid()]); }

if ($A === 'save' && is_post()) {
    require_perm('depenses.manage'); $id = post_int('id'); $old = $id ? dep_get($id) : null; if ($id && !$old) { http_response_code(404); exit('Introuvable.'); }
    if ($old && $old['maintenance_id']) { flash('error', 'Cette dépense est liée à une maintenance : modifiez la maintenance.'); redirect(url('depenses')); }
    $d = ['vehicule_id' => (int)post('vehicule_id'), 'date_depense' => post('date_depense'), 'categorie' => post('categorie'), 'montant' => (int)post('montant'), 'description' => post('description'), 'prestataire' => post('prestataire')];
    $errs = [];
    if (!val('SELECT COUNT(*) FROM vehicules WHERE id=? AND ministere_id=?', [$d['vehicule_id'], mid()])) { $errs[] = 'Véhicule invalide.'; }
    if (!valid_date($d['date_depense'])) { $errs[] = 'Date invalide.'; } elseif ($d['date_depense'] > date('Y-m-d')) { $errs[] = 'La date ne peut pas être dans le futur.'; }
    if (!in_array($d['categorie'], DEP_CATS, true)) { $errs[] = 'Catégorie invalide.'; }
    if ($d['montant'] <= 0) { $errs[] = 'Le montant doit être supérieur à 0.'; }
    $new = null;
    if (!$errs && has_upload('justificatif')) { try { [$new] = save_upload($_FILES['justificatif'], 'justif', UPLOAD_PRIVATE . '/justificatifs'); $d['justificatif'] = $new; } catch (RuntimeException $e) { $errs[] = $e->getMessage(); } }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect($id ? url('depenses', 'form', ['id' => $id]) : url('depenses', 'form')); }
    if ($old) { update('depenses', $id, $d); if ($new && $old['justificatif']) { delete_file($old['justificatif'], UPLOAD_PRIVATE . '/justificatifs'); } [$o, $n] = diff_vals($old, $d); audit('depense.modification', 'depenses', $id, $o, $n); }
    else { $d += ['ministere_id' => mid(), 'created_by' => uid()]; $id = insert('depenses', $d); audit('depense.creation', 'depenses', $id, null, $d); }
    unset($_SESSION['old']); flash('success', 'Dépense enregistrée.'); redirect(url('depenses'));
}
if ($A === 'delete' && is_post()) {
    require_perm('depenses.manage'); $x = dep_get((int)post('id')); if (!$x) { http_response_code(404); exit('Introuvable.'); }
    if ($x['maintenance_id']) { flash('error', 'Dépense liée à une maintenance : supprimez ou modifiez la maintenance.'); redirect(url('depenses')); }
    q('DELETE FROM depenses WHERE id=?', [$x['id']]); delete_file($x['justificatif'], UPLOAD_PRIVATE . '/justificatifs'); audit('depense.suppression', 'depenses', $x['id'], $x, null); flash('success', 'Dépense supprimée.'); redirect(url('depenses'));
}
if ($A === 'form') {
    require_perm('depenses.manage'); $id = (int)qget('id'); $x = $id ? dep_get($id) : null; if ($id && !$x) { http_response_code(404); exit('Introuvable.'); }
    if ($x && $x['maintenance_id']) { flash('warning', 'Dépense liée à une maintenance : modifiez la maintenance.'); redirect(url('maintenances', 'form', ['id' => $x['maintenance_id']])); }
    $x = array_merge($x ?? ['vehicule_id' => qget('vehicule_id'), 'date_depense' => date('Y-m-d'), 'categorie' => 'Carburant', 'montant' => '', 'description' => '', 'prestataire' => '', 'justificatif' => null], $_SESSION['old'] ?? []); unset($_SESSION['old']);
    page_start($id ? 'Modifier la dépense' : 'Nouvelle dépense');
    echo '<form method="post" enctype="multipart/form-data" action="' . e(url('depenses', 'save')) . '">' . csrf_field() . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : '');
    card_start('Dépense automobile', '', 'mx-auto max-w-3xl'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_select('Véhicule', 'vehicule_id', vehicule_options(), $x['vehicule_id'], ['required' => 1, 'empty' => '— Choisir —']) . f_input('Date', 'date_depense', $x['date_depense'], ['type' => 'date', 'required' => 1, 'max' => date('Y-m-d')])
        . f_select('Catégorie', 'categorie', array_combine(DEP_CATS, DEP_CATS), $x['categorie'], ['required' => 1]) . f_input('Montant (FCFA)', 'montant', $x['montant'], ['type' => 'number', 'min' => 1, 'step' => 1, 'required' => 1])
        . f_input('Description', 'description', $x['description'], ['col' => 'sm:col-span-2', 'maxlength' => 255]) . f_input('Prestataire / fournisseur', 'prestataire', $x['prestataire'], ['maxlength' => 150])
        . '<div><label class="mb-1 block text-sm font-medium">Justificatif (PDF ou image)</label><input type="file" name="justificatif" accept="application/pdf,image/jpeg,image/png,image/webp" class="block w-full">' . ($x['justificatif'] ? '<a class="mt-1 inline-block text-xs text-brand hover:underline" target="_blank" href="' . e(url('documents', 'justificatif', ['t' => 'depenses', 'id' => $id])) . '">Justificatif actuel</a>' : '') . '</div></div>'
        . '<div class="flex justify-end gap-2 border-t border-slate-100 px-5 py-4">' . link_btn(url('depenses'), 'Annuler') . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer') . '</div>'; card_end(); echo '</form>'; page_end(); exit;
}

// ----------------------------------------------------------------- Synthèse et comparaisons
if ($A === 'synthese') {
    $an = (int)qget('annee', date('Y')); if ($an < 2000 || $an > 2100) { $an = (int)date('Y'); }
    $m = mid(); $byMonth = array_column(rows('SELECT MONTH(date_depense) mo, SUM(montant) s FROM depenses WHERE ministere_id=? AND YEAR(date_depense)=? GROUP BY mo', [$m, $an]), 's', 'mo');
    $byCat = rows('SELECT categorie, SUM(montant) s, COUNT(*) n FROM depenses WHERE ministere_id=? AND YEAR(date_depense)=? GROUP BY categorie ORDER BY s DESC', [$m, $an]);
    $byVeh = rows("SELECT v.id, v.marque, v.modele, v.immatriculation, COALESCE(SUM(d.montant),0) total, COUNT(d.id) n,
        (SELECT COALESCE(SUM(km_retour-km_depart),0) FROM reservations r WHERE r.vehicule_id=v.id AND r.statut='Terminée' AND YEAR(r.date_depart)=?) km
        FROM vehicules v LEFT JOIN depenses d ON d.vehicule_id=v.id AND YEAR(d.date_depense)=? WHERE v.ministere_id=? AND v.est_archive=0 GROUP BY v.id ORDER BY total DESC", [$an, $an, $m]);
    $total = array_sum($byMonth);
    page_start('Synthèse des dépenses ' . $an, ['actions' => link_btn(url('depenses'), '<i class="fa-solid fa-list"></i> Liste des dépenses') . '<form method="get" class="inline-flex gap-2"><input type="hidden" name="p" value="depenses"><input type="hidden" name="a" value="synthese"><input type="number" name="annee" value="' . $an . '" min="2000" max="2100" class="' . f_cls() . ' w-28">' . btn('Afficher', 'secondary') . '</form>']);
    echo '<div class="mb-5 grid gap-3 sm:grid-cols-3">' . stat_card('Total ' . $an, fcfa($total), 'fa-coins') . stat_card('Moyenne mensuelle', fcfa($total / 12), 'fa-calendar', 'sky') . stat_card('Écritures', nb(array_sum(array_column($byCat, 'n'))), 'fa-receipt', 'slate') . '</div>';
    echo '<div class="grid gap-6 lg:grid-cols-2">'; card_start('Dépenses par mois'); echo '<div class="p-5"><canvas id="c-mois" height="140"></canvas></div>'; card_end(); card_start('Comparaison entre véhicules'); echo '<div class="p-5"><canvas id="c-veh" height="140"></canvas></div>'; card_end(); echo '</div>';
    echo '<div class="mt-6 grid gap-6 lg:grid-cols-3"><div class="lg:col-span-2">'; card_start('Coût par véhicule');
    echo tbl_start() . th('Véhicule') . th('Écritures') . th('Total') . th('Km (missions)') . th('Coût moyen / km') . tbl_mid();
    foreach ($byVeh as $v) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-2.5"><a class="font-semibold hover:text-brand" href="' . e(url('vehicules', 'show', ['id' => $v['id']])) . '">' . e($v['marque'] . ' ' . $v['modele']) . '</a><div class="font-mono text-xs text-slate-500">' . e($v['immatriculation']) . '</div></td><td class="px-4 py-2.5">' . (int)$v['n'] . '</td><td class="px-4 py-2.5 whitespace-nowrap font-medium">' . fcfa($v['total']) . '</td><td class="px-4 py-2.5">' . nb($v['km']) . '</td><td class="px-4 py-2.5">' . ((int)$v['km'] > 0 ? fcfa($v['total'] / $v['km']) : '<span class="text-slate-400">n/d</span>') . '</td></tr>'; }
    echo tbl_end(); card_end(); echo '</div>'; card_start('Par catégorie'); echo '<div class="space-y-3 p-5">';
    foreach ($byCat as $c) { $pct = $total > 0 ? round($c['s'] / $total * 100) : 0; echo '<div><div class="mb-1 flex justify-between text-xs"><span>' . e($c['categorie']) . '</span><span class="font-medium">' . fcfa($c['s']) . ' · ' . $pct . ' %</span></div><div class="h-1.5 rounded-full bg-slate-100"><div class="h-1.5 rounded-full bg-brand" style="width:' . $pct . '%"></div></div></div>'; }
    if (!$byCat) { echo '<p class="text-sm text-slate-500">Aucune dépense sur cette année.</p>'; } echo '</div>'; card_end(); echo '</div>';
    $labels = array_map('mois_court', range(1, 12)); $vals = array_map(fn($i) => (float)($byMonth[$i] ?? 0), range(1, 12));
    $top = array_slice($byVeh, 0, 10);
    echo '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script><script>
    const fm=v=>new Intl.NumberFormat("fr-FR").format(v)+" FCFA";
    new Chart(document.getElementById("c-mois"),{type:"bar",data:{labels:' . json_encode($labels) . ',datasets:[{label:"Dépenses",data:' . json_encode($vals) . ',backgroundColor:"#006828",borderRadius:4}]},options:{plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>fm(c.parsed.y)}}},scales:{y:{ticks:{callback:v=>fm(v).replace(" FCFA","")}}}}});
    new Chart(document.getElementById("c-veh"),{type:"bar",data:{labels:' . json_encode(array_map(fn($v) => $v['marque'] . ' ' . $v['immatriculation'], $top), JSON_UNESCAPED_UNICODE) . ',datasets:[{label:"Total",data:' . json_encode(array_map(fn($v) => (float)$v['total'], $top)) . ',backgroundColor:"#FFBE00",borderRadius:4}]},options:{indexAxis:"y",plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>fm(c.parsed.x)}}}}});</script>';
    page_end(); exit;
}

// ----------------------------------------------------------------- Liste
$w = ['d.ministere_id=?']; $p = [mid()];
if (($q = qget('q')) !== '') { $w[] = '(d.description LIKE ? OR d.prestataire LIKE ? OR v.immatriculation LIKE ? OR v.marque LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
if ((int)qget('vehicule_id')) { $w[] = 'd.vehicule_id=?'; $p[] = (int)qget('vehicule_id'); }
if (in_array(qget('categorie'), DEP_CATS, true)) { $w[] = 'd.categorie=?'; $p[] = qget('categorie'); }
if (valid_date(qget('du'))) { $w[] = 'd.date_depense >= ?'; $p[] = qget('du'); }
if (valid_date(qget('au'))) { $w[] = 'd.date_depense <= ?'; $p[] = qget('au'); }
$from = 'depenses d JOIN vehicules v ON v.id=d.vehicule_id WHERE ' . implode(' AND ', $w);
$pg = paginate('d.*, v.marque, v.modele, v.immatriculation, CONCAT(u.prenoms," ",u.nom) AS createur', str_replace('FROM', 'FROM', $from) === $from ? 'depenses d JOIN vehicules v ON v.id=d.vehicule_id LEFT JOIN users u ON u.id=d.created_by WHERE ' . implode(' AND ', $w) : $from, $p, ['date' => 'd.date_depense', 'veh' => 'v.marque', 'cat' => 'd.categorie', 'montant' => 'd.montant'], 'date', 'desc');
$totFiltre = (float)val('SELECT COALESCE(SUM(d.montant),0) FROM ' . $from, $p);
$totMois = (float)val('SELECT COALESCE(SUM(montant),0) FROM depenses WHERE ministere_id=? AND date_depense >= ?', [mid(), date('Y-m-01')]);
page_start('Dépenses automobiles', ['actions' => link_btn(url('depenses', 'synthese'), '<i class="fa-solid fa-chart-column"></i> Synthèse et comparaisons') . (can('depenses.manage') ? link_btn(url('depenses', 'form'), '<i class="fa-solid fa-plus"></i> Nouvelle dépense', 'primary') : '')]);
echo '<div class="mb-5 grid gap-3 sm:grid-cols-3">' . stat_card('Dépenses du mois en cours', fcfa($totMois), 'fa-calendar-day') . stat_card('Total (filtre courant)', fcfa($totFiltre), 'fa-coins', 'sky') . stat_card('Écritures (filtre courant)', nb($pg['total']), 'fa-receipt', 'slate') . '</div>';
card_start(); echo '<form method="get" action="' . e(BASE_URL) . '" class="flex flex-wrap items-end gap-2 px-5 py-3"><input type="hidden" name="p" value="depenses"><div class="min-w-[10rem] flex-1"><input type="search" name="q" value="' . e(qget('q')) . '" placeholder="Description, prestataire, véhicule…" class="' . f_cls() . '"></div>'
    . '<select name="vehicule_id" class="' . f_cls() . ' w-auto max-w-[14rem]"><option value="">Tous les véhicules</option>';
foreach (vehicule_options(true) as $k => $v) { echo '<option value="' . $k . '"' . (qget('vehicule_id') === (string)$k ? ' selected' : '') . '>' . e($v) . '</option>'; }
echo '</select><select name="categorie" class="' . f_cls() . ' w-auto"><option value="">Toutes catégories</option>'; foreach (DEP_CATS as $c) { echo '<option' . (qget('categorie') === $c ? ' selected' : '') . '>' . e($c) . '</option>'; }
echo '</select><input type="date" name="du" value="' . e(qget('du')) . '" class="' . f_cls() . ' w-auto" title="Du"><input type="date" name="au" value="' . e(qget('au')) . '" class="' . f_cls() . ' w-auto" title="Au">' . btn('Filtrer') . '<a class="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50" href="' . e(url('depenses')) . '">Réinitialiser</a></form>';
if (!$pg['rows']) { echo empty_state('Aucune dépense enregistrée.', 'fa-receipt'); } else {
    echo tbl_start() . th_sort('Date', 'date', $pg) . th_sort('Véhicule', 'veh', $pg) . th_sort('Catégorie', 'cat', $pg) . th('Description') . th('Prestataire') . th_sort('Montant', 'montant', $pg) . th('Saisi par') . th('') . tbl_mid();
    foreach ($pg['rows'] as $x) {
        $act = '';
        if ($x['maintenance_id']) { $act .= '<a class="text-xs text-slate-500 hover:text-brand" href="' . e(url('maintenances')) . '" title="Liée à une maintenance"><i class="fa-solid fa-link"></i> maintenance</a>'; $docT = 'maintenances'; $docId = $x['maintenance_id']; }
        else { $docT = 'depenses'; $docId = $x['id']; if (can('depenses.manage')) { $act .= '<a class="mr-2 text-brand hover:underline" href="' . e(url('depenses', 'form', ['id' => $x['id']])) . '">Modifier</a>' . confirm_form(url('depenses', 'delete'), '<button class="text-red-700 hover:underline">Supprimer</button>', 'Supprimer cette dépense ?', ['id' => $x['id']]); } }
        if ($x['justificatif']) { $act = '<a class="mr-2 text-slate-500 hover:text-brand" target="_blank" title="Justificatif" href="' . e(url('documents', 'justificatif', ['t' => $docT, 'id' => $docId])) . '"><i class="fa-solid fa-paperclip"></i></a>' . $act; }
        echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 whitespace-nowrap">' . fmt_date($x['date_depense']) . '</td><td class="px-4 py-3">' . e($x['marque'] . ' ' . $x['modele']) . '<div class="font-mono text-xs text-slate-500">' . e($x['immatriculation']) . '</div></td><td class="px-4 py-3">' . e($x['categorie']) . '</td><td class="max-w-xs truncate px-4 py-3">' . e($x['description']) . '</td><td class="px-4 py-3">' . e($x['prestataire'] ?: '—') . '</td><td class="px-4 py-3 whitespace-nowrap font-semibold">' . fcfa($x['montant']) . '</td><td class="px-4 py-3 text-xs">' . e($x['createur'] ?? 'Système') . '</td><td class="px-4 py-3 text-right whitespace-nowrap">' . $act . '</td></tr>';
    }
    echo tbl_end();
}
echo pager($pg); card_end(); page_end();
