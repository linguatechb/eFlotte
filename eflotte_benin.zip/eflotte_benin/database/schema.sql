-- =====================================================================
--  eFlotte Bénin — Schéma de base de données (MySQL 8 / MariaDB 10.4+)
--  Une instance = un ministère = une base de données.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS `eflotte_benin` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `eflotte_benin`;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `login_attempts`, `parametres`, `audit_logs`, `notifications`, `visites_techniques`, `assurances`,
  `depenses`, `maintenances`, `historiques_reservations`, `reservations`, `chauffeurs`, `vehicules`, `users`, `services`, `roles`, `ministeres`;

CREATE TABLE `ministeres` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom` VARCHAR(190) NOT NULL,
  `sigle` VARCHAR(30) NOT NULL,
  `code` VARCHAR(30) NOT NULL,
  `adresse` VARCHAR(255) NULL,
  `telephone` VARCHAR(40) NULL,
  `email` VARCHAR(150) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_min_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `roles` (
  `id` TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(30) NOT NULL,
  `libelle` VARCHAR(80) NOT NULL,
  `fonction` VARCHAR(190) NOT NULL,
  `description` TEXT NOT NULL,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_role_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `services` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `nom` VARCHAR(190) NOT NULL,
  `sigle` VARCHAR(30) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_service` (`ministere_id`,`nom`),
  CONSTRAINT `fk_services_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `role_id` TINYINT UNSIGNED NOT NULL,
  `service_id` INT UNSIGNED NULL,
  `nom` VARCHAR(80) NOT NULL,
  `prenoms` VARCHAR(120) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `matricule` VARCHAR(40) NULL,
  `telephone` VARCHAR(40) NULL,
  `fonction` VARCHAR(150) NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `actif` TINYINT(1) NOT NULL DEFAULT 1,
  `derniere_connexion` DATETIME NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_email` (`email`),
  KEY `idx_user_min` (`ministere_id`), KEY `idx_user_role` (`role_id`), KEY `idx_user_service` (`service_id`),
  CONSTRAINT `fk_users_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`),
  CONSTRAINT `fk_users_service` FOREIGN KEY (`service_id`) REFERENCES `services`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `vehicules` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `marque` VARCHAR(60) NOT NULL,
  `modele` VARCHAR(80) NOT NULL,
  `immatriculation` VARCHAR(30) NOT NULL,
  `numero_chassis` VARCHAR(40) NOT NULL,
  `carburant` ENUM('Essence','Diesel','Hybride','Électrique','GPL') NOT NULL DEFAULT 'Diesel',
  `annee` SMALLINT UNSIGNED NOT NULL,
  `kilometrage` INT UNSIGNED NOT NULL DEFAULT 0,
  `date_acquisition` DATE NOT NULL,
  `valeur_acquisition` DECIMAL(14,0) NOT NULL DEFAULT 0,
  `etat` ENUM('Disponible','En mission','En maintenance','Immobilisé','Réformé') NOT NULL DEFAULT 'Disponible',
  `photo` VARCHAR(120) NULL,
  `observations` TEXT NULL,
  `est_archive` TINYINT(1) NOT NULL DEFAULT 0,
  `created_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_veh_immat` (`ministere_id`,`immatriculation`),
  UNIQUE KEY `uq_veh_chassis` (`ministere_id`,`numero_chassis`),
  KEY `idx_veh_etat` (`etat`),
  CONSTRAINT `fk_veh_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_veh_user` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `chauffeurs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `nom` VARCHAR(80) NOT NULL,
  `prenoms` VARCHAR(120) NOT NULL,
  `matricule` VARCHAR(40) NOT NULL,
  `telephone` VARCHAR(40) NOT NULL,
  `adresse` VARCHAR(255) NULL,
  `numero_permis` VARCHAR(60) NOT NULL,
  `categorie_permis` VARCHAR(30) NOT NULL,
  `date_delivrance` DATE NOT NULL,
  `date_expiration` DATE NOT NULL,
  `actif` TINYINT(1) NOT NULL DEFAULT 1,
  `observations` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_chauf_matricule` (`ministere_id`,`matricule`),
  UNIQUE KEY `uq_chauf_permis` (`ministere_id`,`numero_permis`),
  CONSTRAINT `fk_chauf_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `reservations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `reference` VARCHAR(30) NULL,
  `demandeur_id` INT UNSIGNED NOT NULL,
  `motif` VARCHAR(255) NOT NULL,
  `destination` VARCHAR(255) NOT NULL,
  `date_depart` DATETIME NOT NULL,
  `date_retour` DATETIME NOT NULL,
  `vehicule_souhaite_id` INT UNSIGNED NULL,
  `observations` TEXT NULL,
  `ordre_mission_fichier` VARCHAR(120) NOT NULL,
  `ordre_mission_nom` VARCHAR(190) NOT NULL,
  `statut` ENUM('En attente','Validée','Attribuée','En cours','Terminée','Rejetée') NOT NULL DEFAULT 'En attente',
  `validateur_id` INT UNSIGNED NULL,
  `date_decision` DATETIME NULL,
  `commentaire_decision` TEXT NULL,
  `vehicule_id` INT UNSIGNED NULL,
  `chauffeur_id` INT UNSIGNED NULL,
  `attribue_par` INT UNSIGNED NULL,
  `date_attribution` DATETIME NULL,
  `km_depart` INT UNSIGNED NULL,
  `km_retour` INT UNSIGNED NULL,
  `date_debut_reelle` DATETIME NULL,
  `date_fin_reelle` DATETIME NULL,
  `observations_execution` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_res_statut` (`statut`), KEY `idx_res_dem` (`demandeur_id`),
  KEY `idx_res_veh` (`vehicule_id`,`date_depart`,`date_retour`),
  KEY `idx_res_chauf` (`chauffeur_id`,`date_depart`,`date_retour`),
  KEY `idx_res_dates` (`date_depart`),
  CONSTRAINT `chk_res_dates` CHECK (`date_retour` > `date_depart`),
  CONSTRAINT `fk_res_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_res_dem` FOREIGN KEY (`demandeur_id`) REFERENCES `users`(`id`),
  CONSTRAINT `fk_res_vsou` FOREIGN KEY (`vehicule_souhaite_id`) REFERENCES `vehicules`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_res_val` FOREIGN KEY (`validateur_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_res_veh` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules`(`id`),
  CONSTRAINT `fk_res_chauf` FOREIGN KEY (`chauffeur_id`) REFERENCES `chauffeurs`(`id`),
  CONSTRAINT `fk_res_attr` FOREIGN KEY (`attribue_par`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `historiques_reservations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `reservation_id` INT UNSIGNED NOT NULL,
  `ancien_statut` VARCHAR(30) NULL,
  `nouveau_statut` VARCHAR(30) NOT NULL,
  `user_id` INT UNSIGNED NULL,
  `commentaire` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_hist_res` (`reservation_id`),
  CONSTRAINT `fk_hist_res` FOREIGN KEY (`reservation_id`) REFERENCES `reservations`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hist_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `maintenances` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `vehicule_id` INT UNSIGNED NOT NULL,
  `type` ENUM('Préventive','Corrective') NOT NULL,
  `categorie` ENUM('Vidange','Pneumatiques','Freinage','Batterie','Révision générale','Réparation mécanique','Réparation électrique','Autres interventions') NOT NULL,
  `description` TEXT NOT NULL,
  `statut` ENUM('Planifiée','En cours','Terminée') NOT NULL DEFAULT 'Terminée',
  `date_maintenance` DATE NOT NULL,
  `date_fin` DATE NULL,
  `kilometrage` INT UNSIGNED NULL,
  `prestataire` VARCHAR(150) NULL,
  `cout` DECIMAL(14,0) NOT NULL DEFAULT 0,
  `pieces_remplacees` TEXT NULL,
  `prochaine_echeance` DATE NULL,
  `observations` TEXT NULL,
  `justificatif` VARCHAR(120) NULL,
  `created_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_mnt_veh` (`vehicule_id`,`date_maintenance`), KEY `idx_mnt_statut` (`statut`),
  CONSTRAINT `fk_mnt_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_mnt_veh` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules`(`id`),
  CONSTRAINT `fk_mnt_user` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `depenses` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `vehicule_id` INT UNSIGNED NOT NULL,
  `maintenance_id` INT UNSIGNED NULL,
  `date_depense` DATE NOT NULL,
  `categorie` ENUM('Carburant','Entretien','Réparation','Assurance','Visite technique','Pièces détachées','Autres frais') NOT NULL,
  `montant` DECIMAL(14,0) NOT NULL,
  `description` VARCHAR(255) NULL,
  `prestataire` VARCHAR(150) NULL,
  `justificatif` VARCHAR(120) NULL,
  `created_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_dep_veh` (`vehicule_id`,`date_depense`), KEY `idx_dep_date` (`date_depense`), KEY `idx_dep_cat` (`categorie`),
  UNIQUE KEY `uq_dep_maint` (`maintenance_id`),
  CONSTRAINT `chk_dep_montant` CHECK (`montant` >= 0),
  CONSTRAINT `fk_dep_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_dep_veh` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules`(`id`),
  CONSTRAINT `fk_dep_mnt` FOREIGN KEY (`maintenance_id`) REFERENCES `maintenances`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dep_user` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `assurances` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `vehicule_id` INT UNSIGNED NOT NULL,
  `compagnie` VARCHAR(150) NOT NULL,
  `numero_police` VARCHAR(80) NOT NULL,
  `date_souscription` DATE NOT NULL,
  `date_expiration` DATE NOT NULL,
  `justificatif` VARCHAR(120) NULL,
  `created_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_ass_veh` (`vehicule_id`,`date_expiration`),
  CONSTRAINT `chk_ass_dates` CHECK (`date_expiration` > `date_souscription`),
  CONSTRAINT `fk_ass_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_ass_veh` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules`(`id`),
  CONSTRAINT `fk_ass_user` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `visites_techniques` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NOT NULL,
  `vehicule_id` INT UNSIGNED NOT NULL,
  `date_visite` DATE NOT NULL,
  `date_prochaine` DATE NOT NULL,
  `centre` VARCHAR(150) NULL,
  `resultat` ENUM('Favorable','Défavorable') NOT NULL DEFAULT 'Favorable',
  `observations` TEXT NULL,
  `justificatif` VARCHAR(120) NULL,
  `created_by` INT UNSIGNED NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_vt_veh` (`vehicule_id`,`date_prochaine`),
  CONSTRAINT `chk_vt_dates` CHECK (`date_prochaine` > `date_visite`),
  CONSTRAINT `fk_vt_min` FOREIGN KEY (`ministere_id`) REFERENCES `ministeres`(`id`),
  CONSTRAINT `fk_vt_veh` FOREIGN KEY (`vehicule_id`) REFERENCES `vehicules`(`id`),
  CONSTRAINT `fk_vt_user` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `notifications` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('info','success','warning','danger') NOT NULL DEFAULT 'info',
  `titre` VARCHAR(190) NOT NULL,
  `message` VARCHAR(500) NULL,
  `lien` VARCHAR(255) NULL,
  `cle` VARCHAR(120) NULL,
  `lu` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notif_cle` (`user_id`,`cle`),
  KEY `idx_notif_user` (`user_id`,`lu`,`created_at`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `audit_logs` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ministere_id` INT UNSIGNED NULL,
  `user_id` INT UNSIGNED NULL,
  `user_nom` VARCHAR(190) NULL,
  `action` VARCHAR(80) NOT NULL,
  `ressource_type` VARCHAR(60) NULL,
  `ressource_id` VARCHAR(120) NULL,
  `anciennes_valeurs` MEDIUMTEXT NULL,
  `nouvelles_valeurs` MEDIUMTEXT NULL,
  `ip` VARCHAR(45) NULL,
  `user_agent` VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_audit_date` (`created_at`), KEY `idx_audit_user` (`user_id`), KEY `idx_audit_action` (`action`), KEY `idx_audit_res` (`ressource_type`,`ressource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Journal non modifiable / non supprimable (même par un compte applicatif)
CREATE TRIGGER `trg_audit_no_update` BEFORE UPDATE ON `audit_logs` FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs est en lecture seule : modification interdite';
CREATE TRIGGER `trg_audit_no_delete` BEFORE DELETE ON `audit_logs` FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'audit_logs est en lecture seule : suppression interdite';

CREATE TABLE `parametres` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `cle` VARCHAR(60) NOT NULL,
  `valeur` VARCHAR(255) NOT NULL,
  `groupe` ENUM('operationnel','technique') NOT NULL DEFAULT 'operationnel',
  `type` ENUM('int','bool','text') NOT NULL DEFAULT 'int',
  `libelle` VARCHAR(190) NOT NULL,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), UNIQUE KEY `uq_param_cle` (`cle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `login_attempts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` VARCHAR(150) NOT NULL,
  `ip` VARCHAR(45) NOT NULL,
  `succes` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_la_email` (`email`,`created_at`), KEY `idx_la_ip` (`ip`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
