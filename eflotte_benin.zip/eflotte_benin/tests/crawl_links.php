<?php
/** Parcourt tous les liens internes accessibles à chaque profil et signale les liens cassés (404/500/erreur PHP). */
require __DIR__ . '/run_tests_client.php';
