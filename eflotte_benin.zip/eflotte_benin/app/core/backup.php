<?php
declare(strict_types=1);

/** Sépare un script SQL en instructions (gère chaînes, commentaires -- et /* *\/). */
function sql_split(string $sql): array
{
    $out = []; $cur = ''; $len = strlen($sql); $q = null;
    for ($i = 0; $i < $len; $i++) {
        $c = $sql[$i];
        if ($q) {
            $cur .= $c;
            if ($c === '\\' && $q !== '`') { $cur .= $sql[++$i] ?? ''; }
            elseif ($c === $q) { if (($sql[$i + 1] ?? '') === $q) { $cur .= $sql[++$i]; } else { $q = null; } }
            continue;
        }
        if ($c === '-' && ($sql[$i + 1] ?? '') === '-' && (($sql[$i + 2] ?? ' ') === ' ' || ($sql[$i + 2] ?? '') === "\n")) { while ($i < $len && $sql[$i] !== "\n") { $i++; } continue; }
        if ($c === '#') { while ($i < $len && $sql[$i] !== "\n") { $i++; } continue; }
        if ($c === '/' && ($sql[$i + 1] ?? '') === '*') { $i += 2; while ($i < $len - 1 && !($sql[$i] === '*' && $sql[$i + 1] === '/')) { $i++; } $i++; continue; }
        if ($c === "'" || $c === '"' || $c === '`') { $q = $c; $cur .= $c; continue; }
        if ($c === ';') { if (trim($cur) !== '') { $out[] = trim($cur); } $cur = ''; continue; }
        $cur .= $c;
    }
    if (trim($cur) !== '') { $out[] = trim($cur); }
    return $out;
}

/** Exécute un script SQL (tables supprimées/recréées) ; retourne le nombre d'instructions. */
function sql_run(PDO $pdo, string $sql): int
{
    $n = 0;
    foreach (sql_split($sql) as $st) { $pdo->exec($st); $n++; }
    return $n;
}

function db_tables(): array { return array_column(rows('SHOW FULL TABLES WHERE Table_type = \'BASE TABLE\''), 'Tables_in_' . $GLOBALS['CFG']['db']['name']); }

/** Dump logique complet (structure, données, déclencheurs) sans dépendre de mysqldump */
function db_dump(string $dest, array &$counts): void
{
    $pdo = db(); $fh = fopen($dest, 'wb');
    $w = fn($s) => fwrite($fh, $s . ";\n-- @@\n");
    fwrite($fh, "-- eFlotte Bénin — sauvegarde logique " . date('c') . "\n");
    $w('SET NAMES utf8mb4'); $w('SET FOREIGN_KEY_CHECKS=0'); $w("SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO'");
    foreach (db_tables() as $t) {
        $cr = $pdo->query('SHOW CREATE TABLE `' . $t . '`')->fetch(PDO::FETCH_NUM)[1];
        $w('DROP TABLE IF EXISTS `' . $t . '`'); $w($cr);
        $counts[$t] = 0; $stmt = $pdo->query('SELECT * FROM `' . $t . '`', PDO::FETCH_NUM); $batch = [];
        $flush = function () use (&$batch, $t, $w) { if ($batch) { $w('INSERT INTO `' . $t . '` VALUES ' . implode(',', $batch)); $batch = []; } };
        while ($r = $stmt->fetch()) {
            $batch[] = '(' . implode(',', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v), $r)) . ')'; $counts[$t]++;
            if (count($batch) >= 200) { $flush(); }
        }
        $flush();
    }
    foreach ($pdo->query('SHOW TRIGGERS')->fetchAll(PDO::FETCH_ASSOC) as $tr) {
        $c = $pdo->query('SHOW CREATE TRIGGER `' . $tr['Trigger'] . '`')->fetch(PDO::FETCH_ASSOC);
        $w('DROP TRIGGER IF EXISTS `' . $tr['Trigger'] . '`');
        $w(preg_replace('/^CREATE\s+DEFINER=\S+\s+TRIGGER/i', 'CREATE TRIGGER', $c['SQL Original Statement']));
    }
    $w('SET FOREIGN_KEY_CHECKS=1');
    fclose($fh);
}

function add_dir_to_zip(ZipArchive $z, string $dir, string $prefix): int
{
    $n = 0; if (!is_dir($dir)) { return 0; }
    foreach (new DirectoryIterator($dir) as $f) {
        if ($f->isFile() && !str_starts_with($f->getFilename(), '.') && $f->getFilename() !== 'index.html') { $z->addFile($f->getPathname(), $prefix . $f->getFilename()); $n++; }
    }
    return $n;
}

/** Crée une sauvegarde .zip (base + documents + images) et applique la politique de conservation */
function backup_create(string $label = 'manuelle'): array
{
    if (!class_exists('ZipArchive')) { throw new RuntimeException('L\'extension PHP zip est requise (activez extension=zip dans php.ini).'); }
    @set_time_limit(300);
    $stamp = date('Ymd_His'); $name = 'eflotte_backup_' . $stamp . '_' . preg_replace('/[^a-z0-9]/', '', strtolower($label)) . '.zip';
    $tmpSql = tempnam(sys_get_temp_dir(), 'efd'); $counts = [];
    db_dump($tmpSql, $counts);
    $z = new ZipArchive(); $path = BACKUP_PATH . '/' . $name;
    if ($z->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { throw new RuntimeException('Impossible de créer l\'archive de sauvegarde.'); }
    $z->addFile($tmpSql, 'database.sql');
    $files = add_dir_to_zip($z, UPLOAD_PUBLIC . '/vehicules', 'files/vehicules/') + add_dir_to_zip($z, UPLOAD_PRIVATE . '/ordres_mission', 'files/ordres_mission/') + add_dir_to_zip($z, UPLOAD_PRIVATE . '/justificatifs', 'files/justificatifs/');
    $manifest = ['application' => 'eFlotte Bénin', 'version' => 1, 'created_at' => date('c'), 'database' => $GLOBALS['CFG']['db']['name'], 'tables' => $counts, 'sha256_database' => hash_file('sha256', $tmpSql), 'files' => $files, 'created_by' => uid(), 'ministere' => ministere()['nom'] ?? ''];
    $z->addFromString('manifest.json', json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    $z->close(); @unlink($tmpSql);
    return ['name' => $name, 'size' => filesize($path), 'manifest' => $manifest];
}

function backup_list(): array
{
    $o = [];
    foreach (glob(BACKUP_PATH . '/eflotte_backup_*.zip') ?: [] as $f) { $o[] = ['name' => basename($f), 'size' => filesize($f), 'time' => filemtime($f)]; }
    usort($o, fn($a, $b) => $b['time'] <=> $a['time']);
    return $o;
}
function backup_valid_name(string $n): bool { return (bool)preg_match('/^eflotte_backup_\d{8}_\d{6}_[a-z0-9]+\.zip$/', $n); }

/** Politique de conservation : supprime les sauvegardes plus anciennes que N jours (en gardant au moins 3 archives) */
function backup_purge(): int
{
    $days = max(1, (int)param('backup_retention_days', 30)); $list = backup_list(); $n = 0;
    foreach (array_slice($list, 3) as $b) { if ($b['time'] < time() - $days * 86400) { @unlink(BACKUP_PATH . '/' . $b['name']); $n++; } }
    return $n;
}

/** Restauration vérifiée : intégrité (sha256), sauvegarde de sécurité préalable, restauration, contrôle des comptages */
function backup_restore(string $zipPath): array
{
    $z = new ZipArchive();
    if ($z->open($zipPath) !== true) { throw new RuntimeException('Archive illisible.'); }
    $man = json_decode((string)$z->getFromName('manifest.json'), true); $sql = $z->getFromName('database.sql');
    if (!is_array($man) || ($man['application'] ?? '') !== 'eFlotte Bénin' || $sql === false) { throw new RuntimeException('Archive invalide : manifeste ou dump absent.'); }
    if (!hash_equals((string)$man['sha256_database'], hash('sha256', $sql))) { throw new RuntimeException('Vérification d\'intégrité échouée (empreinte SHA-256 différente) : restauration annulée.'); }
    $safety = backup_create('avantrestauration');
    $pdo = db();
    try { sql_run($pdo, $sql); }
    catch (Throwable $e) { error_log('[eFlotte][restore] ' . $e->getMessage()); throw new RuntimeException('Échec de la restauration SQL : ' . $e->getMessage() . ' — une sauvegarde de sécurité (' . $safety['name'] . ') a été créée avant l\'opération.'); }
    $bad = [];
    foreach ($man['tables'] as $t => $n) { $c = (int)$pdo->query('SELECT COUNT(*) FROM `' . $t . '`')->fetchColumn(); if ($c !== (int)$n) { $bad[] = "$t ($c ≠ $n)"; } }
    $restored = 0;
    foreach ([['files/vehicules/', UPLOAD_PUBLIC . '/vehicules'], ['files/ordres_mission/', UPLOAD_PRIVATE . '/ordres_mission'], ['files/justificatifs/', UPLOAD_PRIVATE . '/justificatifs']] as [$pre, $dest]) {
        if (!is_dir($dest)) { @mkdir($dest, 0775, true); }
        for ($i = 0; $i < $z->numFiles; $i++) {
            $n = $z->getNameIndex($i);
            if (str_starts_with($n, $pre) && preg_match('/^[a-zA-Z0-9_\-]+\.(pdf|jpg|png|webp)$/', substr($n, strlen($pre)))) { file_put_contents($dest . '/' . substr($n, strlen($pre)), $z->getFromIndex($i)); $restored++; }
        }
    }
    $z->close();
    return ['tables' => count($man['tables']), 'files' => $restored, 'mismatch' => $bad, 'safety' => $safety['name'], 'date' => $man['created_at']];
}
