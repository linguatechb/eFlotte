<?php
declare(strict_types=1);

require_perm('assurances.view');
$T = qget('t', post('t')) === 'visite' ? 'visite' : 'assurance';
$TABLE = $T === 'visite' ? 'visites_techniques' : 'assurances';
$LABEL = $T === 'visite' ? 'visite technique' : 'assurance';
function ass_get(string $table, int $id): ?array { return row("SELECT * FROM `$table` WHERE id=? AND ministere_id=?", [$id, mid()]); }

if ($A === 'save' && is_post()) {
    require_perm('assurances.manage'); $id = post_int('id'); $old = $id ? ass_get($TABLE, $id) : null; if ($id && !$old) { http_response_code(404); exit('Introuvable.'); }
    $d = ['vehicule_id' => (int)post('vehicule_id')]; $errs = [];
    if (!val('SELECT COUNT(*) FROM vehicules WHERE id=? AND ministere_id=?', [$d['vehicule_id'], mid()])) { $errs[] = 'Véhicule invalide.'; }
    if ($T === 'assurance') {
        $d += ['compagnie' => post('compagnie'), 'numero_police' => post('numero_police'), 'date_souscription' => post('date_souscription'), 'date_expiration' => post('date_expiration')];
        if ($d['compagnie'] === '' || $d['numero_police'] === '') { $errs[] = 'Compagnie et numéro de police obligatoires.'; }
        if (!valid_date($d['date_souscription']) || !valid_date($d['date_expiration'])) { $errs[] = 'Dates invalides.'; } elseif ($d['date_expiration'] <= $d['date_souscription']) { $errs[] = 'L\'expiration doit être postérieure à la souscription.'; }
    } else {
        $d += ['date_visite' => post('date_visite'), 'date_prochaine' => post('date_prochaine'), 'centre' => post('centre'), 'resultat' => post('resultat'), 'observations' => post('observations')];
        if (!valid_date($d['date_visite']) || !valid_date($d['date_prochaine'])) { $errs[] = 'Dates invalides.'; } elseif ($d['date_prochaine'] <= $d['date_visite']) { $errs[] = 'La prochaine visite doit être postérieure à la visite.'; }
        if (!in_array($d['resultat'], ['Favorable', 'Défavorable'], true)) { $errs[] = 'Résultat invalide.'; }
    }
    $new = null;
    if (!$errs && has_upload('justificatif')) { try { [$new] = save_upload($_FILES['justificatif'], 'justif', UPLOAD_PRIVATE . '/justificatifs'); $d['justificatif'] = $new; } catch (RuntimeException $e) { $errs[] = $e->getMessage(); } }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect(url('assurances', 'form', ['t' => $T] + ($id ? ['id' => $id] : []))); }
    if ($old) { update($TABLE, $id, $d); if ($new && $old['justificatif']) { delete_file($old['justificatif'], UPLOAD_PRIVATE . '/justificatifs'); } [$o, $n] = diff_vals($old, $d); audit($T . '.modification', $TABLE, $id, $o, $n); }
    else { $d += ['ministere_id' => mid(), 'created_by' => uid()]; $id = insert($TABLE, $d); audit($T . '.creation', $TABLE, $id, null, $d); }
    unset($_SESSION['old']); flash('success', ucfirst($LABEL) . ' enregistrée.'); redirect(url('assurances'));
}
if ($A === 'delete' && is_post()) {
    require_perm('assurances.manage'); $x = ass_get($TABLE, (int)post('id')); if (!$x) { http_response_code(404); exit('Introuvable.'); }
    q("DELETE FROM `$TABLE` WHERE id=?", [$x['id']]); delete_file($x['justificatif'], UPLOAD_PRIVATE . '/justificatifs'); audit($T . '.suppression', $TABLE, $x['id'], $x, null); flash('success', ucfirst($LABEL) . ' supprimée.'); redirect(url('assurances'));
}
if ($A === 'form') {
    require_perm('assurances.manage'); $id = (int)qget('id'); $x = $id ? ass_get($TABLE, $id) : null; if ($id && !$x) { http_response_code(404); exit('Introuvable.'); }
    $def = $T === 'assurance' ? ['vehicule_id' => qget('vehicule_id'), 'compagnie' => '', 'numero_police' => '', 'date_souscription' => date('Y-m-d'), 'date_expiration' => date('Y-m-d', strtotime('+1 year')), 'justificatif' => null]
                              : ['vehicule_id' => qget('vehicule_id'), 'date_visite' => date('Y-m-d'), 'date_prochaine' => date('Y-m-d', strtotime('+6 months')), 'centre' => '', 'resultat' => 'Favorable', 'observations' => '', 'justificatif' => null];
    $x = array_merge($x ?? $def, $_SESSION['old'] ?? []); unset($_SESSION['old']);
    page_start(($id ? 'Modifier' : 'Enregistrer') . ' — ' . $LABEL);
    echo '<form method="post" enctype="multipart/form-data" action="' . e(url('assurances', 'save')) . '">' . csrf_field() . '<input type="hidden" name="t" value="' . $T . '">' . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : '');
    card_start(ucfirst($LABEL), '', 'mx-auto max-w-3xl'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_select('Véhicule', 'vehicule_id', vehicule_options(), $x['vehicule_id'], ['required' => 1, 'empty' => '— Choisir —', 'col' => 'sm:col-span-2']);
    if ($T === 'assurance') { echo f_input('Compagnie d\'assurance', 'compagnie', $x['compagnie'], ['required' => 1]) . f_input('Numéro de police', 'numero_police', $x['numero_police'], ['required' => 1]) . f_input('Date de souscription', 'date_souscription', $x['date_souscription'], ['type' => 'date', 'required' => 1]) . f_input('Date d\'expiration', 'date_expiration', $x['date_expiration'], ['type' => 'date', 'required' => 1]); }
    else { echo f_input('Date de la dernière visite', 'date_visite', $x['date_visite'], ['type' => 'date', 'required' => 1]) . f_input('Date de la prochaine visite', 'date_prochaine', $x['date_prochaine'], ['type' => 'date', 'required' => 1]) . f_input('Centre de contrôle', 'centre', $x['centre']) . f_select('Résultat', 'resultat', ['Favorable' => 'Favorable', 'Défavorable' => 'Défavorable'], $x['resultat']) . f_textarea('Observations', 'observations', $x['observations'], ['col' => 'sm:col-span-2', 'rows' => 2]); }
    echo '<div class="sm:col-span-2"><label class="mb-1 block text-sm font-medium">Justificatif (PDF ou image)</label><input type="file" name="justificatif" accept="application/pdf,image/jpeg,image/png,image/webp" class="block w-full">' . ($x['justificatif'] ? '<a class="mt-1 inline-block text-xs text-brand hover:underline" target="_blank" href="' . e(url('documents', 'justificatif', ['t' => $TABLE, 'id' => $id])) . '">Justificatif actuel</a>' : '') . '</div></div>'
        . '<div class="flex justify-end gap-2 border-t border-slate-100 px-5 py-4">' . link_btn(url('assurances'), 'Annuler') . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer') . '</div>'; card_end(); echo '</form>'; page_end(); exit;
}

$dA = (int)param('alerte_assurance_jours', 30); $dV = (int)param('alerte_visite_jours', 30); $manage = can('assurances.manage');
page_start('Assurances et visites techniques', ['actions' => $manage ? link_btn(url('assurances', 'form', ['t' => 'visite']), '<i class="fa-solid fa-clipboard-check"></i> Nouvelle visite technique') . link_btn(url('assurances', 'form', ['t' => 'assurance']), '<i class="fa-solid fa-plus"></i> Nouvelle assurance', 'primary') : '']);
$veh = rows("SELECT v.id, v.marque, v.modele, v.immatriculation, v.etat, (SELECT MAX(date_expiration) FROM assurances WHERE vehicule_id=v.id) ass, (SELECT MAX(date_prochaine) FROM visites_techniques WHERE vehicule_id=v.id) vt FROM vehicules v WHERE v.ministere_id=? AND v.est_archive=0 ORDER BY v.marque, v.modele", [mid()]);
$bad = 0; foreach ($veh as $v) { if (echeance_statut($v['ass'], $dA) === 'Expirée' || echeance_statut($v['vt'], $dV) === 'Expirée') { $bad++; } }
if ($bad) { echo '<div class="mb-4 flex items-center gap-3 rounded-xl border border-red-300 bg-red-50 px-4 py-3 text-sm text-red-900"><i class="fa-solid fa-circle-exclamation"></i><span><b>' . $bad . '</b> véhicule(s) avec une obligation expirée : l\'attribution à une mission est bloquée' . ((int)param('blocage_obligations_expirees', 1) ? '' : ' (blocage désactivé dans les paramètres)') . '.</span></div>'; }
card_start('Conformité du parc'); echo tbl_start() . th('Véhicule') . th('Assurance (échéance)') . th('Visite technique (échéance)') . th('Attribuable') . tbl_mid();
foreach ($veh as $v) {
    $sa = echeance_statut($v['ass'], $dA); $sv = echeance_statut($v['vt'], $dV); $ok = $sa !== 'Expirée' && $sv !== 'Expirée' && $v['etat'] !== 'Réformé' && $v['etat'] !== 'Immobilisé';
    echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3"><a class="font-semibold hover:text-brand" href="' . e(url('vehicules', 'show', ['id' => $v['id']])) . '">' . e($v['marque'] . ' ' . $v['modele']) . '</a> <span class="font-mono text-xs text-slate-500">' . e($v['immatriculation']) . '</span></td><td class="px-4 py-3">' . fmt_date($v['ass']) . ' ' . badge($sa) . '</td><td class="px-4 py-3">' . fmt_date($v['vt']) . ' ' . badge($sv) . '</td><td class="px-4 py-3">' . ($ok ? '<i class="fa-solid fa-circle-check text-emerald-600"></i> Oui' : '<i class="fa-solid fa-ban text-red-600"></i> Non') . '</td></tr>';
}
echo tbl_end(); card_end();
$docs = function (string $table, string $title, array $rowsData, callable $cells) use ($manage, $T) {
    echo '<div class="mt-6">'; card_start($title);
    if (!$rowsData) { echo empty_state('Aucun enregistrement.'); } else { echo tbl_start() . $cells(null) . th('') . tbl_mid(); foreach ($rowsData as $r) {
        $tt = $table === 'assurances' ? 'assurance' : 'visite';
        $act = ($r['justificatif'] ? '<a class="mr-2 text-slate-500 hover:text-brand" target="_blank" href="' . e(url('documents', 'justificatif', ['t' => $table, 'id' => $r['id']])) . '"><i class="fa-solid fa-paperclip"></i></a>' : '')
             . ($manage ? '<a class="mr-2 text-brand hover:underline" href="' . e(url('assurances', 'form', ['t' => $tt, 'id' => $r['id']])) . '">Modifier</a>' . confirm_form(url('assurances', 'delete'), '<button class="text-red-700 hover:underline">Supprimer</button>', 'Supprimer cet enregistrement ?', ['id' => $r['id'], 't' => $tt]) : '');
        echo '<tr class="hover:bg-slate-50">' . $cells($r) . '<td class="px-4 py-3 text-right whitespace-nowrap">' . $act . '</td></tr>'; } echo tbl_end(); }
    card_end(); echo '</div>';
};
$docs('assurances', 'Contrats d\'assurance', rows("SELECT a.*, v.marque, v.modele, v.immatriculation FROM assurances a JOIN vehicules v ON v.id=a.vehicule_id WHERE a.ministere_id=? ORDER BY a.date_expiration DESC LIMIT 60", [mid()]), function ($r) use ($dA) {
    if ($r === null) { return th('Véhicule') . th('Compagnie') . th('N° de police') . th('Souscription') . th('Expiration'); }
    return '<td class="px-4 py-3">' . e($r['marque'] . ' ' . $r['modele']) . ' <span class="font-mono text-xs text-slate-500">' . e($r['immatriculation']) . '</span></td><td class="px-4 py-3">' . e($r['compagnie']) . '</td><td class="px-4 py-3 font-mono text-xs">' . e($r['numero_police']) . '</td><td class="px-4 py-3">' . fmt_date($r['date_souscription']) . '</td><td class="px-4 py-3 whitespace-nowrap">' . fmt_date($r['date_expiration']) . ' ' . badge(echeance_statut($r['date_expiration'], $dA)) . '</td>';
});
$docs('visites_techniques', 'Visites techniques', rows("SELECT t.*, v.marque, v.modele, v.immatriculation FROM visites_techniques t JOIN vehicules v ON v.id=t.vehicule_id WHERE t.ministere_id=? ORDER BY t.date_prochaine DESC LIMIT 60", [mid()]), function ($r) use ($dV) {
    if ($r === null) { return th('Véhicule') . th('Dernière visite') . th('Centre') . th('Résultat') . th('Prochaine visite'); }
    return '<td class="px-4 py-3">' . e($r['marque'] . ' ' . $r['modele']) . ' <span class="font-mono text-xs text-slate-500">' . e($r['immatriculation']) . '</span></td><td class="px-4 py-3">' . fmt_date($r['date_visite']) . '</td><td class="px-4 py-3">' . e($r['centre'] ?: '—') . '</td><td class="px-4 py-3">' . badge($r['resultat']) . '</td><td class="px-4 py-3 whitespace-nowrap">' . fmt_date($r['date_prochaine']) . ' ' . badge(echeance_statut($r['date_prochaine'], $dV)) . '</td>';
});
page_end();
