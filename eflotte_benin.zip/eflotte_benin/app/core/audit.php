<?php
declare(strict_types=1);

/** Journal d'audit : insertion seule (les triggers SQL interdisent UPDATE/DELETE). */
function audit(string $action, ?string $type = null, $id = null, $old = null, $new = null, ?array $asUser = null): void
{
    try {
        $u = $asUser ?? user();
        $strip = function ($v) {
            if (is_array($v)) { unset($v['password_hash'], $v['password']); }
            return $v === null ? null : json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        };
        q('INSERT INTO audit_logs (ministere_id,user_id,user_nom,action,ressource_type,ressource_id,anciennes_valeurs,nouvelles_valeurs,ip,user_agent) VALUES (?,?,?,?,?,?,?,?,?,?)', [
            $u['ministere_id'] ?? 1, $u['id'] ?? null, $u ? trim(($u['prenoms'] ?? '') . ' ' . ($u['nom'] ?? '')) : null,
            $action, $type, $id === null ? null : (string)$id, $strip($old), $strip($new), client_ip(), substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        ]);
    } catch (Throwable $e) { error_log('[eFlotte][audit] ' . $e->getMessage()); }
}
/** Différences entre deux états (ne conserve que les champs modifiés) */
function diff_vals(array $old, array $new, array $ignore = ['updated_at', 'created_at', 'password_hash']): array
{
    $o = $n = [];
    foreach ($new as $k => $v) {
        if (in_array($k, $ignore, true)) { continue; }
        if ((string)($old[$k] ?? '') !== (string)$v) { $o[$k] = $old[$k] ?? null; $n[$k] = $v; }
    }
    return [$o, $n];
}

// ---------------------------------------------------------------- Notifications
/** @param int[] $userIds */
function notify(array $userIds, string $titre, string $message = '', ?string $lien = null, string $type = 'info', ?string $cle = null): void
{
    foreach (array_unique(array_filter($userIds)) as $uidTarget) {
        try {
            q('INSERT IGNORE INTO notifications (user_id,type,titre,message,lien,cle) VALUES (?,?,?,?,?,?)', [$uidTarget, $type, $titre, mb_substr($message, 0, 500), $lien, $cle ? mb_substr($cle, 0, 120) : null]);
        } catch (Throwable $e) { error_log('[eFlotte][notify] ' . $e->getMessage()); }
    }
}
function users_by_role(string $role, ?int $serviceId = null): array
{
    $sql = 'SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE u.actif=1 AND u.ministere_id=? AND r.code=?';
    $p = [mid(), $role];
    if ($serviceId !== null) { $sql .= ' AND u.service_id=?'; $p[] = $serviceId; }
    return array_column(rows($sql, $p), 'id');
}
function unread_count(): int { return (int)val('SELECT COUNT(*) FROM notifications WHERE user_id=? AND lu=0', [uid()]); }
