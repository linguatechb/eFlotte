<?php
declare(strict_types=1);

if ($A === 'read_all' && is_post()) { q('UPDATE notifications SET lu=1 WHERE user_id=?', [uid()]); redirect(url('notifications')); }
if ($A === 'open') {
    $n = row('SELECT * FROM notifications WHERE id=? AND user_id=?', [(int)qget('id'), uid()]);
    if ($n) { q('UPDATE notifications SET lu=1 WHERE id=?', [$n['id']]); }
    $l = $n['lien'] ?? ''; redirect(($l !== '' && str_starts_with($l, ROOT_URL . '/')) ? $l : url('notifications'));
}
$pg = paginate('n.*', 'notifications n WHERE n.user_id=?', [uid()], ['date' => 'n.created_at', 'lu' => 'n.lu'], 'date', 'desc', 20);
page_start('Notifications', ['actions' => unread_count() ? '<form method="post" action="' . e(url('notifications', 'read_all')) . '">' . csrf_field() . btn('<i class="fa-solid fa-check-double"></i> Tout marquer comme lu', 'secondary') . '</form>' : '']);
card_start();
if (!$pg['rows']) { echo empty_state('Aucune notification pour le moment.', 'fa-bell'); }
echo '<ul class="divide-y divide-slate-100">';
foreach ($pg['rows'] as $n) {
    $ic = ['info' => 'fa-circle-info text-sky-600', 'success' => 'fa-circle-check text-emerald-600', 'warning' => 'fa-triangle-exclamation text-amber-600', 'danger' => 'fa-circle-exclamation text-red-600'][$n['type']];
    echo '<li><a href="' . e(url('notifications', 'open', ['id' => $n['id']])) . '" class="flex gap-3 px-5 py-3.5 hover:bg-slate-50 ' . ($n['lu'] ? '' : 'bg-brand-50/60') . '"><i class="fa-solid ' . $ic . ' mt-1"></i><div class="min-w-0 flex-1"><div class="text-sm ' . ($n['lu'] ? 'font-medium' : 'font-bold') . '">' . e($n['titre']) . '</div><div class="text-sm text-slate-600">' . e($n['message']) . '</div></div><div class="shrink-0 text-xs text-slate-400">' . fmt_dt($n['created_at']) . '</div></a></li>';
}
echo '</ul>' . pager($pg); card_end(); page_end();
