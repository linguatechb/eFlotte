<?php
declare(strict_types=1);

require_perm('users.manage');
function usr_get(int $id): ?array { return row('SELECT u.*, r.code role FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=? AND u.ministere_id=?', [$id, mid()]); }
function role_options(): array { $o = []; foreach (rows('SELECT id, code, libelle FROM roles ORDER BY id') as $r) { $o[$r['id']] = $r['libelle']; } return $o; }
function service_options(): array { $o = []; foreach (rows('SELECT id, nom, sigle FROM services WHERE ministere_id=? ORDER BY nom', [mid()]) as $s) { $o[$s['id']] = $s['nom'] . ($s['sigle'] ? ' (' . $s['sigle'] . ')' : ''); } return $o; }
function other_active_admins(int $exceptId): int { return (int)val("SELECT COUNT(*) FROM users u JOIN roles r ON r.id=u.role_id WHERE r.code='superadmin' AND u.actif=1 AND u.ministere_id=? AND u.id<>?", [mid(), $exceptId]); }

if ($A === 'save' && is_post()) {
    $id = post_int('id'); $old = $id ? usr_get($id) : null; if ($id && !$old) { http_response_code(404); exit('Utilisateur introuvable.'); }
    $d = ['nom' => mb_strtoupper(post('nom')), 'prenoms' => post('prenoms'), 'email' => mb_strtolower(post('email')), 'matricule' => post('matricule') ?: null, 'telephone' => post('telephone') ?: null, 'fonction' => post('fonction') ?: null,
          'role_id' => (int)post('role_id'), 'service_id' => post_int('service_id') ?: null, 'actif' => post('actif') === '1' ? 1 : 0];
    $errs = []; $roleCode = val('SELECT code FROM roles WHERE id=?', [$d['role_id']]);
    if ($d['nom'] === '' || $d['prenoms'] === '') { $errs[] = 'Nom et prénoms obligatoires.'; }
    if (!filter_var($d['email'], FILTER_VALIDATE_EMAIL)) { $errs[] = 'Adresse e-mail invalide.'; }
    if (!$roleCode) { $errs[] = 'Rôle invalide.'; }
    if ($d['service_id'] && !val('SELECT COUNT(*) FROM services WHERE id=? AND ministere_id=?', [$d['service_id'], mid()])) { $errs[] = 'Service invalide.'; }
    if (in_array($roleCode, ['agent', 'validateur'], true) && !$d['service_id']) { $errs[] = 'Un agent ou un validateur doit être rattaché à un service (périmètre de validation).'; }
    if (val('SELECT COUNT(*) FROM users WHERE email=? AND id<>?', [$d['email'], $id ?? 0])) { $errs[] = 'Cette adresse e-mail est déjà utilisée.'; }
    if ($old && $id === uid() && ($roleCode !== $old['role'] || !$d['actif'])) { $errs[] = 'Vous ne pouvez pas modifier votre propre rôle ni désactiver votre propre compte.'; }
    if ($old && $old['role'] === 'superadmin' && ($roleCode !== 'superadmin' || !$d['actif']) && !other_active_admins($id)) { $errs[] = 'Au moins un Super-Admin actif doit subsister.'; }
    $pwd = (string)($_POST['password'] ?? '');
    if (!$old || $pwd !== '') { if ($e = password_policy_error($pwd)) { $errs[] = $e; } }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect($id ? url('users', 'form', ['id' => $id]) : url('users', 'form')); }
    if ($old) {
        if ($pwd !== '') { $d['password_hash'] = password_hash($pwd, PASSWORD_DEFAULT); }
        update('users', $id, $d); [$o, $n] = diff_vals($old, $d); audit('utilisateur.modification', 'users', $id, $o, $n + ($pwd !== '' ? ['mot_de_passe' => 'réinitialisé'] : []));
        if ($roleCode !== $old['role']) { audit('utilisateur.changement_role', 'users', $id, ['role' => $old['role']], ['role' => $roleCode]); }
    } else { $d += ['ministere_id' => mid(), 'password_hash' => password_hash($pwd, PASSWORD_DEFAULT)]; $id = insert('users', $d); audit('utilisateur.creation', 'users', $id, null, $d + ['role' => $roleCode]); }
    unset($_SESSION['old']); flash('success', 'Utilisateur enregistré.'); redirect(url('users'));
}
if ($A === 'toggle' && is_post()) {
    $x = usr_get((int)post('id')); if (!$x) { http_response_code(404); exit('Introuvable.'); }
    if ((int)$x['id'] === uid()) { flash('error', 'Vous ne pouvez pas désactiver votre propre compte.'); redirect(url('users')); }
    if ($x['actif'] && $x['role'] === 'superadmin' && !other_active_admins((int)$x['id'])) { flash('error', 'Au moins un Super-Admin actif doit subsister.'); redirect(url('users')); }
    update('users', (int)$x['id'], ['actif' => $x['actif'] ? 0 : 1]); audit('utilisateur.' . ($x['actif'] ? 'desactivation' : 'activation'), 'users', $x['id'], ['actif' => $x['actif']], ['actif' => $x['actif'] ? 0 : 1]);
    flash('success', $x['actif'] ? 'Compte désactivé.' : 'Compte réactivé.'); redirect(url('users'));
}
if ($A === 'delete' && is_post()) {
    $x = usr_get((int)post('id')); if (!$x) { http_response_code(404); exit('Introuvable.'); }
    if ((int)$x['id'] === uid()) { flash('error', 'Vous ne pouvez pas supprimer votre propre compte.'); redirect(url('users')); }
    $ties = (int)val('SELECT (SELECT COUNT(*) FROM reservations WHERE demandeur_id=? OR validateur_id=? OR attribue_par=?) + (SELECT COUNT(*) FROM audit_logs WHERE user_id=?)', array_fill(0, 4, $x['id']));
    if ($ties) { flash('error', 'Cet utilisateur possède un historique (réservations / journal) : désactivez-le plutôt que de le supprimer.'); redirect(url('users')); }
    q('DELETE FROM users WHERE id=?', [$x['id']]); audit('utilisateur.suppression', 'users', $x['id'], $x, null); flash('success', 'Utilisateur supprimé.'); redirect(url('users'));
}
if ($A === 'form') {
    $id = (int)qget('id'); $x = $id ? usr_get($id) : null; if ($id && !$x) { http_response_code(404); exit('Introuvable.'); }
    $x = array_merge($x ?? ['nom' => '', 'prenoms' => '', 'email' => '', 'matricule' => '', 'telephone' => '', 'fonction' => '', 'role_id' => 1, 'service_id' => '', 'actif' => 1], $_SESSION['old'] ?? []); unset($_SESSION['old']);
    page_start($id ? 'Modifier l\'utilisateur' : 'Nouvel utilisateur');
    echo '<form method="post" action="' . e(url('users', 'save')) . '">' . csrf_field() . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : ''); card_start('Compte utilisateur', '', 'mx-auto max-w-4xl');
    echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_input('Nom', 'nom', $x['nom'], ['required' => 1]) . f_input('Prénoms', 'prenoms', $x['prenoms'], ['required' => 1]) . f_input('Adresse e-mail (identifiant)', 'email', $x['email'], ['type' => 'email', 'required' => 1]) . f_input('Matricule', 'matricule', $x['matricule'])
        . f_input('Téléphone', 'telephone', $x['telephone']) . f_input('Fonction', 'fonction', $x['fonction'], ['placeholder' => 'ex. Directeur des Études'])
        . f_select('Profil / rôle', 'role_id', role_options(), $x['role_id'], ['required' => 1]) . f_select('Service', 'service_id', service_options(), $x['service_id'], ['empty' => '— Aucun —', 'help' => 'Obligatoire pour agents et validateurs : définit le périmètre de validation.'])
        . f_select('Statut', 'actif', ['1' => 'Actif', '0' => 'Désactivé'], (string)$x['actif']) . f_input($id ? 'Nouveau mot de passe (laisser vide pour conserver)' : 'Mot de passe initial', 'password', '', ['type' => 'password', 'autocomplete' => 'new-password', 'required' => $id ? null : 1, 'help' => '8 caractères minimum, avec majuscule, minuscule et chiffre.'])
        . '</div><div class="flex justify-end gap-2 border-t border-slate-100 px-5 py-4">' . link_btn(url('users'), 'Annuler') . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer') . '</div>'; card_end(); echo '</form>'; page_end(); exit;
}
$w = ['u.ministere_id=?']; $p = [mid()];
if (($q = qget('q')) !== '') { $w[] = '(u.nom LIKE ? OR u.prenoms LIKE ? OR u.email LIKE ? OR u.matricule LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
if ((int)qget('role_id')) { $w[] = 'u.role_id=?'; $p[] = (int)qget('role_id'); }
$pg = paginate('u.*, r.libelle role_lib, r.code role_code, s.nom service_nom', 'users u JOIN roles r ON r.id=u.role_id LEFT JOIN services s ON s.id=u.service_id WHERE ' . implode(' AND ', $w), $p, ['nom' => 'u.nom', 'role' => 'r.id', 'service' => 's.nom', 'connexion' => 'u.derniere_connexion', 'statut' => 'u.actif'], 'nom', 'asc');
page_start('Utilisateurs et rôles', ['actions' => link_btn(url('users', 'form'), '<i class="fa-solid fa-user-plus"></i> Nouvel utilisateur', 'primary')]);
card_start(); echo search_bar(['role_id' => [role_options(), 'Tous les profils']], 'Nom, e-mail, matricule…');
echo tbl_start() . th_sort('Utilisateur', 'nom', $pg) . th_sort('Profil', 'role', $pg) . th_sort('Service', 'service', $pg) . th_sort('Dernière connexion', 'connexion', $pg) . th_sort('Statut', 'statut', $pg) . th('') . tbl_mid();
foreach ($pg['rows'] as $x) {
    $me = (int)$x['id'] === uid();
    echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3"><div class="font-semibold">' . e($x['nom'] . ' ' . $x['prenoms']) . ($me ? ' <span class="text-xs text-brand">(vous)</span>' : '') . '</div><div class="text-xs text-slate-500">' . e($x['email']) . '</div></td><td class="px-4 py-3">' . e($x['role_lib']) . '</td><td class="px-4 py-3">' . e($x['service_nom'] ?: '—') . '</td><td class="px-4 py-3 whitespace-nowrap text-xs">' . fmt_dt($x['derniere_connexion']) . '</td><td class="px-4 py-3">' . badge($x['actif'] ? 'Actif' : 'Inactif') . '</td><td class="px-4 py-3 text-right whitespace-nowrap"><a class="mr-2 text-brand hover:underline" href="' . e(url('users', 'form', ['id' => $x['id']])) . '">Modifier</a>'
        . (!$me ? confirm_form(url('users', 'toggle'), '<button class="mr-2 text-amber-700 hover:underline">' . ($x['actif'] ? 'Désactiver' : 'Réactiver') . '</button>', ($x['actif'] ? 'Désactiver' : 'Réactiver') . ' le compte de ' . $x['prenoms'] . ' ' . $x['nom'] . ' ?', ['id' => $x['id']]) . confirm_form(url('users', 'delete'), '<button class="text-red-700 hover:underline">Supprimer</button>', 'Supprimer définitivement ce compte ?', ['id' => $x['id']]) : '') . '</td></tr>';
}
echo tbl_end() . pager($pg); card_end(); page_end();
