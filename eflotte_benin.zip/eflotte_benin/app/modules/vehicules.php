<?php
declare(strict_types=1);

require_perm('vehicules.view');

function veh_photo(?string $p, string $cls = 'h-40'): string
{
    return $p ? '<img src="' . e(UPLOAD_URL . '/vehicules/' . $p) . '" alt="" class="' . $cls . ' w-full object-cover" loading="lazy">'
              : '<div class="' . $cls . ' grid w-full place-items-center bg-gradient-to-br from-brand-50 to-brand-100 text-brand/40"><i class="fa-solid fa-car-side text-5xl"></i></div>';
}
function veh_get(int $id): ?array { return row('SELECT * FROM vehicules WHERE id=? AND ministere_id=?', [$id, mid()]); }

// ================================================================== Enregistrement
if ($A === 'save' && is_post()) {
    require_perm('vehicules.manage');
    $id = post_int('id'); $old = $id ? veh_get($id) : null;
    if ($id && !$old) { http_response_code(404); exit('Véhicule introuvable.'); }
    $d = ['marque' => post('marque'), 'modele' => post('modele'), 'immatriculation' => mb_strtoupper(preg_replace('/\s+/', ' ', post('immatriculation'))), 'numero_chassis' => mb_strtoupper(post('numero_chassis')),
          'carburant' => post('carburant'), 'annee' => (int)post('annee'), 'kilometrage' => (int)post('kilometrage'), 'date_acquisition' => post('date_acquisition'),
          'valeur_acquisition' => (int)post('valeur_acquisition'), 'observations' => post('observations')];
    $errs = [];
    if ($d['marque'] === '' || mb_strlen($d['marque']) > 60) { $errs[] = 'La marque est obligatoire (60 caractères max).'; }
    if ($d['modele'] === '' || mb_strlen($d['modele']) > 80) { $errs[] = 'Le modèle est obligatoire.'; }
    if (!preg_match('/^[A-Z0-9][A-Z0-9 \-]{3,28}$/', $d['immatriculation'])) { $errs[] = 'Immatriculation officielle invalide (ex. AD 3412 RB).'; }
    if (!preg_match('/^[A-Z0-9\-]{5,40}$/', $d['numero_chassis'])) { $errs[] = 'Numéro de châssis invalide (lettres/chiffres, 5 à 40 caractères).'; }
    if (!in_array($d['carburant'], CARBURANTS, true)) { $errs[] = 'Type de carburant invalide.'; }
    if ($d['annee'] < 1980 || $d['annee'] > (int)date('Y') + 1) { $errs[] = 'Année de mise en circulation invalide.'; }
    if (!valid_date($d['date_acquisition'])) { $errs[] = 'Date d\'acquisition invalide.'; }
    if ($d['kilometrage'] < 0 || $d['valeur_acquisition'] < 0) { $errs[] = 'Kilométrage et valeur doivent être positifs.'; }
    if ($old && $d['kilometrage'] < (int)$old['kilometrage'] && post('confirm_km') !== '1') { $errs[] = 'Le kilométrage ne peut pas diminuer (' . nb($old['kilometrage']) . ' km enregistrés).'; }
    $etat = post('etat'); $auto = ['En mission', 'En maintenance'];
    if ($old && in_array($old['etat'], $auto, true)) { $etat = $old['etat']; } elseif (!in_array($etat, ['Disponible', 'Immobilisé', 'Réformé'], true)) { $etat = 'Disponible'; }
    $d['etat'] = $etat;
    if ($d['immatriculation'] && val('SELECT COUNT(*) FROM vehicules WHERE ministere_id=? AND immatriculation=? AND id<>?', [mid(), $d['immatriculation'], $id ?? 0])) { $errs[] = 'Cette immatriculation existe déjà.'; }
    if ($d['numero_chassis'] && val('SELECT COUNT(*) FROM vehicules WHERE ministere_id=? AND numero_chassis=? AND id<>?', [mid(), $d['numero_chassis'], $id ?? 0])) { $errs[] = 'Ce numéro de châssis existe déjà.'; }
    $photo = $old['photo'] ?? null; $newPhoto = null;
    if (!$errs && has_upload('photo')) {
        try { [$newPhoto] = save_upload($_FILES['photo'], 'image', UPLOAD_PUBLIC . '/vehicules', 5 * 1048576); $d['photo'] = $newPhoto; } catch (RuntimeException $e) { $errs[] = $e->getMessage(); }
    } elseif ($old && post('remove_photo') === '1') { $d['photo'] = null; }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect($id ? url('vehicules', 'form', ['id' => $id]) : url('vehicules', 'form')); }
    if ($old) {
        update('vehicules', $id, $d);
        if (array_key_exists('photo', $d) && $old['photo'] && $d['photo'] !== $old['photo']) { delete_file($old['photo'], UPLOAD_PUBLIC . '/vehicules'); }   // suppression sécurisée de l'ancienne image
        [$o, $n] = diff_vals($old, $d); audit('vehicule.modification', 'vehicules', $id, $o, $n);
        sync_vehicule_etat($id); flash('success', 'Véhicule mis à jour.');
    } else {
        $d += ['ministere_id' => mid(), 'created_by' => uid()];
        $id = insert('vehicules', $d); audit('vehicule.creation', 'vehicules', $id, null, $d); flash('success', 'Véhicule créé.');
    }
    unset($_SESSION['old']); redirect(url('vehicules', 'show', ['id' => $id]));
}

// ================================================================== Suppression / archivage
if (($A === 'delete' || $A === 'unarchive') && is_post()) {
    require_perm('vehicules.manage');
    $v = veh_get((int)post('id')); if (!$v) { http_response_code(404); exit('Véhicule introuvable.'); }
    if ($A === 'unarchive') { update('vehicules', (int)$v['id'], ['est_archive' => 0]); audit('vehicule.desarchivage', 'vehicules', $v['id'], ['est_archive' => 1], ['est_archive' => 0]); flash('success', 'Véhicule réactivé.'); redirect(url('vehicules', 'show', ['id' => $v['id']])); }
    if (in_array($v['etat'], ['En mission', 'En maintenance'], true) || val("SELECT COUNT(*) FROM reservations WHERE vehicule_id=? AND statut IN ('Attribuée','En cours')", [$v['id']])) {
        flash('error', 'Impossible de retirer ce véhicule : mission ou maintenance active / attribuée.'); redirect(url('vehicules', 'show', ['id' => $v['id']]));
    }
    $deps = (int)val('SELECT (SELECT COUNT(*) FROM reservations WHERE vehicule_id=? OR vehicule_souhaite_id=?) + (SELECT COUNT(*) FROM maintenances WHERE vehicule_id=?) + (SELECT COUNT(*) FROM depenses WHERE vehicule_id=?) + (SELECT COUNT(*) FROM assurances WHERE vehicule_id=?) + (SELECT COUNT(*) FROM visites_techniques WHERE vehicule_id=?)', array_fill(0, 6, $v['id']));
    if ($deps > 0) {
        update('vehicules', (int)$v['id'], ['est_archive' => 1]); audit('vehicule.archivage', 'vehicules', $v['id'], ['est_archive' => 0], ['est_archive' => 1, 'motif' => 'historique existant']);
        flash('success', 'Le véhicule possède un historique : il a été archivé (conservation de la traçabilité).');
    } else {
        delete_file($v['photo'], UPLOAD_PUBLIC . '/vehicules'); q('DELETE FROM vehicules WHERE id=?', [$v['id']]); audit('vehicule.suppression', 'vehicules', $v['id'], $v, null);
        flash('success', 'Véhicule supprimé définitivement.');
    }
    redirect(url('vehicules'));
}

// ================================================================== Formulaire
if ($A === 'form') {
    require_perm('vehicules.manage');
    $id = (int)qget('id'); $v = $id ? veh_get($id) : null; if ($id && !$v) { http_response_code(404); exit('Véhicule introuvable.'); }
    $v = array_merge($v ?? ['marque' => '', 'modele' => '', 'immatriculation' => '', 'numero_chassis' => '', 'carburant' => 'Diesel', 'annee' => date('Y'), 'kilometrage' => 0, 'date_acquisition' => date('Y-m-d'), 'valeur_acquisition' => 0, 'etat' => 'Disponible', 'photo' => null, 'observations' => ''], $_SESSION['old'] ?? []); unset($_SESSION['old']);
    page_start($id ? 'Modifier le véhicule' : 'Nouveau véhicule');
    echo '<form method="post" enctype="multipart/form-data" action="' . e(url('vehicules', 'save')) . '">' . csrf_field() . ($id ? '<input type="hidden" name="id" value="' . $id . '">' : '');
    echo '<div class="grid gap-6 lg:grid-cols-3">';
    card_start('Identification', '', 'lg:col-span-2'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">'
        . f_input('Marque', 'marque', $v['marque'], ['required' => 1, 'maxlength' => 60]) . f_input('Modèle', 'modele', $v['modele'], ['required' => 1, 'maxlength' => 80])
        . f_input('Immatriculation officielle', 'immatriculation', $v['immatriculation'], ['required' => 1, 'maxlength' => 30, 'placeholder' => 'AD 3412 RB'])
        . f_input('Numéro de châssis (VIN)', 'numero_chassis', $v['numero_chassis'], ['required' => 1, 'maxlength' => 40])
        . f_select('Type de carburant', 'carburant', array_combine(CARBURANTS, CARBURANTS), $v['carburant'], ['required' => 1])
        . f_input('Année de mise en circulation', 'annee', $v['annee'], ['type' => 'number', 'min' => 1980, 'max' => (int)date('Y') + 1, 'required' => 1])
        . f_input('Kilométrage actuel (km)', 'kilometrage', $v['kilometrage'], ['type' => 'number', 'min' => 0, 'required' => 1])
        . f_input('Date d\'acquisition', 'date_acquisition', $v['date_acquisition'], ['type' => 'date', 'required' => 1])
        . f_input('Valeur d\'acquisition (FCFA)', 'valeur_acquisition', $v['valeur_acquisition'], ['type' => 'number', 'min' => 0, 'step' => 1, 'required' => 1]);
    if ($id && in_array($v['etat'], ['En mission', 'En maintenance'], true)) { echo '<div><label class="mb-1 block text-sm font-medium">État opérationnel</label><div class="py-2">' . badge($v['etat']) . '</div><p class="text-xs text-slate-500">État géré automatiquement (mission / maintenance en cours).</p></div>'; }
    else { echo f_select('État opérationnel', 'etat', ['Disponible' => 'Disponible', 'Immobilisé' => 'Immobilisé', 'Réformé' => 'Réformé'], $v['etat'], ['help' => 'Les états « En mission » et « En maintenance » sont calculés automatiquement.']); }
    echo f_textarea('Observations', 'observations', $v['observations'], ['col' => 'sm:col-span-2', 'rows' => 3]) . '</div>'; card_end();
    card_start('Photo du véhicule'); echo '<div class="space-y-3 p-5"><div class="overflow-hidden rounded-lg border border-slate-200">' . veh_photo($v['photo'], 'h-44') . '</div>'
        . '<img id="photo-prev" class="hidden h-44 w-full rounded-lg object-cover" alt="">'
        . '<input type="file" name="photo" accept="image/jpeg,image/png,image/webp" data-preview="#photo-prev" class="block w-full">'
        . '<p class="text-xs text-slate-500">JPG, PNG ou WEBP — 5 Mo max. Le fichier est vérifié (type MIME réel), ré-encodé et renommé aléatoirement.</p>'
        . ($v['photo'] ? '<label class="flex items-center gap-2 text-sm"><input type="checkbox" name="remove_photo" value="1" class="rounded border-slate-300"> Supprimer la photo actuelle</label>' : '') . '</div>'; card_end();
    echo '</div><div class="mt-6 flex justify-end gap-2">' . link_btn($id ? url('vehicules', 'show', ['id' => $id]) : url('vehicules'), 'Annuler') . btn('<i class="fa-solid fa-floppy-disk"></i> Enregistrer', 'primary') . '</div></form>';
    page_end(); exit;
}

// ================================================================== Fiche détaillée
if ($A === 'show') {
    $v = veh_get((int)qget('id')); if (!$v) { http_response_code(404); page_start('Introuvable'); echo empty_state('Véhicule introuvable.'); page_end(); exit; }
    $id = (int)$v['id']; $manage = can('vehicules.manage'); $fin = can('depenses.view');
    $act = '';
    if ($manage) {
        $act .= link_btn(url('vehicules', 'form', ['id' => $id]), '<i class="fa-solid fa-pen"></i> Modifier');
        $act .= $v['est_archive'] ? confirm_form(url('vehicules', 'unarchive'), btn('<i class="fa-solid fa-box-open"></i> Réactiver', 'secondary'), 'Réactiver ce véhicule archivé ?', ['id' => $id])
                                  : confirm_form(url('vehicules', 'delete'), btn('<i class="fa-solid fa-trash"></i> Supprimer / archiver', 'danger'), 'Supprimer ce véhicule ? S\'il possède un historique, il sera archivé au lieu d\'être supprimé.', ['id' => $id]);
    }
    page_start($v['marque'] . ' ' . $v['modele'], ['actions' => link_btn(url('vehicules'), '<i class="fa-solid fa-arrow-left"></i> Parc') . $act]);
    $a = last_assurance($id); $t = last_visite($id); $dA = (int)param('alerte_assurance_jours', 30); $dV = (int)param('alerte_visite_jours', 30);
    echo '<div class="grid gap-6 lg:grid-cols-3"><div class="space-y-6 lg:col-span-1">';
    card_start('', '', 'overflow-hidden'); echo veh_photo($v['photo'], 'h-56') . '<div class="p-5"><div class="flex items-start justify-between gap-2"><div><div class="text-lg font-extrabold">' . e($v['marque'] . ' ' . $v['modele']) . '</div><div class="mt-0.5 font-mono text-sm text-slate-600">' . e($v['immatriculation']) . '</div></div><div class="flex flex-col items-end gap-1">' . badge($v['etat']) . ($v['est_archive'] ? badge('Archivé') : '') . '</div></div>';
    echo '<dl class="mt-4 grid grid-cols-2 gap-y-2.5 text-sm">';
    foreach ([['Carburant', $v['carburant']], ['Année', $v['annee']], ['Kilométrage', nb($v['kilometrage']) . ' km'], ['Acquisition', fmt_date($v['date_acquisition'])], ['Valeur d\'acquisition', fcfa($v['valeur_acquisition'])], ['N° de châssis', $v['numero_chassis']]] as [$k, $x]) { echo '<dt class="text-slate-500">' . e($k) . '</dt><dd class="text-right font-medium break-all">' . e($x) . '</dd>'; }
    echo '</dl>' . ($v['observations'] ? '<p class="mt-4 rounded-lg bg-slate-50 p-3 text-sm text-slate-600">' . nl2br(e($v['observations'])) . '</p>' : '') . '</div>'; card_end();
    card_start('Conformité réglementaire'); echo '<div class="divide-y divide-slate-100 text-sm"><div class="flex items-center justify-between px-5 py-3"><div><div class="font-medium">Assurance</div><div class="text-xs text-slate-500">' . ($a ? e($a['compagnie']) . ' · ' . e($a['numero_police']) . ' · échéance ' . fmt_date($a['date_expiration']) : 'Aucune assurance enregistrée') . '</div></div>' . badge(echeance_statut($a['date_expiration'] ?? null, $dA)) . '</div>'
        . '<div class="flex items-center justify-between px-5 py-3"><div><div class="font-medium">Visite technique</div><div class="text-xs text-slate-500">' . ($t ? 'prochaine visite ' . fmt_date($t['date_prochaine']) : 'Aucune visite enregistrée') . '</div></div>' . badge(echeance_statut($t['date_prochaine'] ?? null, $dV)) . '</div></div>'; card_end();
    echo '</div><div class="space-y-6 lg:col-span-2">';

    // Prochaines affectations
    $next = rows("SELECT r.id, r.reference, r.destination, r.date_depart, r.date_retour, r.statut FROM reservations r WHERE r.vehicule_id=? AND r.statut IN ('Attribuée','En cours') ORDER BY r.date_depart", [$id]);
    $mn = rows("SELECT * FROM maintenances WHERE vehicule_id=? AND statut IN ('Planifiée','En cours') ORDER BY date_maintenance", [$id]);
    $fullView = in_array(role(), ['gestionnaire', 'superadmin'], true);   // détail des missions : réservé à l'administration du parc
    card_start('Disponibilité — missions et maintenances à venir');
    if (!$next && !$mn) { echo '<div class="px-5 py-4 text-sm text-slate-600"><i class="fa-solid fa-circle-check mr-1 text-emerald-600"></i> Aucune affectation ni maintenance prévue.</div>'; }
    else { echo '<ul class="divide-y divide-slate-100 text-sm">'; foreach ($next as $r) { echo '<li class="flex items-center justify-between gap-3 px-5 py-3"><div>' . ($fullView ? '<a class="font-semibold text-brand hover:underline" href="' . e(url('reservations', 'show', ['id' => $r['id']])) . '">' . e($r['reference']) . '</a> — ' . e($r['destination']) : '<span class="font-semibold">Véhicule réservé</span>') . '<div class="text-xs text-slate-500">' . fmt_dt($r['date_depart']) . ' → ' . fmt_dt($r['date_retour']) . '</div></div>' . ($fullView ? badge($r['statut']) : badge('Indisponible', 'slate')) . '</li>'; }
        foreach ($mn as $m) { echo '<li class="flex items-center justify-between gap-3 px-5 py-3"><div><span class="font-semibold">Maintenance : ' . e($m['categorie']) . '</span><div class="text-xs text-slate-500">' . fmt_date($m['date_maintenance']) . ($m['date_fin'] ? ' → ' . fmt_date($m['date_fin']) : '') . '</div></div>' . badge($m['statut']) . '</li>'; } echo '</ul>'; }
    card_end();

    // Historique des missions
    $hist = rows("SELECT r.id, r.reference, r.destination, r.date_depart, r.statut, r.km_depart, r.km_retour, CONCAT(c.prenoms,' ',c.nom) chauffeur FROM reservations r LEFT JOIN chauffeurs c ON c.id=r.chauffeur_id WHERE r.vehicule_id=? ORDER BY r.date_depart DESC LIMIT 15", [$id]);
    $kmTot = (int)val("SELECT COALESCE(SUM(km_retour-km_depart),0) FROM reservations WHERE vehicule_id=? AND statut='Terminée'", [$id]);
    if ($fullView) { card_start('Historique des missions', '<span class="text-xs text-slate-500">' . nb($kmTot) . ' km parcourus en mission</span>');
    if (!$hist) { echo empty_state('Aucune mission enregistrée.'); } else {
        echo tbl_start() . th('Référence') . th('Destination') . th('Départ') . th('Chauffeur') . th('Km') . th('Statut') . tbl_mid();
        foreach ($hist as $r) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-2.5"><a class="font-semibold text-brand hover:underline" href="' . e(url('reservations', 'show', ['id' => $r['id']])) . '">' . e($r['reference']) . '</a></td><td class="px-4 py-2.5">' . e($r['destination']) . '</td><td class="px-4 py-2.5 whitespace-nowrap">' . fmt_dt($r['date_depart']) . '</td><td class="px-4 py-2.5">' . e($r['chauffeur'] ?: '—') . '</td><td class="px-4 py-2.5">' . ($r['km_retour'] !== null ? nb($r['km_retour'] - $r['km_depart']) : '—') . '</td><td class="px-4 py-2.5">' . badge($r['statut']) . '</td></tr>'; }
        echo tbl_end();
    }
    card_end(); }

    if (can('maintenances.view')) {
        $ms = rows('SELECT * FROM maintenances WHERE vehicule_id=? ORDER BY date_maintenance DESC LIMIT 8', [$id]);
        card_start('Maintenances', link_btn(url('maintenances', null, ['vehicule_id' => $id]), 'Tout voir'));
        if (!$ms) { echo empty_state('Aucune maintenance enregistrée.'); } else {
            echo tbl_start() . th('Date') . th('Type') . th('Catégorie') . th('Coût') . th('Statut') . tbl_mid();
            foreach ($ms as $m) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-2.5">' . fmt_date($m['date_maintenance']) . '</td><td class="px-4 py-2.5">' . badge($m['type']) . '</td><td class="px-4 py-2.5">' . e($m['categorie']) . '</td><td class="px-4 py-2.5">' . fcfa($m['cout']) . '</td><td class="px-4 py-2.5">' . badge($m['statut']) . '</td></tr>'; }
            echo tbl_end();
        } card_end();
    }
    if ($fin) {
        $tot = (float)val('SELECT COALESCE(SUM(montant),0) FROM depenses WHERE vehicule_id=?', [$id]);
        $cats = rows('SELECT categorie, SUM(montant) s FROM depenses WHERE vehicule_id=? GROUP BY categorie ORDER BY s DESC', [$id]);
        card_start('Dépenses cumulées', '<span class="text-sm font-bold text-brand">' . fcfa($tot) . '</span>' . ($kmTot > 0 ? '<span class="text-xs text-slate-500">· ' . fcfa($tot / $kmTot) . ' / km</span>' : ''));
        if (!$cats) { echo empty_state('Aucune dépense enregistrée.'); } else { echo '<div class="space-y-2.5 p-5">'; foreach ($cats as $c) { $pct = $tot > 0 ? round($c['s'] / $tot * 100) : 0; echo '<div><div class="mb-1 flex justify-between text-xs"><span>' . e($c['categorie']) . '</span><span class="font-medium">' . fcfa($c['s']) . ' · ' . $pct . ' %</span></div><div class="h-1.5 rounded-full bg-slate-100"><div class="h-1.5 rounded-full bg-brand" style="width:' . $pct . '%"></div></div></div>'; } echo '</div>'; }
        card_end();
    }
    echo '</div></div>'; page_end(); exit;
}

// ================================================================== Liste
$view = qget('view', 'cards') === 'table' ? 'table' : 'cards';
$w = ['v.ministere_id=?']; $p = [mid()];
if (qget('arch') !== '1') { $w[] = 'v.est_archive=0'; } else { $w[] = 'v.est_archive=1'; }
if (($q = qget('q')) !== '') { $w[] = '(v.marque LIKE ? OR v.modele LIKE ? OR v.immatriculation LIKE ? OR v.numero_chassis LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%"); }
if (in_array(qget('etat'), ETATS, true)) { $w[] = 'v.etat=?'; $p[] = qget('etat'); }
if (in_array(qget('carburant'), CARBURANTS, true)) { $w[] = 'v.carburant=?'; $p[] = qget('carburant'); }
$pg = paginate('v.*', 'vehicules v WHERE ' . implode(' AND ', $w), $p, ['vehicule' => 'v.marque', 'immat' => 'v.immatriculation', 'annee' => 'v.annee', 'km' => 'v.kilometrage', 'etat' => 'v.etat'], 'vehicule', 'asc', $view === 'cards' ? 12 : 15);
$kpi = array_column(rows('SELECT etat, COUNT(*) n FROM vehicules WHERE ministere_id=? AND est_archive=0 GROUP BY etat', [mid()]), 'n', 'etat');
$actions = link_btn(qs(['view' => $view === 'cards' ? 'table' : 'cards']), $view === 'cards' ? '<i class="fa-solid fa-table-list"></i> Tableau' : '<i class="fa-solid fa-grip"></i> Cartes')
         . link_btn(qs(['arch' => qget('arch') === '1' ? '' : '1', 'page' => 1]), '<i class="fa-solid fa-box-archive"></i> ' . (qget('arch') === '1' ? 'Véhicules actifs' : 'Archives'))
         . (can('vehicules.manage') ? link_btn(url('vehicules', 'form'), '<i class="fa-solid fa-plus"></i> Nouveau véhicule', 'primary') : '');
page_start('Parc automobile', ['actions' => $actions]);
echo '<div class="mb-5 grid grid-cols-2 gap-3 md:grid-cols-5">';
foreach (ETATS as $e_) { echo '<a href="' . e(qs(['etat' => $e_, 'page' => 1])) . '" class="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm hover:border-brand/40"><div class="text-2xl font-extrabold">' . (int)($kpi[$e_] ?? 0) . '</div><div class="mt-0.5">' . badge($e_) . '</div></a>'; }
echo '</div>';
card_start(); echo search_bar(['etat' => [array_combine(ETATS, ETATS), 'Tous les états'], 'carburant' => [array_combine(CARBURANTS, CARBURANTS), 'Tous carburants']], 'Marque, modèle, immatriculation, châssis…');
if (!$pg['rows']) { echo empty_state('Aucun véhicule ne correspond à votre recherche.', 'fa-car'); }
elseif ($view === 'cards') {
    echo '<div class="grid gap-4 border-t border-slate-100 p-5 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">';
    foreach ($pg['rows'] as $v) {
        echo '<a href="' . e(url('vehicules', 'show', ['id' => $v['id']])) . '" class="group overflow-hidden rounded-xl border border-slate-200 bg-white transition hover:border-brand/50 hover:shadow-md"><div class="relative">' . veh_photo($v['photo'], 'h-36') . '<div class="absolute right-2 top-2">' . badge($v['etat']) . '</div></div><div class="p-4"><div class="font-bold text-slate-900 group-hover:text-brand">' . e($v['marque'] . ' ' . $v['modele']) . '</div><div class="font-mono text-xs text-slate-500">' . e($v['immatriculation']) . '</div><div class="mt-3 flex justify-between text-xs text-slate-500"><span><i class="fa-solid fa-gas-pump mr-1"></i>' . e($v['carburant']) . '</span><span><i class="fa-solid fa-gauge mr-1"></i>' . nb($v['kilometrage']) . ' km</span><span>' . $v['annee'] . '</span></div></div></a>';
    }
    echo '</div>';
} else {
    echo tbl_start() . th_sort('Véhicule', 'vehicule', $pg) . th_sort('Immatriculation', 'immat', $pg) . th('Carburant') . th_sort('Année', 'annee', $pg) . th_sort('Kilométrage', 'km', $pg) . th_sort('État', 'etat', $pg) . th('') . tbl_mid();
    foreach ($pg['rows'] as $v) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 font-semibold">' . e($v['marque'] . ' ' . $v['modele']) . '</td><td class="px-4 py-3 font-mono text-xs">' . e($v['immatriculation']) . '</td><td class="px-4 py-3">' . e($v['carburant']) . '</td><td class="px-4 py-3">' . $v['annee'] . '</td><td class="px-4 py-3">' . nb($v['kilometrage']) . ' km</td><td class="px-4 py-3">' . badge($v['etat']) . '</td><td class="px-4 py-3 text-right"><a class="text-brand hover:underline" href="' . e(url('vehicules', 'show', ['id' => $v['id']])) . '">Fiche</a></td></tr>'; }
    echo tbl_end();
}
echo pager($pg); card_end(); page_end();
