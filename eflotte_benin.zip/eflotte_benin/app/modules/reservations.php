<?php
declare(strict_types=1);

/** Verrouille la réservation (transaction) et renvoie son état courant, dans le périmètre de l'utilisateur */
function res_lock(int $id): ?array
{
    $r = get_reservation($id); if (!$r) { return null; }
    return row('SELECT * FROM reservations WHERE id=? FOR UPDATE', [$id]) + ['_scoped' => true];
}
function res_link(int $id): string { return url('reservations', 'show', ['id' => $id]); }
function fail_back(int $id, array $errs): never { flash('error', implode('<br>', array_map('e', $errs))); redirect($id ? res_link($id) : url('reservations')); }

// ================================================================== 1-2. Soumission + PDF
if ($A === 'create' && is_post()) {
    require_perm('reservations.create');
    $u = user(); $errs = [];
    $d = ['motif' => post('motif'), 'destination' => post('destination'), 'dep' => post('date_depart'), 'ret' => post('date_retour'), 'vs' => post_int('vehicule_souhaite_id'), 'obs' => post('observations')];
    if (!$u['service_id']) { $errs[] = 'Votre compte n\'est rattaché à aucun service : impossible de déterminer le validateur. Contactez l\'administrateur.'; }
    if ($d['motif'] === '' || mb_strlen($d['motif']) > 255) { $errs[] = 'Le motif de la mission est obligatoire.'; }
    if ($d['destination'] === '' || mb_strlen($d['destination']) > 255) { $errs[] = 'La destination est obligatoire.'; }
    if (!valid_dt($d['dep']) || !valid_dt($d['ret'])) { $errs[] = 'Dates/heures de départ et de retour invalides.'; }
    else {
        if (substr($d['dep'], 0, 10) < date('Y-m-d')) { $errs[] = 'La date de départ ne peut pas être dans le passé.'; }
        if ($d['ret'] <= $d['dep']) { $errs[] = 'Le retour doit être postérieur au départ.'; }
    }
    if (!has_upload('ordre_mission')) { $errs[] = 'L\'ordre de mission signé (PDF) est obligatoire.'; }
    if (!$errs && $d['vs']) {
        $ck = vehicule_check($d['vs'], dt_sql($d['dep']), dt_sql($d['ret']));
        if ($ck['errors']) { $errs[] = 'Le véhicule souhaité n\'est pas disponible : ' . implode(' ', $ck['errors']); }
    }
    $file = null;
    if (!$errs) { try { $file = save_upload($_FILES['ordre_mission'], 'pdf', UPLOAD_PRIVATE . '/ordres_mission'); } catch (RuntimeException $e) { $errs[] = $e->getMessage(); } }
    if ($errs) { $_SESSION['old'] = $_POST; flash('error', implode('<br>', array_map('e', $errs))); redirect(url('reservations', 'new')); }
    try {
        db()->beginTransaction();
        $id = insert('reservations', ['ministere_id' => mid(), 'demandeur_id' => uid(), 'motif' => $d['motif'], 'destination' => $d['destination'], 'date_depart' => dt_sql($d['dep']), 'date_retour' => dt_sql($d['ret']),
            'vehicule_souhaite_id' => $d['vs'] ?: null, 'observations' => $d['obs'], 'ordre_mission_fichier' => $file[0], 'ordre_mission_nom' => $file[1], 'statut' => 'En attente']);
        q("UPDATE reservations SET reference=CONCAT('EFB-',YEAR(created_at),'-',LPAD(id,4,'0')) WHERE id=?", [$id]);
        histo($id, null, 'En attente', 'Demande soumise avec ordre de mission signé.');
        db()->commit();
    } catch (Throwable $e) { if (db()->inTransaction()) { db()->rollBack(); } delete_file($file[0], UPLOAD_PRIVATE . '/ordres_mission'); throw $e; }
    $ref = val('SELECT reference FROM reservations WHERE id=?', [$id]);
    audit('reservation.soumission', 'reservations', $id, null, ['reference' => $ref, 'destination' => $d['destination'], 'depart' => $d['dep'], 'retour' => $d['ret'], 'ordre_mission' => $file[1]]);
    notify(users_by_role('validateur', (int)$u['service_id']), 'Nouvelle demande à valider', $ref . ' — ' . $u['prenoms'] . ' ' . $u['nom'] . ' : ' . $d['destination'], res_link($id), 'warning');
    flash('success', 'Demande ' . e($ref) . ' soumise. Elle est en attente de validation hiérarchique.');
    unset($_SESSION['old']); redirect(res_link($id));
}

// ================================================================== 3. Validation hiérarchique
if ($A === 'decide' && is_post()) {
    require_perm('reservations.validate'); $id = (int)post('id');
    db()->beginTransaction();
    $r = res_lock($id);
    if (!$r) { db()->rollBack(); http_response_code(404); exit('Demande introuvable ou hors de votre périmètre.'); }
    $dec = post('decision'); $com = post('commentaire');
    if ($r['statut'] !== 'En attente') { db()->rollBack(); fail_back($id, ['Cette demande a déjà été traitée (statut : ' . $r['statut'] . ').']); }
    if (!in_array($dec, ['valider', 'rejeter'], true)) { db()->rollBack(); fail_back($id, ['Décision invalide.']); }
    if ($dec === 'rejeter' && mb_strlen($com) < 5) { db()->rollBack(); fail_back($id, ['Un commentaire est obligatoire pour motiver un rejet.']); }
    $new = $dec === 'valider' ? 'Validée' : 'Rejetée';
    q('UPDATE reservations SET statut=?, validateur_id=?, date_decision=NOW(), commentaire_decision=? WHERE id=?', [$new, uid(), $com ?: null, $id]);
    histo($id, 'En attente', $new, $com ?: null); db()->commit();
    audit('reservation.' . ($dec === 'valider' ? 'validation' : 'rejet'), 'reservations', $id, ['statut' => 'En attente'], ['statut' => $new, 'commentaire' => $com]);
    notify([(int)$r['demandeur_id']], 'Demande ' . mb_strtolower($new), $r['reference'] . ($com ? ' — ' . $com : ''), res_link($id), $dec === 'valider' ? 'success' : 'danger');
    if ($dec === 'valider') { notify(users_by_role('gestionnaire'), 'Demande validée à attribuer', $r['reference'] . ' — ' . $r['destination'], res_link($id), 'info'); }
    flash('success', 'Demande ' . e($r['reference']) . ' ' . mb_strtolower($new) . '.'); redirect(res_link($id));
}

// ================================================================== 4. Attribution définitive
if ($A === 'assign' && is_post()) {
    require_perm('reservations.assign'); $id = (int)post('id'); $vid = post_int('vehicule_id'); $cid = post_int('chauffeur_id');
    if (post('confirm') !== '1') { fail_back($id, ['Veuillez cocher la confirmation d\'attribution après consultation de l\'ordre de mission.']); }
    if (!$vid || !$cid) { fail_back($id, ['Sélectionnez un véhicule et un chauffeur.']); }
    try {
        db()->beginTransaction();
        $r = res_lock($id);
        if (!$r) { throw new RuntimeException('Demande introuvable.'); }
        if (!in_array($r['statut'], ['Validée', 'Attribuée'], true)) { throw new RuntimeException('Seules les demandes validées peuvent être attribuées (statut actuel : ' . $r['statut'] . ').'); }
        // Verrous pessimistes : sérialisent les attributions concurrentes sur le même véhicule / chauffeur
        if (!row('SELECT id FROM vehicules WHERE id=? AND ministere_id=? FOR UPDATE', [$vid, mid()])) { throw new RuntimeException('Véhicule introuvable.'); }
        if (!row('SELECT id FROM chauffeurs WHERE id=? AND ministere_id=? FOR UPDATE', [$cid, mid()])) { throw new RuntimeException('Chauffeur introuvable.'); }
        $vc = vehicule_check($vid, $r['date_depart'], $r['date_retour'], $id); $cc = chauffeur_check($cid, $r['date_depart'], $r['date_retour'], $id);
        $errs = array_merge(array_map(fn($x) => 'Véhicule : ' . $x, $vc['errors']), array_map(fn($x) => 'Chauffeur : ' . $x, $cc['errors']));
        if ($errs) { throw new RuntimeException(implode("\n", $errs)); }
        q("UPDATE reservations SET statut='Attribuée', vehicule_id=?, chauffeur_id=?, attribue_par=?, date_attribution=NOW() WHERE id=?", [$vid, $cid, uid(), $id]);
        histo($id, $r['statut'], 'Attribuée', 'Véhicule et chauffeur attribués.'); db()->commit();
    } catch (RuntimeException $e) { if (db()->inTransaction()) { db()->rollBack(); } fail_back($id, explode("\n", $e->getMessage())); }
    catch (Throwable $e) { if (db()->inTransaction()) { db()->rollBack(); } throw $e; }
    audit('reservation.attribution', 'reservations', $id, ['vehicule_id' => $r['vehicule_id'], 'chauffeur_id' => $r['chauffeur_id'], 'statut' => $r['statut']], ['vehicule_id' => $vid, 'chauffeur_id' => $cid, 'statut' => 'Attribuée']);
    notify([(int)$r['demandeur_id']], 'Véhicule attribué', $r['reference'] . ' — mission du ' . fmt_dt($r['date_depart']), res_link($id), 'success');
    flash('success', 'Véhicule et chauffeur attribués à la mission ' . e($r['reference']) . '.'); redirect(res_link($id));
}

// ================================================================== 5. Exécution
if ($A === 'start' && is_post()) {
    require_perm('reservations.execute'); $id = (int)post('id'); $km = post_int('km_depart');
    try {
        db()->beginTransaction();
        $r = res_lock($id); if (!$r) { throw new RuntimeException('Demande introuvable.'); }
        if ($r['statut'] !== 'Attribuée') { throw new RuntimeException('Seule une mission attribuée peut être démarrée.'); }
        $v = row('SELECT * FROM vehicules WHERE id=? FOR UPDATE', [$r['vehicule_id']]);
        if ($km === null) { throw new RuntimeException('Le kilométrage de départ est obligatoire.'); }
        if ($km < (int)$v['kilometrage']) { throw new RuntimeException('Le kilométrage de départ (' . nb($km) . ') est inférieur au compteur enregistré (' . nb($v['kilometrage']) . ' km).'); }
        if (in_array($v['etat'], ['En maintenance', 'Immobilisé', 'Réformé', 'En mission'], true) || $v['est_archive']) { throw new RuntimeException('Démarrage impossible : le véhicule est « ' . $v['etat'] . ' ».'); }
        if (val("SELECT COUNT(*) FROM reservations WHERE chauffeur_id=? AND statut='En cours' AND id<>?", [$r['chauffeur_id'], $id])) { throw new RuntimeException('Le chauffeur est déjà en mission.'); }
        $ch = row('SELECT * FROM chauffeurs WHERE id=?', [$r['chauffeur_id']]);
        if (!$ch['actif'] || $ch['date_expiration'] < date('Y-m-d')) { throw new RuntimeException('Le chauffeur est inactif ou son permis est expiré.'); }
        $strict = (int)param('blocage_obligations_expirees', 1) === 1; $a = last_assurance((int)$v['id']); $t = last_visite((int)$v['id']);
        if ($strict && (($a && $a['date_expiration'] < date('Y-m-d')) || ($t && $t['date_prochaine'] < date('Y-m-d')))) { throw new RuntimeException('Démarrage bloqué : assurance ou visite technique expirée.'); }
        q("UPDATE reservations SET statut='En cours', km_depart=?, date_debut_reelle=NOW() WHERE id=?", [$km, $id]);
        q('UPDATE vehicules SET kilometrage=?, etat=\'En mission\' WHERE id=?', [$km, $v['id']]);
        histo($id, 'Attribuée', 'En cours', 'Départ enregistré — ' . nb($km) . ' km.'); db()->commit();
    } catch (RuntimeException $e) { if (db()->inTransaction()) { db()->rollBack(); } fail_back($id, [$e->getMessage()]); }
    catch (Throwable $e) { if (db()->inTransaction()) { db()->rollBack(); } throw $e; }
    audit('mission.demarrage', 'reservations', $id, ['statut' => 'Attribuée'], ['statut' => 'En cours', 'km_depart' => $km]);
    notify([(int)$r['demandeur_id']], 'Mission démarrée', $r['reference'] . ' — départ enregistré.', res_link($id), 'info');
    flash('success', 'Mission démarrée.'); redirect(res_link($id));
}
if ($A === 'close' && is_post()) {
    require_perm('reservations.execute'); $id = (int)post('id'); $km = post_int('km_retour'); $obs = post('observations_execution');
    try {
        db()->beginTransaction();
        $r = res_lock($id); if (!$r) { throw new RuntimeException('Demande introuvable.'); }
        if ($r['statut'] !== 'En cours') { throw new RuntimeException('Seule une mission en cours peut être clôturée.'); }
        if ($km === null || $km < (int)$r['km_depart']) { throw new RuntimeException('Le kilométrage de retour doit être renseigné et supérieur ou égal au kilométrage de départ (' . nb($r['km_depart']) . ' km).'); }
        row('SELECT id FROM vehicules WHERE id=? FOR UPDATE', [$r['vehicule_id']]);
        q("UPDATE reservations SET statut='Terminée', km_retour=?, date_fin_reelle=NOW(), observations_execution=? WHERE id=?", [$km, $obs ?: null, $id]);
        q('UPDATE vehicules SET kilometrage=GREATEST(kilometrage,?) WHERE id=?', [$km, $r['vehicule_id']]);
        sync_vehicule_etat((int)$r['vehicule_id']);
        histo($id, 'En cours', 'Terminée', 'Retour enregistré — ' . nb($km - $r['km_depart']) . ' km parcourus.' . ($obs ? ' ' . $obs : '')); db()->commit();
    } catch (RuntimeException $e) { if (db()->inTransaction()) { db()->rollBack(); } fail_back($id, [$e->getMessage()]); }
    catch (Throwable $e) { if (db()->inTransaction()) { db()->rollBack(); } throw $e; }
    audit('mission.cloture', 'reservations', $id, ['statut' => 'En cours'], ['statut' => 'Terminée', 'km_retour' => $km, 'km_parcourus' => $km - $r['km_depart'], 'observations' => $obs]);
    notify([(int)$r['demandeur_id']], 'Mission terminée', $r['reference'] . ' — ' . nb($km - $r['km_depart']) . ' km parcourus.', res_link($id), 'success');
    flash('success', 'Mission clôturée (' . nb($km - $r['km_depart']) . ' km parcourus).'); redirect(res_link($id));
}

// ================================================================== Formulaire de demande
if ($A === 'new') {
    require_perm('reservations.create');
    $o = array_merge(['motif' => '', 'destination' => '', 'date_depart' => '', 'date_retour' => '', 'vehicule_souhaite_id' => '', 'observations' => ''], $_SESSION['old'] ?? []); unset($_SESSION['old']);
    page_start('Nouvelle demande de réservation');
    echo '<form method="post" enctype="multipart/form-data" action="' . e(url('reservations', 'create')) . '">' . csrf_field() . '<div class="grid gap-6 lg:grid-cols-3"><div class="space-y-6 lg:col-span-2">';
    card_start('Étape 1 — Informations de la mission'); echo '<div class="grid gap-4 p-5 sm:grid-cols-2">' . f_input('Motif de la mission', 'motif', $o['motif'], ['required' => 1, 'col' => 'sm:col-span-2', 'maxlength' => 255]) . f_input('Destination', 'destination', $o['destination'], ['required' => 1, 'col' => 'sm:col-span-2', 'maxlength' => 255])
        . f_input('Date et heure de départ', 'date_depart', $o['date_depart'], ['type' => 'datetime-local', 'required' => 1, 'id' => 'f-depart', 'min' => date('Y-m-d\T00:00')]) . f_input('Date et heure de retour', 'date_retour', $o['date_retour'], ['type' => 'datetime-local', 'required' => 1, 'id' => 'f-retour'])
        . f_select('Véhicule souhaité (facultatif)', 'vehicule_souhaite_id', [], $o['vehicule_souhaite_id'], ['empty' => '— Aucune préférence —', 'id' => 'f-vehicule', 'col' => 'sm:col-span-2', 'help' => 'La liste est filtrée selon la disponibilité réelle sur la période choisie.'])
        . f_textarea('Observations', 'observations', $o['observations'], ['col' => 'sm:col-span-2']) . '</div>'; card_end();
    card_start('Étape 2 — Ordre de mission signé (obligatoire)'); echo '<div class="space-y-2 p-5"><input type="file" name="ordre_mission" accept="application/pdf,.pdf" required class="block w-full"><p class="text-xs text-slate-500">PDF uniquement — ' . (int)param('upload_max_mb', 10) . ' Mo maximum. Le fichier est contrôlé (type réel), renommé aléatoirement et stocké hors accès public.</p></div>'; card_end();
    echo '</div><div class="space-y-6">'; card_start('Disponibilités sur la période'); echo '<div id="dispo-box" class="p-5"></div>'; card_end();
    card_start('Circuit de validation'); echo '<ol class="space-y-3 p-5 text-sm text-slate-600"><li><b>1.</b> Soumission avec ordre de mission PDF</li><li><b>2.</b> Validation par votre responsable hiérarchique</li><li><b>3.</b> Attribution du véhicule et du chauffeur par le Parc Automobile</li><li><b>4.</b> Exécution et clôture de la mission</li></ol>'; card_end();
    echo '</div></div><div class="mt-6 flex justify-end gap-2">' . link_btn(url('reservations'), 'Annuler') . btn('<i class="fa-solid fa-paper-plane"></i> Soumettre la demande') . '</div></form>';
    page_end(); exit;
}

// ================================================================== Fiche détaillée
if ($A === 'show') {
    $r = get_reservation((int)qget('id'));
    if (!$r) { http_response_code(404); page_start('Introuvable'); echo empty_state('Demande introuvable ou hors de votre périmètre.'); page_end(); exit; }
    $id = (int)$r['id']; $st = $r['statut'];
    page_start('Demande ' . $r['reference'], ['actions' => link_btn(url('reservations'), '<i class="fa-solid fa-arrow-left"></i> Retour à la liste')]);
    echo '<div class="mb-5">' . ''; 
    $steps = ['En attente', 'Validée', 'Attribuée', 'En cours', 'Terminée']; $idx = array_search($st, $steps, true);
    echo '<ol class="flex flex-wrap items-center gap-2 text-xs font-semibold">';
    foreach ($steps as $i => $s) { $done = $st !== 'Rejetée' && $idx !== false && $i <= $idx; echo '<li class="flex items-center gap-2 rounded-full px-3 py-1.5 ' . ($done ? 'bg-brand text-white' : 'bg-slate-100 text-slate-500') . '">' . ($done ? '<i class="fa-solid fa-check"></i>' : '') . e($s) . '</li>' . ($i < 4 ? '<i class="fa-solid fa-chevron-right text-[10px] text-slate-300"></i>' : ''); }
    if ($st === 'Rejetée') { echo '<li class="ml-2 rounded-full bg-red-600 px-3 py-1.5 text-white"><i class="fa-solid fa-xmark mr-1"></i>Rejetée</li>'; }
    echo '</ol></div><div class="grid gap-6 lg:grid-cols-3"><div class="space-y-6 lg:col-span-2">';
    card_start('Détails de la mission', badge($st)); echo '<dl class="grid gap-x-6 gap-y-3 p-5 text-sm sm:grid-cols-2">';
    foreach ([['Demandeur', $r['dem_prenoms'] . ' ' . $r['dem_nom'] . ($r['dem_fonction'] ? ' — ' . $r['dem_fonction'] : '')], ['Service', $r['service_nom'] ?: '—'], ['Motif', $r['motif']], ['Destination', $r['destination']], ['Départ prévu', fmt_dt($r['date_depart'])], ['Retour prévu', fmt_dt($r['date_retour'])],
        ['Véhicule souhaité', $r['vs_marque'] ? $r['vs_marque'] . ' ' . $r['vs_modele'] . ' (' . $r['vs_immat'] . ')' : '—'], ['Soumise le', fmt_dt($r['created_at'])]] as [$k, $v]) { echo '<div><dt class="text-xs text-slate-500">' . e($k) . '</dt><dd class="font-medium">' . e($v) . '</dd></div>'; }
    if ($r['observations']) { echo '<div class="sm:col-span-2"><dt class="text-xs text-slate-500">Observations</dt><dd>' . nl2br(e($r['observations'])) . '</dd></div>'; }
    echo '</dl>'; card_end();

    card_start('Ordre de mission signé (PDF)', '<a class="text-sm font-semibold text-brand hover:underline" target="_blank" rel="noopener" href="' . e(url('documents', 'ordre', ['id' => $id])) . '"><i class="fa-solid fa-up-right-from-square"></i> Ouvrir</a><a class="text-sm font-semibold text-brand hover:underline" href="' . e(url('documents', 'ordre', ['id' => $id, 'dl' => 1])) . '"><i class="fa-solid fa-download"></i> Télécharger</a>');
    echo '<div class="p-4"><div class="mb-2 text-xs text-slate-500"><i class="fa-regular fa-file-pdf text-red-600"></i> ' . e($r['ordre_mission_nom']) . '</div><iframe src="' . e(url('documents', 'ordre', ['id' => $id])) . '" class="h-[28rem] w-full rounded-lg border border-slate-200" title="Ordre de mission"></iframe></div>'; card_end();

    if ($r['date_decision']) {
        card_start('Décision hiérarchique'); echo '<div class="p-5 text-sm"><div class="flex flex-wrap items-center gap-2">' . badge($st === 'Rejetée' ? 'Rejetée' : 'Validée') . '<span>par <b>' . e(trim(($r['val_prenoms'] ?? '') . ' ' . ($r['val_nom'] ?? ''))) . '</b> le ' . fmt_dt($r['date_decision']) . '</span></div>' . ($r['commentaire_decision'] ? '<p class="mt-2 rounded-lg bg-slate-50 p-3 text-slate-700">« ' . e($r['commentaire_decision']) . ' »</p>' : '') . '</div>'; card_end();
    }

    // --- Actions de workflow selon profil et statut
    if ($st === 'En attente' && can('reservations.validate')) {
        card_start('Décision de validation', '', 'border-amber-300'); echo '<form method="post" action="' . e(url('reservations', 'decide')) . '" class="space-y-3 p-5" id="decide-form">' . csrf_field() . '<input type="hidden" name="id" value="' . $id . '">'
            . f_textarea('Commentaire de validation', 'commentaire', '', ['help' => 'Obligatoire en cas de rejet.', 'maxlength' => 1000]) . '<div class="flex flex-wrap gap-2">'
            . '<button name="decision" value="valider" class="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark"><i class="fa-solid fa-circle-check mr-1"></i>Valider la demande</button>'
            . '<button name="decision" value="rejeter" class="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700"><i class="fa-solid fa-circle-xmark mr-1"></i>Rejeter</button></div></form>'; card_end();
    }
    if (in_array($st, ['Validée', 'Attribuée'], true) && can('reservations.assign')) {
        $dis = disponibles($r['date_depart'], $r['date_retour'], $id);
        card_start($st === 'Validée' ? 'Étape 4 — Attribution définitive' : 'Modifier l\'attribution', '', 'border-sky-300');
        echo '<form method="post" action="' . e(url('reservations', 'assign')) . '" class="space-y-4 p-5">' . csrf_field() . '<input type="hidden" name="id" value="' . $id . '"><p class="text-sm text-slate-600">Seuls les véhicules et chauffeurs réellement disponibles du <b>' . fmt_dt($r['date_depart']) . '</b> au <b>' . fmt_dt($r['date_retour']) . '</b> sont proposés (état, missions futures, maintenances, assurance, visite technique, permis).</p><div class="grid gap-4 sm:grid-cols-2">';
        $vo = []; foreach ($dis['vehicules'] as $v) { $vo[$v['id']] = $v['marque'] . ' ' . $v['modele'] . ' — ' . $v['immatriculation'] . ' (' . nb($v['kilometrage']) . ' km)' . ($v['warnings'] ? ' ⚠' : ''); }
        $co = []; foreach ($dis['chauffeurs'] as $c) { $co[$c['id']] = $c['nom'] . ' ' . $c['prenoms'] . ' — permis ' . $c['categorie_permis']; }
        echo f_select('Véhicule', 'vehicule_id', $vo, $r['vehicule_id'] ?? ($r['vehicule_souhaite_id'] && isset($vo[$r['vehicule_souhaite_id']]) ? $r['vehicule_souhaite_id'] : ''), ['required' => 1, 'empty' => $vo ? '— Choisir —' : '— Aucun véhicule disponible —']) . f_select('Chauffeur', 'chauffeur_id', $co, $r['chauffeur_id'] ?? '', ['required' => 1, 'empty' => $co ? '— Choisir —' : '— Aucun chauffeur disponible —']) . '</div>';
        $warn = array_unique(array_merge(...array_map(fn($v) => $v['warnings'], $dis['vehicules']) ?: [[]]));
        if ($warn) { echo '<div class="rounded-lg bg-amber-50 p-3 text-xs text-amber-900"><i class="fa-solid fa-triangle-exclamation mr-1"></i>' . e(implode(' — ', array_slice($warn, 0, 3))) . '</div>'; }
        echo '<label class="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" value="1" class="mt-0.5 rounded border-slate-300 text-brand" required> J\'ai consulté l\'ordre de mission et je confirme cette attribution.</label>' . btn('<i class="fa-solid fa-link"></i> Confirmer l\'attribution', 'primary') . '</form>'; card_end();
    }
    if ($st === 'Attribuée' && can('reservations.execute')) {
        card_start('Étape 5 — Démarrer la mission', '', 'border-emerald-300'); echo '<form method="post" action="' . e(url('reservations', 'start')) . '" class="flex flex-wrap items-end gap-3 p-5" data-confirm="Démarrer la mission ' . e($r['reference']) . ' ? Le véhicule passera à l\'état « En mission ».">' . csrf_field() . '<input type="hidden" name="id" value="' . $id . '">'
            . f_input('Kilométrage de départ', 'km_depart', $r['veh_km'], ['type' => 'number', 'min' => (int)$r['veh_km'], 'required' => 1, 'col' => 'w-56']) . btn('<i class="fa-solid fa-play"></i> Démarrer') . '</form>'; card_end();
    }
    if ($st === 'En cours' && can('reservations.execute')) {
        card_start('Étape 5 — Clôturer la mission', '', 'border-emerald-300'); echo '<form method="post" action="' . e(url('reservations', 'close')) . '" class="space-y-3 p-5" data-confirm="Clôturer la mission ' . e($r['reference']) . ' ? Le véhicule redeviendra disponible.">' . csrf_field() . '<input type="hidden" name="id" value="' . $id . '"><div class="grid gap-4 sm:grid-cols-2">'
            . f_input('Kilométrage de retour', 'km_retour', '', ['type' => 'number', 'min' => (int)$r['km_depart'], 'required' => 1, 'help' => 'Départ : ' . nb($r['km_depart']) . ' km']) . f_textarea('Observations de fin de mission', 'observations_execution', '', ['rows' => 2]) . '</div>' . btn('<i class="fa-solid fa-flag-checkered"></i> Clôturer la mission') . '</form>'; card_end();
    }
    echo '</div><div class="space-y-6">';
    card_start('Attribution et exécution'); echo '<dl class="space-y-3 p-5 text-sm">';
    foreach ([['Véhicule', $r['marque'] ? $r['marque'] . ' ' . $r['modele'] . ' (' . $r['immatriculation'] . ')' : 'Non attribué'], ['Chauffeur', $r['ch_nom'] ? $r['ch_prenoms'] . ' ' . $r['ch_nom'] . ' — ' . $r['ch_tel'] : 'Non attribué'], ['Attribuée le', fmt_dt($r['date_attribution'])], ['Départ réel', $r['date_debut_reelle'] ? fmt_dt($r['date_debut_reelle']) . ' — ' . nb($r['km_depart']) . ' km' : '—'], ['Retour réel', $r['date_fin_reelle'] ? fmt_dt($r['date_fin_reelle']) . ' — ' . nb($r['km_retour']) . ' km' : '—'], ['Distance parcourue', $r['km_retour'] !== null ? nb($r['km_retour'] - $r['km_depart']) . ' km' : '—']] as [$k, $v]) { echo '<div><dt class="text-xs text-slate-500">' . e($k) . '</dt><dd class="font-medium">' . e($v) . '</dd></div>'; }
    if ($r['observations_execution']) { echo '<div><dt class="text-xs text-slate-500">Observations de fin de mission</dt><dd>' . nl2br(e($r['observations_execution'])) . '</dd></div>'; }
    echo '</dl>'; card_end();
    $h = rows('SELECT h.*, CONCAT(u.prenoms," ",u.nom) auteur FROM historiques_reservations h LEFT JOIN users u ON u.id=h.user_id WHERE h.reservation_id=? ORDER BY h.id', [$id]);
    card_start('Historique du dossier'); echo '<ol class="relative space-y-4 p-5 text-sm before:absolute before:bottom-6 before:left-[1.65rem] before:top-6 before:w-px before:bg-slate-200">';
    foreach ($h as $x) { echo '<li class="relative flex gap-3"><span class="relative z-10 mt-1 h-3 w-3 shrink-0 rounded-full bg-brand ring-4 ring-white"></span><div><div>' . ($x['ancien_statut'] ? e($x['ancien_statut']) . ' → ' : '') . '<b>' . e($x['nouveau_statut']) . '</b></div><div class="text-xs text-slate-500">' . fmt_dt($x['created_at']) . ' · ' . e($x['auteur'] ?? 'Système') . '</div>' . ($x['commentaire'] ? '<div class="mt-0.5 text-xs text-slate-600">' . e($x['commentaire']) . '</div>' : '') . '</div></li>'; }
    echo '</ol>'; card_end(); echo '</div></div>'; page_end(); exit;
}

// ================================================================== Liste
[$sc, $sp] = reservation_scope();
$w = [$sc]; $p = $sp;
if (($q = qget('q')) !== '') { $w[] = '(r.reference LIKE ? OR r.destination LIKE ? OR r.motif LIKE ? OR d.nom LIKE ? OR d.prenoms LIKE ?)'; array_push($p, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%"); }
if (in_array(qget('statut'), RES_STATUTS, true)) { $w[] = 'r.statut=?'; $p[] = qget('statut'); }
if (valid_date(qget('du'))) { $w[] = 'r.date_depart >= ?'; $p[] = qget('du') . ' 00:00:00'; }
if (valid_date(qget('au'))) { $w[] = 'r.date_depart <= ?'; $p[] = qget('au') . ' 23:59:59'; }
$from = 'reservations r JOIN users d ON d.id=r.demandeur_id LEFT JOIN vehicules v ON v.id=r.vehicule_id WHERE ' . implode(' AND ', $w);
$pg = paginate("r.*, d.nom AS dem_nom, d.prenoms AS dem_prenoms, v.marque, v.modele, v.immatriculation", $from, $p, ['ref' => 'r.id', 'dem' => 'd.nom', 'dest' => 'r.destination', 'depart' => 'r.date_depart', 'statut' => 'r.statut'], 'depart', 'desc');
$titles = ['agent' => 'Mes demandes de réservation', 'validateur' => 'Demandes de mon périmètre', 'gestionnaire' => 'Réservations et ordres de mission', 'superadmin' => 'Réservations et ordres de mission'];
page_start($titles[role()] ?? 'Réservations', ['actions' => can('reservations.create') ? link_btn(url('reservations', 'new'), '<i class="fa-solid fa-plus"></i> Nouvelle demande', 'primary') : '']);
$cnt = array_column(rows("SELECT r.statut, COUNT(*) n FROM reservations r JOIN users d ON d.id=r.demandeur_id WHERE $sc GROUP BY r.statut", $sp), 'n', 'statut');
echo '<div class="mb-5 grid grid-cols-2 gap-3 md:grid-cols-6">';
foreach (RES_STATUTS as $s) { echo '<a href="' . e(qs(['statut' => $s, 'page' => 1])) . '" class="rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm hover:border-brand/40"><div class="text-2xl font-extrabold">' . (int)($cnt[$s] ?? 0) . '</div><div class="mt-0.5">' . badge($s) . '</div></a>'; }
echo '</div>'; card_start(); echo search_bar(['statut' => [array_combine(RES_STATUTS, RES_STATUTS), 'Tous les statuts']], 'Référence, destination, motif, demandeur…');
if (!$pg['rows']) { echo empty_state('Aucune demande ne correspond.', 'fa-file-circle-xmark'); } else {
    echo tbl_start() . th_sort('Référence', 'ref', $pg) . th_sort('Demandeur', 'dem', $pg) . th_sort('Destination', 'dest', $pg) . th_sort('Départ', 'depart', $pg) . th('Véhicule') . th_sort('Statut', 'statut', $pg) . th('') . tbl_mid();
    foreach ($pg['rows'] as $r) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 font-semibold text-brand">' . e($r['reference']) . '</td><td class="px-4 py-3">' . e($r['dem_prenoms'] . ' ' . $r['dem_nom']) . '</td><td class="px-4 py-3">' . e($r['destination']) . '<div class="max-w-xs truncate text-xs text-slate-500">' . e($r['motif']) . '</div></td><td class="px-4 py-3 whitespace-nowrap">' . fmt_dt($r['date_depart']) . '</td><td class="px-4 py-3">' . ($r['marque'] ? e($r['marque'] . ' ' . $r['modele']) . '<div class="font-mono text-xs text-slate-500">' . e($r['immatriculation']) . '</div>' : '<span class="text-slate-400">—</span>') . '</td><td class="px-4 py-3">' . badge($r['statut']) . '</td><td class="px-4 py-3 text-right"><a class="font-semibold text-brand hover:underline" href="' . e(res_link((int)$r['id'])) . '">Ouvrir</a></td></tr>'; }
    echo tbl_end();
}
echo pager($pg); card_end(); page_end();
