<?php
declare(strict_types=1);

$m = mid(); $role = role(); $u = user();
$mgr = in_array($role, ['gestionnaire', 'superadmin'], true);
$months = []; for ($i = 11; $i >= 0; $i--) { $t = strtotime(date('Y-m-01') . " -$i months"); $months[date('Y-m', $t)] = mois_court((int)date('n', $t)) . ' ' . date('y', $t); }
$since = array_key_first($months) . '-01';
$series = function (array $rowsData, string $valKey) use ($months): array { $map = array_column($rowsData, $valKey, 'ym'); return array_map(fn($k) => (float)($map[$k] ?? 0), array_keys($months)); };

page_start('Tableau de bord', ['actions' => can('reservations.create') ? link_btn(url('reservations', 'new'), '<i class="fa-solid fa-plus"></i> Nouvelle demande', 'primary') : '']);
echo '<div class="mb-6 overflow-hidden rounded-xl bg-brand-deep text-white"><div class="flex flex-wrap items-center justify-between gap-3 px-6 py-5"><div><div class="text-xs font-medium text-green-100/70">' . e(date('d/m/Y')) . ' · ' . e(ministere()['nom']) . '</div><div class="mt-1 text-xl font-extrabold tracking-tight">Bonjour ' . e($u['prenoms']) . '</div><div class="text-sm text-green-100/80">' . e(ROLE_INFO[$role][0]) . ' — ' . e(ROLE_INFO[$role][1]) . '</div></div><i class="fa-solid fa-car-on text-5xl text-white/10"></i></div>' . tricolor('h-1') . '</div>';

if ($mgr) {
    $veh = array_column(rows('SELECT etat, COUNT(*) n FROM vehicules WHERE ministere_id=? AND est_archive=0 GROUP BY etat', [$m]), 'n', 'etat');
    $totV = array_sum($veh); $mo = date('Y-m-01');
    $missMois = (int)val("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut IN ('Attribuée','En cours','Terminée') AND date_depart >= ? AND date_depart < DATE_ADD(?, INTERVAL 1 MONTH)", [$m, $mo, $mo]);
    $att = (int)val("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut='En attente'", [$m]); $val = (int)val("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut='Validée'", [$m]);
    $ter = (int)val("SELECT COUNT(*) FROM reservations WHERE ministere_id=? AND statut='Terminée' AND date_depart >= ? AND date_depart < DATE_ADD(?, INTERVAL 1 MONTH)", [$m, $mo, $mo]);
    $dep = (float)val('SELECT COALESCE(SUM(montant),0) FROM depenses WHERE ministere_id=? AND date_depense >= ? AND date_depense < DATE_ADD(?, INTERVAL 1 MONTH)', [$m, $mo, $mo]);
    echo '<div class="mb-6 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">'
        . stat_card('Total véhicules', (string)$totV, 'fa-car', 'brand', url('vehicules')) . stat_card('Disponibles', (string)(int)($veh['Disponible'] ?? 0), 'fa-circle-check', 'brand', url('vehicules', null, ['etat' => 'Disponible']))
        . stat_card('En mission', (string)(int)($veh['En mission'] ?? 0), 'fa-route', 'sky', url('vehicules', null, ['etat' => 'En mission'])) . stat_card('En maintenance', (string)(int)($veh['En maintenance'] ?? 0), 'fa-wrench', 'amber', url('vehicules', null, ['etat' => 'En maintenance']))
        . stat_card('Immobilisés', (string)(int)($veh['Immobilisé'] ?? 0), 'fa-ban', 'red', url('vehicules', null, ['etat' => 'Immobilisé'])) . stat_card('Missions du mois', (string)$missMois, 'fa-calendar-check', 'sky', url('reservations'))
        . stat_card('Demandes en attente', (string)$att, 'fa-hourglass-half', 'amber', url('reservations', null, ['statut' => 'En attente'])) . stat_card('Demandes validées', (string)$val, 'fa-file-circle-check', 'brand', url('reservations', null, ['statut' => 'Validée']))
        . stat_card('Missions terminées (mois)', (string)$ter, 'fa-flag-checkered', 'slate', url('reservations', null, ['statut' => 'Terminée'])) . stat_card('Dépenses du mois', fcfa($dep), 'fa-coins', 'brand', url('depenses')) . '</div>';

    // Alertes et activité
    $al = array_values(array_filter(alerts(), fn($a) => $a[0] !== 'info')); usort($al, fn($a, $b) => ($a[0] === 'danger' ? 0 : 1) <=> ($b[0] === 'danger' ? 0 : 1));
    echo '<div class="mb-6 grid gap-6 lg:grid-cols-2">'; card_start('Alertes administratives', '<span class="rounded-full bg-red-50 px-2 py-0.5 text-xs font-semibold text-red-700">' . count($al) . '</span>');
    if (!$al) { echo '<div class="px-5 py-6 text-sm text-emerald-700"><i class="fa-solid fa-circle-check mr-1"></i> Aucune alerte : tout est à jour.</div>'; }
    else { echo '<ul class="max-h-80 divide-y divide-slate-100 overflow-y-auto">'; foreach (array_slice($al, 0, 12) as [$lvl, $msg, $link]) { echo '<li><a href="' . e($link) . '" class="flex gap-3 px-5 py-2.5 text-sm hover:bg-slate-50"><i class="fa-solid ' . ($lvl === 'danger' ? 'fa-circle-exclamation text-red-600' : 'fa-triangle-exclamation text-amber-500') . ' mt-0.5"></i><span>' . e($msg) . '</span></a></li>'; } echo '</ul>' . (count($al) > 12 ? '<div class="px-5 py-2 text-xs text-slate-500">+ ' . (count($al) - 12) . ' autre(s) alerte(s)</div>' : ''); }
    card_end();
    $act = rows('SELECT h.*, r.reference, r.id rid, CONCAT(u.prenoms," ",u.nom) auteur FROM historiques_reservations h JOIN reservations r ON r.id=h.reservation_id LEFT JOIN users u ON u.id=h.user_id WHERE r.ministere_id=? ORDER BY h.id DESC LIMIT 8', [$m]);
    card_start('Activité récente', link_btn(url('reservations'), 'Voir tout')); echo '<ul class="divide-y divide-slate-100">';
    foreach ($act as $a) { echo '<li class="flex items-start gap-3 px-5 py-2.5 text-sm"><span class="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-brand"></span><div class="min-w-0 flex-1"><a class="font-semibold text-brand hover:underline" href="' . e(url('reservations', 'show', ['id' => $a['rid']])) . '">' . e($a['reference']) . '</a> ' . ($a['ancien_statut'] ? e($a['ancien_statut']) . ' → ' : '') . '<b>' . e($a['nouveau_statut']) . '</b><div class="text-xs text-slate-500">' . e($a['auteur'] ?? 'Système') . ' · ' . fmt_dt($a['created_at']) . '</div></div></li>'; }
    if (!$act) { echo '<li class="px-5 py-6 text-sm text-slate-500">Aucune activité.</li>'; } echo '</ul>'; card_end(); echo '</div>';

    // Données des graphiques
    $missM = $series(rows("SELECT DATE_FORMAT(date_depart,'%Y-%m') ym, COUNT(*) n FROM reservations WHERE ministere_id=? AND statut IN ('Attribuée','En cours','Terminée') AND date_depart >= ? GROUP BY ym", [$m, $since]), 'n');
    $depM = $series(rows("SELECT DATE_FORMAT(date_depense,'%Y-%m') ym, SUM(montant) s FROM depenses WHERE ministere_id=? AND date_depense >= ? GROUP BY ym", [$m, $since]), 's');
    $mntN = $series(rows("SELECT DATE_FORMAT(date_maintenance,'%Y-%m') ym, COUNT(*) n FROM maintenances WHERE ministere_id=? AND date_maintenance >= ? GROUP BY ym", [$m, $since]), 'n');
    $mntC = $series(rows("SELECT DATE_FORMAT(date_maintenance,'%Y-%m') ym, SUM(cout) s FROM maintenances WHERE ministere_id=? AND date_maintenance >= ? GROUP BY ym", [$m, $since]), 's');
    $mv = rows("SELECT CONCAT(v.marque,' ',v.immatriculation) l, COUNT(*) n FROM reservations r JOIN vehicules v ON v.id=r.vehicule_id WHERE r.ministere_id=? AND r.statut IN ('En cours','Terminée') GROUP BY v.id ORDER BY n DESC LIMIT 8", [$m]);
    $mc = rows("SELECT CONCAT(c.prenoms,' ',c.nom) l, COUNT(*) n FROM reservations r JOIN chauffeurs c ON c.id=r.chauffeur_id WHERE r.ministere_id=? AND r.statut IN ('En cours','Terminée') GROUP BY c.id ORDER BY n DESC LIMIT 8", [$m]);
    $dc = rows('SELECT categorie l, SUM(montant) n FROM depenses WHERE ministere_id=? AND date_depense >= ? GROUP BY categorie ORDER BY n DESC', [$m, $since]);
    $charts = [['c-etat', 'Répartition des véhicules par état'], ['c-miss', 'Évolution mensuelle des missions'], ['c-mveh', 'Missions par véhicule'], ['c-mch', 'Missions par chauffeur'], ['c-dep', 'Évolution des dépenses (12 mois)'], ['c-dcat', 'Dépenses par catégorie (12 mois)'], ['c-mnt', 'Évolution des maintenances']];
    echo '<div class="grid gap-6 md:grid-cols-2 xl:grid-cols-3">';
    foreach ($charts as $i => [$id, $t]) { card_start($t, '', $i === 1 || $i === 4 ? 'xl:col-span-1' : ''); echo '<div class="p-5"><div class="relative h-64"><canvas id="' . $id . '"></canvas></div></div>'; card_end(); }
    echo '</div><script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script><script>
    const L=' . json_encode(array_values($months), JSON_UNESCAPED_UNICODE) . ', G="#006828", Y="#FFBE00", R="#EB0000", S="#0369a1", GR="#64748b";
    const fm=v=>new Intl.NumberFormat("fr-FR").format(v), base={maintainAspectRatio:false,plugins:{legend:{position:"bottom",labels:{boxWidth:10,font:{size:11}}}}};
    const mk=(id,cfg)=>{const el=document.getElementById(id); if(el&&window.Chart) new Chart(el,cfg);};
    mk("c-etat",{type:"doughnut",data:{labels:["Disponible","En mission","En maintenance","Immobilisé","Réformé"],datasets:[{data:' . json_encode(array_map(fn($k) => (int)($veh[$k] ?? 0), ETATS)) . ',backgroundColor:[G,S,Y,R,GR]}]},options:{...base,cutout:"62%"}});
    mk("c-miss",{type:"bar",data:{labels:L,datasets:[{label:"Missions",data:' . json_encode($missM) . ',backgroundColor:G,borderRadius:4}]},options:{...base,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}});
    mk("c-mveh",{type:"bar",data:{labels:' . json_encode(array_column($mv, 'l'), JSON_UNESCAPED_UNICODE) . ',datasets:[{label:"Missions",data:' . json_encode(array_map('intval', array_column($mv, 'n'))) . ',backgroundColor:S,borderRadius:4}]},options:{...base,indexAxis:"y",plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,ticks:{precision:0}}}}});
    mk("c-mch",{type:"bar",data:{labels:' . json_encode(array_column($mc, 'l'), JSON_UNESCAPED_UNICODE) . ',datasets:[{label:"Missions",data:' . json_encode(array_map('intval', array_column($mc, 'n'))) . ',backgroundColor:Y,borderRadius:4}]},options:{...base,indexAxis:"y",plugins:{legend:{display:false}},scales:{x:{beginAtZero:true,ticks:{precision:0}}}}});
    mk("c-dep",{type:"line",data:{labels:L,datasets:[{label:"Dépenses (FCFA)",data:' . json_encode($depM) . ',borderColor:G,backgroundColor:"rgba(0,104,40,.12)",fill:true,tension:.3}]},options:{...base,plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>fm(c.parsed.y)+" FCFA"}}},scales:{y:{beginAtZero:true,ticks:{callback:v=>fm(v)}}}}});
    mk("c-dcat",{type:"doughnut",data:{labels:' . json_encode(array_column($dc, 'l'), JSON_UNESCAPED_UNICODE) . ',datasets:[{data:' . json_encode(array_map('floatval', array_column($dc, 'n'))) . ',backgroundColor:[G,Y,R,S,GR,"#16a34a","#a16207"]}]},options:{...base,cutout:"55%",plugins:{legend:{position:"bottom",labels:{boxWidth:10,font:{size:11}}},tooltip:{callbacks:{label:c=>c.label+" : "+fm(c.parsed)+" FCFA"}}}}});
    mk("c-mnt",{data:{labels:L,datasets:[{type:"bar",label:"Interventions",data:' . json_encode($mntN) . ',backgroundColor:Y,borderRadius:4,yAxisID:"y"},{type:"line",label:"Coût (FCFA)",data:' . json_encode($mntC) . ',borderColor:R,tension:.3,yAxisID:"y1"}]},options:{...base,scales:{y:{beginAtZero:true,ticks:{precision:0}},y1:{position:"right",beginAtZero:true,grid:{drawOnChartArea:false},ticks:{callback:v=>fm(v)}}}}});
    </script>';
} else {
    [$sc, $sp] = reservation_scope();
    $cnt = array_column(rows("SELECT r.statut, COUNT(*) n FROM reservations r JOIN users d ON d.id=r.demandeur_id WHERE $sc GROUP BY r.statut", $sp), 'n', 'statut');
    if ($role === 'agent') {
        $libres = (int)val("SELECT COUNT(*) FROM vehicules WHERE ministere_id=? AND est_archive=0 AND etat='Disponible'", [$m]);
        echo '<div class="mb-6 grid grid-cols-2 gap-3 md:grid-cols-5">' . stat_card('En attente de validation', (string)(int)($cnt['En attente'] ?? 0), 'fa-hourglass-half', 'amber', url('reservations', null, ['statut' => 'En attente'])) . stat_card('Validées', (string)(int)($cnt['Validée'] ?? 0), 'fa-file-circle-check', 'sky', url('reservations', null, ['statut' => 'Validée']))
            . stat_card('Attribuées / en cours', (string)((int)($cnt['Attribuée'] ?? 0) + (int)($cnt['En cours'] ?? 0)), 'fa-route', 'brand', url('reservations')) . stat_card('Terminées', (string)(int)($cnt['Terminée'] ?? 0), 'fa-flag-checkered', 'slate', url('reservations', null, ['statut' => 'Terminée'])) . stat_card('Véhicules disponibles', (string)$libres, 'fa-car', 'brand', url('vehicules', null, ['etat' => 'Disponible'])) . '</div>';
    } else {
        $dec = (int)val("SELECT COUNT(*) FROM reservations WHERE validateur_id=? AND date_decision >= ?", [uid(), date('Y-m-01')]);
        echo '<div class="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">' . stat_card('À valider', (string)(int)($cnt['En attente'] ?? 0), 'fa-hourglass-half', 'amber', url('reservations', null, ['statut' => 'En attente'])) . stat_card('Validées (périmètre)', (string)(int)($cnt['Validée'] ?? 0) , 'fa-file-circle-check', 'brand', url('reservations', null, ['statut' => 'Validée'])) . stat_card('Rejetées', (string)(int)($cnt['Rejetée'] ?? 0), 'fa-circle-xmark', 'red', url('reservations', null, ['statut' => 'Rejetée'])) . stat_card('Mes décisions ce mois', (string)$dec, 'fa-stamp', 'slate') . '</div>';
    }
    $list = rows("SELECT r.*, d.nom dem_nom, d.prenoms dem_prenoms FROM reservations r JOIN users d ON d.id=r.demandeur_id WHERE $sc " . ($role === 'validateur' ? "AND r.statut='En attente' " : "AND r.statut IN ('En attente','Validée','Attribuée','En cours') ") . 'ORDER BY r.date_depart LIMIT 8', $sp);
    card_start($role === 'validateur' ? 'Demandes en attente de ma décision' : 'Mes demandes en cours', link_btn(url('reservations'), 'Tout voir'));
    if (!$list) { echo empty_state($role === 'validateur' ? 'Aucune demande en attente.' : 'Aucune demande en cours. Créez une nouvelle demande de réservation.'); } else {
        echo tbl_start() . th('Référence') . th('Demandeur') . th('Destination') . th('Départ') . th('Statut') . th('') . tbl_mid();
        foreach ($list as $r) { echo '<tr class="hover:bg-slate-50"><td class="px-4 py-3 font-semibold text-brand">' . e($r['reference']) . '</td><td class="px-4 py-3">' . e($r['dem_prenoms'] . ' ' . $r['dem_nom']) . '</td><td class="px-4 py-3">' . e($r['destination']) . '</td><td class="px-4 py-3 whitespace-nowrap">' . fmt_dt($r['date_depart']) . '</td><td class="px-4 py-3">' . badge($r['statut']) . '</td><td class="px-4 py-3 text-right"><a class="font-semibold text-brand hover:underline" href="' . e(url('reservations', 'show', ['id' => $r['id']])) . '">Ouvrir</a></td></tr>'; }
        echo tbl_end();
    }
    card_end();
}
page_end();
