<?php
declare(strict_types=1);

function head_html(string $title): string
{
    return '<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . e($title) . ' — eFlotte Bénin</title>'
        . '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
        . '<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">'
        . '<script src="https://cdn.tailwindcss.com"></script>'
        . '<script>tailwind.config={theme:{extend:{colors:{brand:{DEFAULT:"#006828",dark:"#004d1e",deep:"#033a18",50:"#eef8f1",100:"#d6eedd"},accent:{DEFAULT:"#FFBE00"},danger:{DEFAULT:"#EB0000"}},fontFamily:{sans:["Plus Jakarta Sans","system-ui","Segoe UI","sans-serif"]}}}}</script>'
        . '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">'
        . '<link rel="stylesheet" href="' . e(ASSET_URL) . '/app.css?v=1">'
        . '<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 32 32%27%3E%3Crect width=%2711%27 height=%2732%27 fill=%27%23006828%27/%3E%3Crect x=%2711%27 width=%2711%27 height=%2732%27 fill=%27%23FFBE00%27/%3E%3Crect x=%2722%27 width=%2710%27 height=%2732%27 fill=%27%23EB0000%27/%3E%3C/svg%3E">'
        . '</head>';
}

function tricolor(string $h = 'h-1.5'): string { return '<div class="flex ' . $h . '"><span class="flex-1 bg-brand"></span><span class="flex-1 bg-accent"></span><span class="flex-1 bg-danger"></span></div>'; }

function nav_items(): array
{
    $r = role();
    $resLabel = ['agent' => 'Mes demandes', 'validateur' => 'Demandes à valider'][$r] ?? 'Réservations & missions';
    $items = [
        ['dashboard', 'Tableau de bord', 'fa-gauge-high', true],
        ['vehicules', 'Véhicules', 'fa-car-side', can('vehicules.view')],
        ['chauffeurs', 'Chauffeurs', 'fa-id-card', can('chauffeurs.view')],
        ['disponibilites', 'Disponibilités', 'fa-calendar-days', can('disponibilites.view')],
        ['reservations', $resLabel, 'fa-file-signature', true],
        ['maintenances', 'Maintenance', 'fa-screwdriver-wrench', can('maintenances.view')],
        ['depenses', 'Dépenses', 'fa-coins', can('depenses.view')],
        ['assurances', 'Assurances & visites', 'fa-shield-halved', can('assurances.view')],
        ['rapports', 'Rapports', 'fa-chart-pie', can('rapports.view')],
        ['audit', 'Journal d\'audit', 'fa-clipboard-list', can('audit.view')],
    ];
    $admin = [
        ['users', 'Utilisateurs', 'fa-users-gear', can('users.manage')],
        ['services', 'Services', 'fa-sitemap', can('users.manage')],
        ['parametres', 'Paramètres', 'fa-sliders', can('parametres.operationnel')],
        ['sauvegardes', 'Sauvegardes', 'fa-database', can('sauvegardes.manage')],
    ];
    return [$items, $admin];
}

function page_start(string $title, array $o = []): void
{
    $u = user(); $cur = $GLOBALS['P'] ?? '';
    echo head_html($title);
    echo '<body class="bg-slate-50 font-sans text-slate-800 antialiased"><div id="toasts" class="fixed right-4 top-4 z-[60] flex w-[min(92vw,26rem)] flex-col gap-2">';
    foreach (pull_flash() as $f) {
        $c = ['success' => 'border-emerald-500 text-emerald-900 bg-emerald-50', 'error' => 'border-red-500 text-red-900 bg-red-50', 'warning' => 'border-amber-500 text-amber-900 bg-amber-50', 'info' => 'border-sky-500 text-sky-900 bg-sky-50'][$f['t']] ?? 'border-slate-400 bg-white';
        $ic = ['success' => 'fa-circle-check', 'error' => 'fa-circle-xmark', 'warning' => 'fa-triangle-exclamation', 'info' => 'fa-circle-info'][$f['t']] ?? 'fa-circle-info';
        echo '<div class="toast rounded-lg border-l-4 px-4 py-3 text-sm shadow-lg ' . $c . '" role="alert"><div class="flex gap-3"><i class="fa-solid ' . $ic . ' mt-0.5"></i><div class="flex-1">' . $f['m'] . '</div><button type="button" class="toast-x opacity-60 hover:opacity-100" aria-label="Fermer">&times;</button></div></div>';
    }
    echo '</div>';
    if (!$u) { echo '<main class="min-h-screen">'; return; }
    [$main, $admin] = nav_items();
    $link = function ($it) use ($cur) {
        [$p, $label, $ic, $ok] = $it; if (!$ok) { return ''; }
        $on = $cur === $p;
        return '<a href="' . e(url($p)) . '" class="group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors ' . ($on ? 'bg-white/12 text-white shadow-[inset_3px_0_0_#FFBE00]' : 'text-green-50/80 hover:bg-white/8 hover:text-white') . '"><i class="fa-solid ' . $ic . ' w-5 text-center ' . ($on ? 'text-accent' : 'text-green-100/60 group-hover:text-accent') . '"></i><span>' . e($label) . '</span></a>';
    };
    $m = ministere(); $unread = unread_count();
    echo '<div id="overlay" class="fixed inset-0 z-30 hidden bg-black/40 lg:hidden"></div>';
    echo '<aside id="sidebar" class="fixed inset-y-0 left-0 z-40 flex w-64 -translate-x-full flex-col bg-brand-deep text-white transition-transform lg:translate-x-0">' . tricolor();
    echo '<div class="px-5 pb-3 pt-5"><div class="flex items-center gap-3"><div class="grid h-10 w-10 place-items-center rounded-xl bg-white/10"><i class="fa-solid fa-car-on text-accent text-lg"></i></div><div><div class="text-base font-extrabold leading-tight tracking-tight">eFlotte Bénin</div><div class="text-[11px] leading-tight text-green-100/70">' . e($m['sigle'] ?? '') . ' · Parc automobile</div></div></div></div>';
    echo '<nav class="flex-1 space-y-0.5 overflow-y-auto px-3 py-2">';
    foreach ($main as $it) { echo $link($it); }
    if (array_filter($admin, fn($i) => $i[3])) { echo '<div class="px-3 pb-1 pt-4 text-[11px] font-semibold text-green-100/50">Administration</div>'; foreach ($admin as $it) { echo $link($it); } }
    echo '</nav><div class="border-t border-white/10 px-5 py-3 text-[11px] leading-snug text-green-100/60">' . e($m['nom'] ?? '') . '<br>Instance dédiée — données isolées</div></aside>';
    echo '<div class="lg:pl-64"><header class="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur"><div class="flex h-14 items-center gap-3 px-4 lg:px-8">';
    echo '<button id="menu-btn" type="button" class="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>';
    echo '<h1 class="truncate text-base font-bold text-slate-900 lg:text-lg">' . e($title) . '</h1><div class="ml-auto flex items-center gap-1 sm:gap-3">';
    echo '<a href="' . e(url('notifications')) . '" class="relative rounded-lg p-2 text-slate-600 hover:bg-slate-100" aria-label="Notifications"><i class="fa-regular fa-bell text-lg"></i>' . ($unread ? '<span id="notif-count" class="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">' . min($unread, 99) . '</span>' : '') . '</a>';
    echo '<div class="relative"><button id="user-btn" type="button" class="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-slate-100"><span class="grid h-8 w-8 place-items-center rounded-full bg-brand text-xs font-bold text-white">' . e(mb_strtoupper(mb_substr($u['prenoms'], 0, 1) . mb_substr($u['nom'], 0, 1))) . '</span><span class="hidden text-left sm:block"><span class="block text-sm font-semibold leading-tight">' . e($u['prenoms'] . ' ' . $u['nom']) . '</span><span class="block text-[11px] leading-tight text-slate-500">' . e(ROLE_INFO[$u['role']][0] ?? $u['role_libelle']) . '</span></span><i class="fa-solid fa-chevron-down text-[10px] text-slate-400"></i></button>';
    echo '<div id="user-menu" class="absolute right-0 mt-1 hidden w-60 rounded-xl border border-slate-200 bg-white p-1.5 shadow-xl"><div class="px-3 py-2 text-xs text-slate-500">' . e($u['email']) . '<br>' . e($u['service_nom'] ?? '') . '</div><a class="block rounded-lg px-3 py-2 text-sm hover:bg-slate-50" href="' . e(url('auth', 'profil')) . '"><i class="fa-regular fa-user mr-2 text-slate-400"></i>Mon profil et mot de passe</a>';
    echo '<form method="post" action="' . e(url('auth', 'logout')) . '">' . csrf_field() . '<button class="w-full rounded-lg px-3 py-2 text-left text-sm text-red-700 hover:bg-red-50"><i class="fa-solid fa-arrow-right-from-bracket mr-2"></i>Déconnexion</button></form></div></div>';
    echo '</div></div>' . tricolor('h-0.5') . '</header><main class="px-4 py-6 lg:px-8">';
    if (!empty($o['actions'])) { echo '<div class="mb-5 flex flex-wrap items-center justify-end gap-2">' . $o['actions'] . '</div>'; }
}

function page_end(): void
{
    $u = user();
    echo '</main>';
    if ($u) { echo '<footer class="px-4 pb-6 text-center text-xs text-slate-400 lg:px-8">eFlotte Bénin — République du Bénin · ' . e(ministere()['nom'] ?? '') . '</footer></div>'; }
    echo '<div id="confirm-modal" class="fixed inset-0 z-[70] hidden items-center justify-center bg-black/50 p-4"><div class="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"><div class="flex items-start gap-3"><div class="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-amber-100 text-amber-700"><i class="fa-solid fa-triangle-exclamation"></i></div><div><h3 class="font-bold text-slate-900">Confirmer l\'opération</h3><p id="confirm-msg" class="mt-1 text-sm text-slate-600"></p></div></div><div class="mt-5 flex justify-end gap-2"><button id="confirm-no" type="button" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold hover:bg-slate-50">Annuler</button><button id="confirm-yes" type="button" class="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark">Confirmer</button></div></div></div>';
    echo '<script>window.EFLOTTE={base:' . json_encode(BASE_URL) . ',csrf:' . json_encode(csrf_token()) . '};</script><script src="' . e(ASSET_URL) . '/app.js?v=1"></script></body></html>';
}

function card_start(string $title = '', string $right = '', string $cls = ''): void
{
    echo '<section class="rounded-xl border border-slate-200 bg-white shadow-sm ' . $cls . '">';
    if ($title !== '' || $right !== '') { echo '<div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 px-5 py-3.5"><h2 class="text-sm font-bold text-slate-900">' . $title . '</h2><div class="flex items-center gap-2">' . $right . '</div></div>'; }
}
function card_end(): void { echo '</section>'; }
function stat_card(string $label, string $value, string $icon, string $tone = 'brand', ?string $href = null): string
{
    $t = ['brand' => 'bg-brand-50 text-brand', 'amber' => 'bg-amber-50 text-amber-700', 'red' => 'bg-red-50 text-red-700', 'sky' => 'bg-sky-50 text-sky-700', 'slate' => 'bg-slate-100 text-slate-600'][$tone];
    $in = '<div class="flex items-center gap-4"><div class="grid h-11 w-11 shrink-0 place-items-center rounded-xl ' . $t . '"><i class="fa-solid ' . $icon . '"></i></div><div class="min-w-0"><div class="text-2xl font-extrabold leading-none tracking-tight text-slate-900">' . $value . '</div><div class="mt-1 truncate text-xs font-medium text-slate-500">' . e($label) . '</div></div></div>';
    $c = 'block rounded-xl border border-slate-200 bg-white p-4 shadow-sm';
    return $href ? '<a href="' . e($href) . '" class="' . $c . ' transition hover:border-brand/40 hover:shadow">' . $in . '</a>' : '<div class="' . $c . '">' . $in . '</div>';
}
function empty_state(string $msg, string $icon = 'fa-folder-open'): string { return '<div class="px-6 py-12 text-center text-sm text-slate-500"><i class="fa-regular ' . $icon . ' mb-2 text-2xl text-slate-300"></i><div>' . e($msg) . '</div></div>'; }
function th(string $label, string $cls = ''): string { return '<th class="px-4 py-3 text-left font-semibold ' . $cls . '">' . e($label) . '</th>'; }
function tbl_start(): string { return '<div class="overflow-x-auto"><table class="w-full text-sm"><thead class="border-b border-slate-200 bg-slate-50 text-xs text-slate-600"><tr>'; }
function tbl_mid(): string { return '</tr></thead><tbody class="divide-y divide-slate-100">'; }
function tbl_end(): string { return '</tbody></table></div>'; }
function search_bar(array $filters = [], string $placeholder = 'Rechercher…'): string
{
    $h = '<form method="get" action="' . e(BASE_URL) . '" class="flex flex-wrap items-end gap-2 px-5 py-3"><input type="hidden" name="p" value="' . e($GLOBALS['P'] ?? '') . '">';
    if (isset($_GET['a'])) { $h .= '<input type="hidden" name="a" value="' . e(qget('a')) . '">'; }
    $h .= '<div class="relative min-w-[12rem] flex-1"><i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-400"></i><input type="search" name="q" value="' . e(qget('q')) . '" placeholder="' . e($placeholder) . '" class="' . f_cls() . ' pl-8"></div>';
    foreach ($filters as $name => [$opts, $empty]) {
        $h .= '<select name="' . e($name) . '" class="' . f_cls() . ' w-auto max-w-[14rem]"><option value="">' . e($empty) . '</option>';
        foreach ($opts as $k => $v) { $h .= '<option value="' . e($k) . '"' . (qget($name) === (string)$k ? ' selected' : '') . '>' . e($v) . '</option>'; }
        $h .= '</select>';
    }
    return $h . '<button class="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white hover:bg-brand-dark">Filtrer</button><a href="' . e(url($GLOBALS['P'] ?? 'dashboard', qget('a') ?: null)) . '" class="rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-600 hover:bg-slate-50">Réinitialiser</a></form>';
}
function vehicule_label(array $v): string { return e(($v['marque'] ?? '') . ' ' . ($v['modele'] ?? '')) . ' <span class="text-slate-400">·</span> <span class="font-mono text-xs">' . e($v['immatriculation'] ?? '') . '</span>'; }
function vehicule_options(bool $includeArchived = false): array
{
    $o = [];
    foreach (rows('SELECT id, marque, modele, immatriculation FROM vehicules WHERE ministere_id=?' . ($includeArchived ? '' : ' AND est_archive=0') . ' ORDER BY marque, modele', [mid()]) as $v) { $o[$v['id']] = $v['marque'] . ' ' . $v['modele'] . ' — ' . $v['immatriculation']; }
    return $o;
}
function chauffeur_options(bool $activeOnly = true): array
{
    $o = [];
    foreach (rows('SELECT id, nom, prenoms, matricule FROM chauffeurs WHERE ministere_id=?' . ($activeOnly ? ' AND actif=1' : '') . ' ORDER BY nom', [mid()]) as $c) { $o[$c['id']] = $c['nom'] . ' ' . $c['prenoms'] . ' (' . $c['matricule'] . ')'; }
    return $o;
}
